<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @package WordPress
 * @subpackage Twenty_Fifteen
 * @since Twenty Fifteen 1.0
 */

get_header(); ?> 
<?php /*
<style>
.error-section .error-image {
    background: rgba(0, 0, 0, 0) url(wp-content/themes/test/images/error-page.png) no-repeat scroll center center;
    display: inline-block;
    height: 333px;
    position: relative;
    width: 520px;
}
.error-section .error-image .error-code {
    color: #fff;
    font-size: 70px;
    font-weight: 700;
    left: 200px;
    line-height: 0;
    position: absolute;
    top: 105px;
}
.error-section .erorr-info {
    padding: 20px 0;
}      
</style>             
<div class="container section error-section">
  <div class="row text-center">
      <div class="col-md-12">
          <div class="title">
              <h1 class="uppercase"><strong>Don't Panic!</strong></h1>
              <p>The requested URL <i class="text-darkest">/sdfsdf</i> does not exist.</p>
          </div>
          <div class="error">
              <div class="error-image">   
                  <span class="error-code">404</span>
              </div>
          </div>
          <div class="erorr-info">  
              <h2 class="text-darkest">You may have lost or mis-spelt the URL.</h2>
          </div>
      </div>
  </div>
</div>   
*/
?>

<style>
.error-section .error-image {
    /*background: rgba(0, 0, 0, 0) url(wp-content/themes/test/images/error-page.png) no-repeat scroll center center;*/
    display: inline-block;
    position: relative;
    width: 100%;
}
.error-section .error-image .error-code {
    color: #000;
    font-size: 70px;
    font-weight: 700;
    left: 200px;
    line-height: 0;
    position: absolute;
    top: 105px;
}
.error-section .erorr-info {
    padding: 20px 0;
}
.error-code {
    color: #000;
    font-size: 70px;
    font-weight: 700;
    
}
  img {
    display: block;
    margin: 0 auto;
  }
a.link {
    color: #ffffff;
     margin-bottom: 10px;
}
.link-home {
    background: #0d89ff none repeat scroll 0 0;
    color: #ffffff;
}
.link {
    background: #555555 none repeat scroll 0 0;
    border-radius: 3px;
    color: #ffffff;
    display: inline-block;
    font-size: 16px;
    margin: 0 5px;
    padding: 8px 20px;
    text-decoration: none;
    text-transform: uppercase;
}
.link-contact {
    background: #ff9900 none repeat scroll 0 0;
    color: #ffffff;
}
</style>

<div class="container error-section">
  <div class="row text-center">
      <div class="col-md-12">
          <div class="title">
              <h1 class="uppercase"><strong>Don't Panic!</strong></h1>
              <p>The requested URL <i class="text-darkest"></i> does not exist.</p>
          </div>
          <div class="error">
              <div class="error-image">
                 <img src="wp-content/themes/test/images/error-page.png" class="img-responsive">    
                 
              </div>
          </div>
          <div class="erorr-info">
               <!--<span class="error-code">404</span>   -->
              <h2 class="text-darkest">You may have lost or mis-spelt the URL.</h2>
          </div>
      </div>
      
      <div class="col-md-12">
          <a class="link link-home" href="<?php echo  get_home_url(); ?>">Go Home</a>
          <a class="link link-contact" href="<?php echo get_permalink(150); ?>">Contact Us</a>
      </div>

  </div>
</div> 


<?php get_footer(); ?>
