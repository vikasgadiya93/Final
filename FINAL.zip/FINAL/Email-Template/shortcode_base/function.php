//Email fnnction

 function email_header_shortcode() {
        $home_page = home_url();    
        $logo = esc_url( get_option('site_logo_url') );
        $email_url = get_option('Header_email');
        $phone_no_no = trim(get_option('Header_phone'));
        return "<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>
        <html xmlns='http://www.w3.org/1999/xhtml'>
        <head>
        <meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
        <meta name='viewport' content='width=device-width, initial-scale=1, maximum-scale=1' />
        <meta http-equiv='X-UA-Compatible' content='IE=edge' />
        <meta name='format-detection' content='date=no' />
        <meta name='format-detection' content='address=no' />
        <meta name='format-detection' content='telephone_no=no' />
        <title></title>
        <style type='text/css'>
        body {
        margin: 0px !important;
        padding: 0px !important;
        -webkit-text-size-adjust: 100% !important;
        -ms-text-size-adjust: 100% !important;
        -webkit-font-smoothing: antialiased !important;
        }
        html {
        width: 100%;
        }
        img {
        border: 0 !important;
        outline: none !important;
        display: block !important;
        }
        table {
        border-collapse: collapse;
        mso-table-lspace: 0px;
        mso-table-rspace: 0px;
        }
        td {
        border-collapse: collapse;
        mso-line-height-rule: exactly;
        }
        a, span {
        mso-line-height-rule: exactly;
        }
        a {
        text-decoration: none !important;
        }
        .ExternalClass * {
        line-height: 100%;
        }
        .video img {
        width: 100%;
        height: auto;
        }
        h1, h2, h3, h4, h5, h6 {
        line-height: 100% !important;
        -webkit-font-smoothing: antialiased;
        }
        yshortcuts, .yshortcuts a, .yshortcuts a:link, .yshortcuts a:visited, .yshortcuts a:hover, .yshortcuts a span {
        color: black;
        text-decoration: none !important;
        border-bottom: none !important;
        background: none !important;
        }
        code {
        white-space: 300;
        word-break: break-all;
        }
        span a {
        text-decoration: none !important;
        }
        .yshortcuts a {
        border-bottom: none !important;
        }
        *[class='gmail-fix'] {
        display: none !important;
        }
        @media only screen and (min-width:481px) and (max-width:599px) {
        table[class=templetcontainer] {
        width: 100% !important;
        }
        table[class=spark_full_width_containt] {
        width: 100% !important;
        }
        td[class=spacer] {
        padding-left: 14px !important;
        padding-right: 14px !important;
        }
        td[class=remove] {
        display: none !important;
        }
        img[class=full_img] {
        width: 100% !important;
        height: auto !important;
        }
        td[class=height_f] {
        height: 20px !important;
        }
        td[class=video] img {
        width: 100% !important;
        height: auto !important;
        }
        td[class=text_center] {
        text-align: center !important;
        }
        .hide {
        display: none !important;
        }
        td[class='mob_hide'] {
        display: none !important;
        font-size: 0 !important;
        height: 0 !important;
        line-height: 0 !important;
        min-height: 0 !important;
        width: 0 !important;
        }
        td[class='templetcontainer2'] {
        float: left !important;
        width: 100% !important;
        display: block !important;
        }
        td[class=pad_bottom] {
        padding-bottom: 10px;
        }
        td[class=pad_top] {
        padding-top: 10px;
        }
        }
        @media only screen and (max-width:480px) {
        table[class=templetcontainer] {
        width: 100% !important;
        }
        table[class=spark_full_width_containt] {
        width: 100% !important;
        }
        td[class='spacer'] {
        padding-left: 16px !important;
        padding-right: 16px !important;
        }
        td[class=remove] {
        display: none !important;
        }
        img[class=full_img] {
        width: 100% !important;
        height: auto !important;
        }
        td[class=height_f] {
        height: 20px !important;
        }
        td[class=video] img {
        width: 100% !important;
        height: auto !important;
        }
        td[class=text_center] {
        text-align: center !important;
        }
        .hide {
        display: none !important;
        }
        td[class=pad_bottom] {
        padding-bottom: 10px;
        }
        td[class=pad_top] {
        padding-top: 10px;
        }
        td[class='mob_hide'] {
        display: none !important;
        font-size: 0 !important;
        height: 0 !important;
        line-height: 0 !important;
        min-height: 0 !important;
        width: 0 !important;
        }
        td[class='templetcontainer2'] {
        float: left !important;
        width: 100% !important;
        display: block !important;
        }
        }
        /* Hide spacer image in applications that support media queries */
        @media only screen and (max-width: 600px) {
        *[class='gmail-fix'] {
        display: none !important;
        }
        }
        </style>
        </head>
        <body marginwidth='0' marginheight='0' offset='0' topmargin='0' leftmargin='0' bgcolor='ffffff'>
        <table width='100%' border='0' align='center' cellspacing='0' cellpadding='0' bgcolor='#ffffff'>
        <tr class='gmail-fix'>
        <td><table cellpadding='0' cellspacing='0' border='0' align='center' width='600'>
        <tr>
        <td cellpadding='0' cellspacing='0' border='0' height='1' style='line-height: 1px; min-width: 600px;'>
        <img src='images/spacer.gif' width='600' height='1' style='display: block; max-height: 1px; min-height: 1px; min-width: 600px; width: 600px;'/>
        </td>
        </tr>
        </table></td>
        </tr>
        <tr>
        <td align='center'><table width='600' border='0' cellspacing='0' cellpadding='0' align='center' class='templetcontainer' style='table-layout:fixed;' >
        <tr>
        <td class='remove' height='20'>&nbsp;</td>
        </tr>
        <tr>
        <td align='center' valign='top' style='padding:10px 0px;'>
        <a href=".$home_page.">
        <img class='thank-you-img' src='".$logo."' alt='' style='max-width: 250px;'></a>
        </td>
        </tr>
        <tr>
        <td class='remove' height='20'>&nbsp;</td>
        </tr>
        </table>
        </td>
        </tr>
        <tr>
        <td align='center'><table width='600' border='0' cellspacing='0' cellpadding='0' align='center' class='templetcontainer' bgcolor='#ffffff' style='table-layout:fixed; background-color:#ffffff;' >
        <tr>
        <td width='20' class='remove'>&nbsp;</td>
        <td width='' class='spacer'><table width='560' border='0' cellspacing='0' cellpadding='0' align='center' class='templetcontainer'>
        <tr>
        <td align='center' style='font-family:Arial, sans-serif; font-size:14px; line-height:26px; color:#000000;'>";
    }
    add_shortcode( 'email_header', 'email_header_shortcode' );
    // Email Footer
    function email_footer_shortcode() {
        $home_page = home_url();    
        $email_url = get_option('Header_email');
        $phone_no = trim(get_option('Header_phone'));

        return "<tr>
        <td align='center'>
        <table width='600' border='0' cellspacing='0' cellpadding='0' align='center' class='templetcontainer'  bgcolor='#525354' style='table-layout:fixed; background-color:#525354;'>
        <tr>
        <td height='10' align='center' valign='top'></td>
        </tr>
        <tr>
        <td align='center' valign='top'  class='spacer'><table width='600' border='0' cellspacing='0' cellpadding='0' align='center' class='templetcontainer' bgcolor='#525354' style='table-layout:fixed; background-color:#525354;' >
        <tr>
        <td width='20' class='remove'>&nbsp;</td>
        <td width='' class='spacer'><table width='100%' border='0' cellspacing='0' cellpadding='0' align='center' class='templetcontainer'>
        <tr>
        <td align='center' valign='top' style='font-size:14px; line-height: 24px; font-family:  Arial, Helvetica, sans-serif; color:#ffffff;text-align: center; padding:0px 0;'>
        <strong style='color:#ffffff;'>Talk To Us:</strong><a href='tel:".$phone_no."' style='color: #ffffff;'> ".$phone_no."</a>
        </td>
        </tr>
        <tr>
        <td height='10' style='line-height:1px;font-size:1px;'  class='height_f'>&nbsp;</td>
        </tr>
        </table>
        </td>
        <td width='20' class='remove'>&nbsp;</td>
        </tr>
        </table></td>
        </tr>
        </table>
        </td>
        </tr>
        <tr>
        <td align='center'><table width='600' border='0' cellspacing='0' cellpadding='0' align='center' class='templetcontainer' >
        <tr>
        <td class='spacer'> <table width='600' border='0' cellspacing='0' cellpadding='0' align='center' class='templetcontainer'>
        <tr>
        <td height='15' style='line-height:1px; font-size:1px;'>&nbsp;</td>
        </tr>
        </table></td>
        </tr>
        <tr>
        <td height='20'>&nbsp;</td>
        </tr>
        </table></td>
        </tr>
        </table>
        </body>
        </html>";    
    }
    add_shortcode( 'email_footer', 'email_footer_shortcode' );