<?php

    $to = $email1;
    $subject = "Thank You for Contacting";
    $message = do_shortcode( '[email_header]' )."
    <h3> Thank You for Contacting. We will contact you soon</h3>
    <br> ".do_shortcode( '[email_footer]' );    
    $headers = 'From: Mosero <'.get_option('admin_email').'>' ."\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
    wp_mail( $to, $subject, $message, $headers );

    
    //To admin
     $to = get_option('admin_email');
        // $to = 'deval@redsparkinfo.com';

        $subject = "New Contact Inquiry";

        $message="<h2>Mosero Conatct Us</h2><br />";

        $message.="<style type='text/css'>
        #sign{
        display:none;
        }
        a { color: #2D7BE0; }
        a:hover { text-decoration: none; }
        </style>
        <table style='background: #eee; padding-left:10px;' width='100%'>
        <tr>
        <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'> First Name </th>
        <td bgcolor='#fff' style='padding: 5px; background-color: #fff;' align='center' width='2%'> : </td>
        <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$firstname."</td>
        </tr>
        <tr>
        <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'> Phone Number </th>
        <td bgcolor='#fff' style='padding: 5px; background-color: #fff;' align='center' width='2%'> : </td>
        <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$phone."</td>
        </tr> 

        <tr>
        <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'> Email </th>
        <td bgcolor='#fff' style='padding: 5px; background-color: #fff;' align='center' width='2%'> : </td>
        <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$email1."</td>
        </tr> 

        <tr>
        <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'> Message </th>
        <td bgcolor='#fff' style='padding: 5px; background-color: #fff;' align='center' width='2%'> : </td>
        <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$Message1."</td>
        </tr> 
        </table>
        <br>"; 

        //  $headers = "From: Quest Media profile_img ";
        $headers = 'From: Mosero <'.get_option('admin_email').'>' . "\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
        wp_mail( $to, $subject, $message, $headers );

        $emailSent = true;
        $success = "1"; 
        }
?>