function load_more() {
    if ( isset($_REQUEST) ) {
        $dirName = dirname(__FILE__);
        require_once ("$dirName/ajax/load_more.php"); 
    }
    die();
}
add_action( 'wp_ajax_load_more', 'load_more' );
add_action( 'wp_ajax_nopriv_load_more', 'load_more' );