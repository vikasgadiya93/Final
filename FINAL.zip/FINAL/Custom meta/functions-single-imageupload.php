<?php 

function img_add_meta_box() {

    add_meta_box(
    'img_sectionid',
    __( 'Brochure Document', 'myplugin_textdomain' ),
    'img_meta_box_callback'
    );
}
add_action( 'add_meta_boxes', 'img_add_meta_box' );

/**
* Prints the box content.
* 
* @param WP_Post $post The object for the current post/page.
*/
function img_meta_box_callback( $post ) {

    wp_nonce_field( 'img_meta_box', 'img_meta_box_nonce' );
    
    $brochure_document = get_post_meta( $post->ID, 'brochure_document', true );   //yes

    echo "<script language='JavaScript'>
    jQuery(document).ready(function() {
   jQuery('#portfolio_image_button_image').click(function() {
    formfield = jQuery('#portfolio_image').attr('name');
    
    tb_show('', 'media-upload.php?type=image&TB_iframe=true');

   window.send_to_editor = function(html_val) {
      
       var buttonID = jQuery(this).attr('name');
       alert(buttonID);
    imgurl = jQuery(html_val).attr('src');
    
    if(  imgurl == undefined) {      
   
       imgurl = jQuery(html_val).attr('href'); // We do this to get Links like PDF's
   
    }   
  
    
  
  
   
   
   // imgurl = jQuery('img',html_val).attr('src');
   // imgurl = jQuery(html_val).attr('src');
   
    jQuery('#portfolio_image').val(imgurl);
    tb_remove();
    }
    return false;
    });
    });
    </script>";

    echo '<table><tr>
    <td style="width:20%;"> <label for="banner_title">';
    _e( 'Brochure Document : ', 'port_folio' );
    echo '</label></td>';

    echo '<td style="width:60%;"><input id="portfolio_image" type="text" size="36" name="brochure_document" value="'.$brochure_document.'" style=" margin-right: 10px; margin-top: 10px; width: 99%;" /></td><td style="width:20%;"><input id="portfolio_image_button_image" type="button" value="Upload Brochure Document" /></td>';
    echo '<label></td></tr></table>';
}

//Save meta value
function myplugin_save_meta_box_data( $post_id) {
   
   // $portfolio_image = "";
    
    
     if(isset($_POST["brochure_document"]))
    {
        $brochure_document = $_POST["brochure_document"];
    }   
    update_post_meta( $post_id, 'brochure_document', $brochure_document );
}
add_action( 'save_post', 'myplugin_save_meta_box_data' );


?>