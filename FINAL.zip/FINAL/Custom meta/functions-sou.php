<?php
// Event Meta
function event_content_add_meta_box() {
        $screens_val = array( 'post' );
        foreach ( $screens_val as $screen ) {  
            add_meta_box(
            'event_content_sectionid',
            __( 'Event Details', 'event_content_textdomain' ),
            'event_content_meta_box_callback',
            $screen
            );
        }
    }
add_action( 'add_meta_boxes', 'event_content_add_meta_box' );

function event_content_meta_box_callback( $post ) {
        wp_nonce_field( 'event_content_meta_box', 'event_content_meta_box_nonce' );
        $event_email = get_post_meta( $post->ID, 'event_email', true );
        $event_phone = get_post_meta( $post->ID, 'event_phone', true );
        $event_price = get_post_meta( $post->ID, 'event_price', true );
        $event_place = get_post_meta( $post->ID, 'event_place', true );
        $event_address = get_post_meta( $post->ID, 'event_address', true );
        $event_city = get_post_meta( $post->ID, 'event_city', true );
        $event_org = get_post_meta( $post->ID, 'event_org', true );
        $event_sdate = get_post_meta( $post->ID, 'event_sdate', true );
        $event_edate = get_post_meta( $post->ID, 'event_edate', true );
        $event_stime = get_post_meta( $post->ID, 'event_stime', true );
        $event_etime = get_post_meta( $post->ID, 'event_etime', true );
        $event_facebook = get_post_meta( $post->ID, 'event_facebook', true );
        $event_google = get_post_meta( $post->ID, 'event_google', true );
        $event_twitter = get_post_meta( $post->ID, 'event_twitter', true );
        $event_instagram = get_post_meta( $post->ID, 'event_instagram', true );

        $settings = array(
        'tinymce' => true,
        'textarea_rows' => 10,
        );
        $editor_id = "event_address";
        echo '<table style="width:100%">';
        echo '<tr><td> Price :</td><td><input type="text" name="event_price" value="'.$event_price.'" style="width:100%"></td></tr>';
        echo '<tr><td> Starting Date :</td><td><input type="text" name="event_sdate"  value="'.$event_sdate.'" id="event_sdate" style="width:100%"/></td></tr>
        <tr><td> Starting Time :</td><td><input type="text" name="event_stime" value="'.$event_stime.'" style="width:100%"></td></tr> 
        <tr><td> Ending Date :</td><td><input type="text" name="event_edate" value="'.$event_edate.'" id="event_edate" style="width:100%"></td></tr>
        <tr><td> Ending Time :</td><td><input type="text" name="event_etime" value="'.$event_etime.'" style="width:100%"></td></tr>';
        echo '<tr><td> Place :</td><td><input type="text" value="'.$event_place.'" name="event_place" id="event_place" style="width:100%; padding: 5px 0;"></td></tr>';
        echo '<tr><td> Address : </td><td>';wp_editor( $event_address, $editor_id, $settings );'</td></tr>';
        echo '<tr><td> City :</td><td><input type="text" name="event_city" value="'.$event_city.'" style="width:100%"></td></tr>
        <tr><td> Organizer Name :</td><td><input type="text" name="event_org" value="'.$event_org.'" style="width:100%"></td></tr>
        <tr><td> Email :</td><td><input type="text" name="event_email" value="'.$event_email.'" style="width:100%"></td></tr>
        <tr><td> Phone :</td><td><input type="text" name="event_phone" value="'.$event_phone.'" style="width:100%"></td></tr>'; 
        echo '<tr><td> Facebook :</td><td><input type="text" name="event_facebook" value="'.$event_facebook.'" style="width:100%"></td></tr>
        <tr><td> Google :</td><td><input type="text" name="event_google" value="'.$event_google.'" style="width:100%"></td></tr>
        <tr><td> Twitter :</td><td><input type="text" name="event_twitter" value="'.$event_twitter.'" style="width:100%"></td></tr>
        <tr><td> Instagram :</td><td><input type="text" name="event_instagram" value="'.$event_instagram.'" style="width:100%"></td></tr>';
        echo '</table>';
        wp_enqueue_script( 'jquery-ui-datepicker' );
        wp_enqueue_style( 'jquery-ui-style', '//ajax.googleapis.com/ajax/libs/jqueryui/1.8.1/themes/smoothness/jquery-ui.css', true);
        echo "<script>
        jQuery(document).ready(function(){
        jQuery('#event_sdate').datepicker({
        dateFormat : 'dd-mm-yy'
        });
        jQuery('#event_edate').datepicker({
        dateFormat : 'dd-mm-yy'
        });
        });
        </script>";
    }

    //Save meta value
function myplugin_save_meta_box_data( $post_id ) {

        $event_price =  $_POST['event_price']; 
        update_post_meta( $post_id, 'event_price', $event_price );
        $event_email =  $_POST['event_email'] ; 
        update_post_meta( $post_id, 'event_email', $event_email );
        $event_phone =  $_POST['event_phone'];
        update_post_meta( $post_id, 'event_phone', $event_phone );
        $event_place =  $_POST['event_place'] ;        
        update_post_meta( $post_id, 'event_place', $event_place );
        $event_address =  $_POST['event_address'] ;     
        update_post_meta( $post_id, 'event_address', $event_address );
        $event_city =  $_POST['event_city'] ;     
        update_post_meta( $post_id, 'event_city', $event_city );
        $event_org =  $_POST['event_org'] ;     
        update_post_meta( $post_id, 'event_org', $event_org );
        $event_sdate =  $_POST['event_state'];         
        update_post_meta( $post_id, 'event_sdate', $event_sdate );
        $event_edate =  $_POST['event_edate'] ;     
        update_post_meta( $post_id, 'event_edate', $event_edate );
        $event_stime =  $_POST['event_stime'] ;     
        update_post_meta( $post_id, 'event_stime', $event_stime );
        $event_etime =  $_POST['event_etime'] ;     
        update_post_meta( $post_id, 'event_etime', $event_etime );
        $event_facebook =  $_POST['event_facebook'] ;     
        update_post_meta( $post_id, 'event_facebook', $event_facebook );
        $event_google =  $_POST['event_google'] ;     
        update_post_meta( $post_id, 'event_google', $event_google );
        $event_twitter =  $_POST['event_twitter'] ;     
        update_post_meta( $post_id, 'event_twitter', $event_twitter );
        $event_instagram =  $_POST['event_instagram'] ;     
        update_post_meta( $post_id, 'event_instagram', $event_instagram );
    }
add_action( 'save_post', 'myplugin_save_meta_box_data' );
    // end 
//Meta repeeters
 



add_action('admin_init', 'hhs_add_meta_boxes', 1);
function hhs_add_meta_boxes() {
        add_meta_box( 'repeatable-fields', 'Youtube link', 'hhs_repeatable_meta_box_display', 'post', 'normal', 'default');
    }

function hhs_repeatable_meta_box_display() {
        global $post;
        $repeatable_fields = get_post_meta($post->ID, 'repeatable_fields', true);
        wp_nonce_field( 'hhs_repeatable_meta_box_nonce', 'hhs_repeatable_meta_box_nonce' );
    ?>
    <script type="text/javascript">
        jQuery(document).ready(function( $ ){
            $( '#add-row' ).on('click', function() {
                var row = $( '.empty-row.screen-reader-text' ).clone(true);
                row.removeClass( 'empty-row screen-reader-text' );
                row.insertBefore( '#repeatable-fieldset-one tbody>tr:last' );
                return false;
            });  
            $( '.remove-row' ).on('click', function() {
                $(this).parents('tr').remove();
                return false;
            });
        });
    </script>

    <table id="repeatable-fieldset-one" width="100%">
        <thead>
            <tr>
                <th width="15%">Name</th>
                <th width="60%"> You tube URL</th>
                <th width="8%"></th>
            </tr>
        </thead>
        <tbody>
            <?php

                if ( $repeatable_fields ) :

                    foreach ( $repeatable_fields as $field ) {
                    ?>
                    <tr>
                        <td><input type="text" class="widefat" name="name[]" value="<?php if($field['name'] != '') echo esc_attr( $field['name'] ); ?>" /></td>
                        <td><input type="text" class="widefat" name="url[]" value="<?php if ($field['url'] != '') echo esc_attr( $field['url'] ); ?>" /></td>
                        <td><a class="button remove-row" href="#">Remove</a></td>
                    </tr>
                    <?php
                    }
                    else :
                    // show a blank one
                ?>
                <tr>
                    <td><input type="text" class="widefat" name="name[]" /></td>
                    <td><input type="text" class="widefat" name="url[]" /></td>
                    <td><a class="button remove-row" href="#">Remove</a></td>
                </tr>
                <?php endif; ?> 
            <!-- empty hidden one for jQuery -->
            <tr class="empty-row screen-reader-text">
                <td><input type="text" class="widefat" name="name[]" /></td>
                <td><input type="text" class="widefat" name="url[]"  /></td>

                <td><a class="button remove-row" href="#">Remove</a></td>
            </tr>
        </tbody>
    </table>

    <p><a id="add-row" class="button" href="#">Add another</a></p>
    <?php
}
add_action('save_post', 'hhs_repeatable_meta_box_save');
function hhs_repeatable_meta_box_save($post_id) {
    if ( ! isset( $_POST['hhs_repeatable_meta_box_nonce'] ) ||
    ! wp_verify_nonce( $_POST['hhs_repeatable_meta_box_nonce'], 'hhs_repeatable_meta_box_nonce' ) )
        return;

    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)
        return;

    if (!current_user_can('edit_post', $post_id))
        return;

    $old = get_post_meta($post_id, 'repeatable_fields', true);

    $new = array();


    $names = $_POST['name'];

    $urls = $_POST['url'];

    $count = count( $names );
    for ( $i = 0; $i < $count; $i++ ) {
        if ( $names[$i] != '' ) :
            $new[$i]['name'] = stripslashes( strip_tags( $names[$i] ) );

            if ( $urls[$i] == '' )
                $new[$i]['url'] = '';   
            else
                $new[$i]['url'] = stripslashes( $urls[$i] ); // and however you want to sanitize
            endif;
    }
    if ( !empty( $new ) && $new != $old )
        update_post_meta( $post_id, 'repeatable_fields', $new );
    elseif ( empty($new) && $old )
        delete_post_meta( $post_id, 'repeatable_fields', $old );
}