<?php
    // parse_str($_POST['data'], $_POST);
  $response = array();
    global $wpdb;
    // global $data; 
    if(isset($_POST)){
     $url =   get_theme_root(); 
    
        
        require_once($url.'/projectname/Stripe/lib/Stripe.php');
        try {
            Stripe::setApiKey("sk_test_9Y66vhjMznY9TyXK1fl4bSgg");
            Stripe_Charge::create(array("amount" => $_POST['amount'],
            "currency" => $_POST['currency'],
            "card" => $_POST['stripeToken'],
            "description" => "Charge Tax Retrun Form"   
            ));
        /*    $success = '<div class="alert alert-success">
            <strong>Success!</strong> Your payment was successful.
             </div>';*/
            $success = 1;         
        }
        
        catch(Stripe_CardError $e) {
            $error1   = '<div class="alert alert-danger">
            <strong>Error!</strong> '.$e->getMessage().'
            </div>';
           //  $message1 = $e->getMessage();
                   
        } catch (Stripe_InvalidRequestError $e) {

            $error2 = '<div class="alert alert-danger">
            <strong>Error!</strong> '.$e->getMessage().'
            </div>';
           // $message2 = $e->getMessage();
          
            
        } catch (Stripe_AuthenticationError $e) {

           $error3 = '<div class="alert alert-danger">
            <strong>Error!</strong> '.$e->getMessage().'
            </div>';
          //  $message3 = $e->getMessage();
          
        } catch (Stripe_ApiConnectionError $e) {
            $error4 = '<div class="alert alert-danger">
            <strong>Error!</strong> '.$e->getMessage().'
            </div>';
           // $message4 = $e->getMessage();

        } catch (Stripe_Error $e) {
            $error5 = '<div class="alert alert-danger">
            <strong>Error!</strong> '.$e->getMessage().'
            </div>';
          //  $message5 = $e->getMessage();

        } catch (Exception $e) {
            $error6 = '<div class="alert alert-danger">
            <strong>Error!</strong> '.$e->getMessage().'
            </div>';
        ///    $message6 = $e->getMessage();
           
        }

         if($success != 1){
            // echo "1";
            echo $error1;         
            echo $error2;
            echo $error3; 
            echo $error4; 
            echo $error5; 
            echo $error6;
     
        }else{  
        // personal information
        $year   = $_POST['year'];                  
        $first_name  = $_POST['first_name'];
        $last_name = $_POST['last_name'];
        $tfn = $_POST['tfn'];
        $phone_number = $_POST['phone_number'];
        $email_id = $_POST['email_id'];
        $date_of_birth = $_POST['date_of_birth'];
        $bsb = $_POST['bsb'] ;
        $account   = $_POST['account'];                  
        $accountname  = $_POST['accountname'];
        $contact_residence_address = $_POST['contact_residence_address'];
        $postaladdress = $_POST['postaladdress'];
        $australian_citizen = $_POST['australian_citizen'];
        $visa_type = $_POST['visa_type'] ;
        $medicare_card   = $_POST['medicare_card'];                  
        $medicare_card_hold_days  = $_POST['medicare_card_hold_days'];
        $private_health_insurance = $_POST['private_health_insurance'];
        $spouse = $_POST['spouse'];
        $spouse_name = $_POST['spouse_name'];
        $spouse_gender   = $_POST['spouse_gender'];                  
        $spouse_date_of_birth  = $_POST['spouse_date_of_birth'];
        $spouse_yearly_taxable_income = $_POST['spouse_yearly_taxable_income'];
        $dependent_children = $_POST['dependent_children'];
        $no_children = $_POST['no_children'];
        $help_debt = $_POST['help_debt'];
        $help_debt_amount = $_POST['help_debt_amount'] ;

        // income data
        foreach($_POST['employer_name'] as $key => $value){
            $employer_name = $_POST['employer_name'][$key] ;  
            $employer[] = $employer_name;      
        }
        // print_R($employer) ;
        $all_employe = implode(",",$employer);


        //print_R($_POST['payg_wihold']); die();
        foreach($_POST['payg_wihold'] as $key => $value){
            $payg_wihold = $_POST['payg_wihold'][$key] ; 

            $payg[] = $payg_wihold;      
        }
        // print_R($payg) ;
        $all_payg_wihold = implode(",",$payg);

        foreach($_POST['gross_wags'] as $key => $vale){
            $gross_wags = $_POST['gross_wags'][$key] ;  
            $gross_wag[] = $gross_wags;      
        }
        // print_R($gross_wag) ;
        $all_gross_wags = implode(",",$gross_wag);

        foreach($_POST['allowance'] as $key => $vale){
            $allowance = $_POST['allowance'][$key] ;  
            $allowances[] = $allowance;      
        }
        //print_R($allowances) ;
        $all_allowance = implode(",",$allowances);  

        $centerlink_income = $_POST['centerlink_income'];                  
        $centerlink_income_details  = $_POST['centerlink_income_details'];
        $centerlink_income_payg_withold = $_POST['centerlink_income_payg_withold'];
        $centerlink_income_payment = $_POST['centerlink_income_payment'];
        $bank_interest_received = $_POST['bank_interest_received'];
        $bank_interest_tax_withold = $_POST['bank_interest_tax_withold'];
        $bank_interest_total_interest = $_POST['bank_interest_total_interest'];
        $dividned_income_unfranked = $_POST['dividned_income_unfranked'];
        $dividned_income_franked = $_POST['dividned_income_franked'];
        $dividned_income_franked_credit = $_POST['dividned_income_franked_credit'] ;
        $other_income   = $_POST['other_income'];                  
        $other_income_amount  = $_POST['other_income_amount']; 
      //  $attach_document_income = $_POST['attach_document_income']; 
      
       $no_files = count($_FILES["files"]['name']);
             $images_arr = array();     
        for ($i = 0; $i < $no_files; $i++) {  
            //move_uploaded_file($_FILES["files"]["tmp_name"][$i], 'uploads/' . $_FILES["files"]["name"][$i]);
            //      echo 'File successfully uploaded : uploads/' . $_FILES["files"]["name"][$i] . ' ';
            $uploads = wp_upload_dir(); 
            $upload_dir = $uploads['basedir']; 
            $upload_dir1 = $uploads['baseurl']; 

            $new_upload= $upload_dir."/Document/";  
            $new_upload1= $upload_dir1."/Document/";

            $file = $new_upload .basename($_FILES['files']['name'][$i]);
            $img = $_FILES['files']['name'][$i] ;
            $file1 = $new_upload1."".$img; 

            move_uploaded_file($_FILES['files']['tmp_name'][$i], $file);
             $images_arr[] = $img;

        }
         $all_images = implode(",",$images_arr);
        // echo $all_images; die('test'); 
      
      
           


        // deduction filed
        $claim_method_deduction   = $_POST['claim_method_deduction'];                  
        $kms_travelled  = $_POST['kms_travelled'];
        $mv_engine_size = $_POST['mv_engine_size'];
        $log_book_method_amount = $_POST['log_book_method_amount'];
        $uniform_amount = $_POST['uniform_amount'];
        $self_education_description = $_POST['self_education_description'];
        $self_education_amount = $_POST['self_education_amount'];

        foreach($_POST['Other_expense_description'] as $key => $value){
            $Other_expense_description = $_POST['Other_expense_description'][$key] ; 

            $Other_expense_des[] = $Other_expense_description;      
        }
        $all_Other_expense_des  = implode(",",$Other_expense_des);


        foreach($_POST['Other_expense_per_working_related'] as $key => $value){
            $Other_expense_per_working_related = $_POST['Other_expense_per_working_related'][$key] ; 

            $Other_expense_per_wroking[] = $Other_expense_per_working_related;      
        }
        $all_Other_expense_per_wroking = implode(",",$Other_expense_per_wroking);
        foreach($_POST['Other_expense_amount'] as $key => $value){
            $Other_expense_amount = $_POST['Other_expense_amount'][$key] ; 

            $Other_expense_amont[] = $Other_expense_amount;      
        }

        $all_Other_expense_amont = implode(",",$Other_expense_amont);

        $gifts_donations_description = $_POST['gifts_donations_description'] ;
        $gifts_donations_amount   = $_POST['gifts_donations_amount'];                  
        $Offsets_single_pay  = $_POST['Offsets_single_pay'];
        $Offsets_remote_area   = $_POST['Offsets_remote_area'];                  
        $offset_post_code  = $_POST['offset_post_code'];
        $offset_notes = $_POST['offset_notes'];



        // busniess data    
        $business_name   = $_POST['business_name'];                  
        $business_activity  = $_POST['business_activity'];
        $business_address = $_POST['business_address'];
          $business_income = $_POST['business_income'];
      //  $business_exp_stationery = $_POST['business_exp_stationery'];
      //  $business_exp_direct_cost = $_POST['business_exp_direct_cost'];
      //  $business_exp_mobile = $_POST['business_exp_mobile'];
     //   $business_exp_travelling = $_POST['business_exp_travelling'];
    //    $business_exp_other_expense = $_POST['business_exp_other_expense'] ;
      foreach($_POST['business_expans_des'] as $key => $value){
            $business_expans_des = $_POST['business_expans_des'][$key] ; 

            $business_expans_description[] = $business_expans_des;      
        }
      $all_business_expans_description = implode(",",$business_expans_description);
      
          foreach($_POST['business_exp_amount'] as $key => $value){
            $business_exp_amount = $_POST['business_exp_amount'][$key] ; 

            $business_exp_amont[] = $business_exp_amount;      
        }
      $all_business_exp_amont = implode(",",$business_exp_amont);
        $busniess_loss_pre_year   = $_POST['busniess_loss_pre_year'];   
        $business_exp_forward_loss   = $_POST['business_exp_forward_loss'];

        $data = array(
        "year"=>$year,
        "first_name"=>$first_name,
        "last_name"=>$last_name,
        "tfn"=> $tfn  ,
        "date_of_birth"=> $date_of_birth,
        "phone_number"=>$phone_number,
        "email"=>$email_id,
        "bsb"=> $bsb,
        "account"=> $account,
        "accountname"=> $accountname,
        "residence_address"=> $contact_residence_address,
        "postaladdress"=> $postaladdress,
        "australian_citizen"=> $australian_citizen,
        "visa_type"=> $visa_type,
        "medicare_card"=> $medicare_card,
        "medicare_card_hold_days"=> $medicare_card_hold_days,
        "private_health_insurance"=> $private_health_insurance,
        "spouse"=> $spouse,
        "spouse_name"=> $spouse_name,
        "spouse_gender"=> $spouse_gender,
        "spouse_date_of_birth"=>$spouse_date_of_birth,
        "spouse_yearly_taxable_income"=>$spouse_yearly_taxable_income,
        "dependent_children"=>$dependent_children,
        "no_children"=>$no_children,
        "help_debt"=>$help_debt,
        "help_debt_amount"=> $help_debt_amount,
        /*"employer_name"=> $all_employe,
        "payg_wihold"=> $all_payg_wihold,
        "gross_wags"=> $all_gross_wags,
        "allowance"=> $all_allowance,  
        "centerlink_income" => $centerlink_income,
        "centerlink_income_details"=>$centerlink_income_details,
        "centerlink_income_payg_withold"=>$centerlink_income_payg_withold,
        "bank_interest_received"=> $bank_interest_received  ,
        "bank_interest_total_interest"=> $bank_interest_total_interest,
        "dividned_income_unfranked"=>$dividned_income_unfranked,
        "dividned_income_franked"=>$dividned_income_franked,
        "dividned_income_franked_credit"=> $dividned_income_franked_credit,
        "other_income"=> $other_income,
        "other_income_amount"=> $other_income_amount,
        // "attach_document_income"=> $attach_document_income,  
        "claim_method_deduction"=>$claim_method_deduction,
        "kms_travelled"=>$kms_travelled,
        "mv_engine_size"=>$mv_engine_size,
        "log_book_method_amount"=> $log_book_method_amount,
        "uniform_amount"=> $uniform_amount  ,
        "self_education_description"=> $self_education_description,
        "self_education_amount"=>$self_education_amount,
        "Other_expense_description"=>$all_Other_expense_des,
        "Other_expense_per_working_related"=> $all_Other_expense_per_wroking,
        "Other_expense_amount"=> $all_Other_expense_amont,
        "gifts_donations_description"=> $gifts_donations_description,
        "gifts_donations_amount"=> $gifts_donations_amount,
        "Offsets_single_pay"=> $Offsets_single_pay,
        "Offsets_remote_area"=> $Offsets_remote_area,
        "offset_post_code"=> $offset_post_code,                     
        "offset_notes"=> $offset_notes,
        // for busineess    
        "business_name"=>$business_name,
        "business_activity"=>$business_activity,
        "business_address"=>$business_address,
        "business_exp_stationery"=> $business_exp_stationery  ,
        "business_exp_direct_cost"=> $business_exp_direct_cost,
        "business_exp_mobile"=>$business_exp_mobile,
        "business_exp_travelling"=>$business_exp_travelling,
        "business_exp_other_expense"=> $business_exp_other_expense,
        "busniess_loss_pre_year"=> $busniess_loss_pre_year,
        "business_exp_forward_loss"=> $business_exp_forward_loss,*/

        );
        // echo "<pre>"; print_r($data); "</pre>";
     //  $insert = $wpdb->insert("wp_individual_tax_return",$data);
       $insert = $wpdb->insert("wp_individual_option_retun",$data);

        $lastInsertId = $wpdb->insert_id;  
   
      $data = array(
        "parent_id"=>$lastInsertId, 
        "employer_name"=> $all_employe,
        "payg_wihold"=> $all_payg_wihold,
        "gross_wags"=> $all_gross_wags,
        "allowance"=> $all_allowance,  
        "centerlink_income" => $centerlink_income,
        "centerlink_income_details"=>$centerlink_income_details,
        "centerlink_income_payg_withold"=>$centerlink_income_payg_withold,
        "centerlink_income_payment"=>$centerlink_income_payment, 
        "bank_interest_received"=> $bank_interest_received  ,
        "bank_interest_tax_withold"=> $bank_interest_tax_withold  ,
        "bank_interest_total_interest"=> $bank_interest_total_interest,
        "dividned_income_unfranked"=>$dividned_income_unfranked,
        "dividned_income_franked"=>$dividned_income_franked,
        "dividned_income_franked_credit"=> $dividned_income_franked_credit,
        "other_income"=> $other_income,
        "other_income_amount"=> $other_income_amount,
        "attach_document_income"=> $all_images,
         );
       
         $insert = $wpdb->insert("wp_individual_income_return",$data); 
      
      
       $data = array(   
        "parent_id"=>$lastInsertId, 
         "claim_method_deduction"=>$claim_method_deduction,
        "kms_travelled"=>$kms_travelled,
        "mv_engine_size"=>$mv_engine_size,
        "log_book_method_amount"=> $log_book_method_amount,
        "uniform_amount"=> $uniform_amount  ,
        "self_education_description"=> $self_education_description,
        "self_education_amount"=>$self_education_amount,
        "Other_expense_description"=>$all_Other_expense_des,
        "Other_expense_per_working_related"=> $all_Other_expense_per_wroking,
        "Other_expense_amount"=> $all_Other_expense_amont,
        "gifts_donations_description"=> $gifts_donations_description,
        "gifts_donations_amount"=> $gifts_donations_amount,
        "Offsets_single_pay"=> $Offsets_single_pay,
        "Offsets_remote_area"=> $Offsets_remote_area,
        "offset_post_code"=> $offset_post_code,                     
        "offset_notes"=> $offset_notes,
        );
       
         $insert = $wpdb->insert("wp_individual_deduction_return",$data); 
        
        
       $data = array(   
        "parent_id"=>$lastInsertId, 
        "business_name"=>$business_name,
        "business_activity"=>$business_activity,
        "business_address"=>$business_address,
        "business_income"=>$business_income,
        "business_expans_des"=> $all_business_expans_description  ,
        "business_exp_amount"=> $all_business_exp_amont,
        //"business_exp_stationery"=> $business_exp_stationery  ,
      //  "business_exp_direct_cost"=> $business_exp_direct_cost,
      //  "business_exp_mobile"=>$business_exp_mobile,
     //   "business_exp_travelling"=>$business_exp_travelling,
     //   "business_exp_other_expense"=> $business_exp_other_expense,
        "busniess_loss_pre_year"=> $busniess_loss_pre_year,
        "business_exp_forward_loss"=> $business_exp_forward_loss,
        );
       
         $insert = $wpdb->insert("wp_individual_business_return",$data);
       
       
       
       
       
        foreach($_POST['investment_first'] as $key=>$val)
        {

            $address_investment_property = $_POST['address_investment_property'][$key];
            $date_investment_property = $_POST['date_investment_property'][$key];
            $investment_first = $_POST['investment_first'][$key];
            $investment_second = $_POST['investment_second'][$key];
           
            $investment_percentage_first = $_POST['investment_percentage_first'][$key];
            
            $investment_percentage_secound = $_POST['investment_percentage_secound'][$key];
            $investment_rental_income = $_POST['investment_rental_income'][$key];
            $investment_other_income = $_POST['investment_other_income'][$key];
            $investment_advertising = $_POST['investment_advertising'][$key];
            
            $investment_body_corporate_fees = $_POST['investment_body_corporate_fees'][$key];
            $investment_borrowing_expenses = $_POST['investment_borrowing_expenses'][$key];
            $investment_cleaning = $_POST['investment_cleaning'][$key];
            $investment_council_rates = $_POST['investment_council_rates'][$key];
          
            $investment_gardening = $_POST['investment_gardening'][$key];
            $investment_insurance = $_POST['investment_insurance'][$key];
            $investment_interest = $_POST['investment_interest'][$key];
            $investment_land_tax = $_POST['investment_land_tax'][$key];
            $investment_legal_fees = $_POST['investment_legal_fees'][$key];
            $investment_pest_control = $_POST['investment_pest_control'][$key];
            $investment_agent_fee = $_POST['investment_agent_fee'][$key];
            $investment_repairs = $_POST['investment_repairs'][$key];
            $investment_capital_work = $_POST['investment_capital_work'][$key];
            $investment_capital_allowance = $_POST['investment_capital_allowance'][$key];
            $investment_office_supplies = $_POST['investment_office_supplies'][$key];
            $investment_travel = $_POST['investment_travel'][$key];
            $investment_water = $_POST['investment_water'][$key];
            $investment_sundry = $_POST['investment_sundry'][$key];

        /*  echo $address_investment_property;  "<pre>"  ;   
          echo $date_investment_property ;"<pre>"  ;   
          echo  $investment_first   ;"<pre>"  ;   
          echo  $investment_second  ;"<pre>"  ;   
          echo $investment_percentage_first  ;"<pre>"  ;   
          echo $investment_percentage_secound   ;"<pre>"  ;   
          echo  $investment_rental_income ; "<pre>"  ;   
          echo $investment_other_income   ;"<pre>"  ;  
          echo  $investment_advertising  ;"<pre>"  ;   
          echo   $investment_body_corporate_fees ;"<pre>"  ;   
          echo  $investment_borrowing_expenses  ;"<pre>"  ;   
          echo  $investment_cleaning  ;"<pre>"  ;   
          echo $investment_council_rates   ;"<pre>"  ;   
          echo  $investment_gardening  ;"<pre>"  ;   
          echo  $investment_insurance  ;"<pre>"  ;   
          echo  $investment_interest  ;"<pre>"  ;   
          echo  $investment_land_tax   ;"<pre>"  ;   
          echo $investment_legal_fees   ;"<pre>"  ;   
          echo $investment_pest_control   ;"<pre>"  ;   
          echo $investment_agent_fee   ;"<pre>"  ;   
          echo  $investment_repairs  ;"<pre>"  ;   
          echo $investment_capital_work   ;"<pre>"  ;   
          echo  $investment_capital_allowance  ;"<pre>"  ;   
          echo $investment_office_supplies   ;"<pre>"  ;   
          echo  $investment_travel  ;"<pre>"  ;   
          echo $investment_water   ;"<pre>"  ;   
          echo  $investment_sundry  ;"<pre>"  ;   */
            
           $data_1 = array(          
                "parent_id"=>$lastInsertId,
                "address_investment_property"=>$address_investment_property,
                "date_investment_property"=>$date_investment_property,
                "investment_first"=>$investment_first,
                "investment_second"=> $investment_second  ,
                "investment_percentage_first"=> $investment_percentage_first,
                "investment_percentage_secound"=>$investment_percentage_secound,
                "investment_rental_income"=>$investment_rental_income,
                "investment_other_income"=> $investment_other_income,
                "investment_advertising"=> $investment_advertising,
                "investment_body_corporate_fees"=> $investment_body_corporate_fees,
                "investment_borrowing_expenses"=> $investment_borrowing_expenses,
                "investment_cleaning"=> $investment_cleaning,
                "investment_council_rates"=> $investment_council_rates,
                "investment_gardening"=> $investment_gardening,
                "investment_insurance"=> $investment_insurance,
                "investment_interest"=> $investment_interest,
                "investment_land_tax"=> $investment_land_tax,
               
                "investment_legal_fees"=> $investment_legal_fees,
               
                "investment_pest_control"=> $investment_pest_control,
               
                "investment_agent_fee"=> $investment_agent_fee,
               
                "investment_repairs"=> $investment_repairs,
               
                "investment_capital_work"=>$investment_capital_work,
               
                "investment_capital_allowance"=>$investment_capital_allowance,
               
                "investment_office_supplies"=>$investment_office_supplies,
               
                "investment_travel"=>$investment_travel,
               
                "investment_water"=>$investment_water,
               
                "investment_sundry"=>$investment_sundry, 
           
            
        
         ); 
         $insert = $wpdb->insert("wp_individual_investment_property",$data_1)    ;    
        
        }
         echo "1";
  
  
    
          
        
        
        
       
       
       
       
       
       
       
       
       
       /* if($insert)
        {
            echo 1;;
        }
        else
        {
            echo "2";
        }       */
     /*   $to = get_option('admin_email');
        $subject = "New Contact Inquiry";

        $message="<h2>ETax Individual Enquiry</h2><br />";
        $message.="<style type='text/css'>
        #sign{
        display:none;
        }
        a { color: #2D7BE0; }
        a:hover { text-decoration: none; }
        </style>
        <table style='background: #eee; padding-left:10px;' width='100%'>
        <tr>
        <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'> Year </th>
        <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$year."</td>
        </tr> 
        <tr>
        <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'> First Name </th>
        <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$first_name."</td>
        </tr>
        <tr>
        <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'> Last Name  </th>
        <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$last_name."</td>
        </tr>
        <tr>
        <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'> TFN  </th>
        <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$tfn."</td>
        </tr>
        <tr>
        <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'>Email</th>
        <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$email_id."</td>
        </tr>
        <tr>
        <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'>Phone Number </th>
        <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$phone_number."</td>
        </tr>
        <tr>
        <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'> D.O.B </th>
        <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$date_of_birth."</td>
        </tr>
        <tr>
        <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'>BSB </th>
        <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$bsb."</td>
        </tr>        
        <tr>
        <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'>Account </th>
        <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$account."</td>
        </tr>   
        <tr>
        <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'>Account Name </th>
        <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$accountname."</td>
        </tr>
        <tr>
        <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'>Residence Address: </th>
        <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$contact_residence_address."</td>
        </tr>   
        
         <tr>
        <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'>Postal Address:  </th>
        <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$postaladdress."</td>
        </tr>
         <tr>
        <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'>Are you Australian Citizen or PR ? </th>
        <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$australian_citizen."</td>
        </tr>   
          <tr>
        <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'>Your VISA Type : </th>
        <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$visa_type."</td>
        </tr>
        <tr>
        <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'>Do you have Medicare Card for the whole year ? </th>
        <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$medicare_card."</td>
        </tr>
        <tr>
        <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'> How many days you hold Medicare Card ?  </th>
        <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$medicare_card_hold_days."</td>
        </tr>
        <tr>
        <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'>Do you have Private Health Insurance </th>
        <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$private_health_insurance."</td>
        </tr> 
        <tr>
        <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'> Do you have Spouse ?</th>
        <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$spouse."</td>
        </tr>   
           <tr>
        <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'>Name </th>
        <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$spouse_name."</td>
        </tr>   
       <tr>
        <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'>Gender </th>
        <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$spouse_gender."</td>
        </tr>     
         
        <tr>
        <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'> Date of Birth </th>
        <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$spouse_date_of_birth."</td>
        </tr>   
         <tr>
        <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'>Yearly Taxable income </th>
        <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$spouse_yearly_taxable_income."</td>
        </tr>      
         <tr>
        <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'>Do you have Dependent Children ? </th>
        <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$dependent_children."</td>
        </tr>   
        <tr>
        <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'> No. of Children </th>
        <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$no_children."</td>
        </tr><tr>
        <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'> Do you have HECS/HELP debt or SFSS Debt ?</th>
        <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$help_debt."</td>
        </tr><tr>
        <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'>Amount </th>
        <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$help_debt_amount."</td>
        </tr>";        
        $message.= "</table>";  
        $headers = 'From: ETax<'.get_option('admin_email').'>'. "\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
        wp_mail( $to, $subject, $message, $headers );
        $emailSent = true;  */

      }

    }






    /* if(isset($_POST)){ 
    $typereturn=$_POST['typereturn']; 
    $tfn=$_POST['tfn']; 
    $name=$_POST['name']; 
    $phone=$_POST['phone']; 
    $email_id=$_POST['email_id']; 

    $contact_person=$_POST['contact_person']; 

    $img = $_POST['upload_file']; 
    //  echo $tfn ,$name, $phone,$email_id,  $contact_person,$img;

    $uploads = wp_upload_dir(); 
    $upload_dir=$uploads['basedir']; 
    $upload_dir1=$uploads['baseurl']; 

    $new_upload= $upload_dir."/upload_image/";  
    $new_upload1= $upload_dir1."/upload_image/";

    $file = $new_upload . $img ;
    $file1 = $new_upload1."".$img; 

    move_uploaded_file($file1, $img);


    $data = array(
    "tfn"=>$tfn,
    "name"=>$name,
    "email"=>$phone,
    "phone"=>$email_id,
    "contact_person"=>$contact_person,
    "attachment"=> $file1,
    "type_entity"=> $typereturn,

    );
    // echo "<pre>"; print_r($data); "</pre>";
    $insert = $wpdb->insert("wp_buaniess_return",$data);
    if($insert)
    {
    echo "1";
    }
    else
    {
    echo "2";
    }       
    } */
?>