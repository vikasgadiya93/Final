<?php
    /**
    Template Name: Individal_tax
    */
    get_header(); ?>
<style>
    #tab_click a:hover{
        background-color: #002776;
        color: #fff;
         border-bottom: 1px solid #eff4ff !important;
         cursor: text;
    }
    #tab_click a:focus{
        background-color: #002776;
        color: #fff;
        border-bottom: 1px solid #eff4ff !important;
        cursor: text;
    }
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script type="text/javascript" src="https://js.stripe.com/v2/"></script>
<div class="breadcrumb">
    <div class="container">
        <div class="row">
            <div class="col-sm-4">
                <h1><?php the_title(); ?></h1>
            </div>
            <div class="col-sm-8">
                <?php echo get_post_meta( get_the_ID(), 'breadcrumb_content', true ); ?>
            </div>
        </div>
    </div>
</div>   
<div class="tax_tab">
    <div class="container">
        <ul class="nav nav-tabs text_returntab nav-justified" id="tab_click" role="tablist">
            <li role="presentation" id="personal"  class="active"><a href="#Personalinfo" aria-controls="Personalinfo" role="tab" data-toggle="tab"> Personalinfo </a></li>
            <li role="presentation" ><a href="#Income" aria-controls="Income" role="tab" data-toggle="tab"> Income </a></li>
            <li role="presentation"><a href="#Deductions" aria-controls="Deductions" role="tab" data-toggle="tab"> Deductions </a></li>
            <li role="presentation" ><a href="#Busniess" aria-controls="Busniess" role="tab" data-toggle="tab">Busniess </a></li>
            <li role="presentation" ><a href="#Investment" aria-controls="Investment" role="tab" data-toggle="tab">Investment Property</a></li>
        </ul>
    </div>
</div>

<form action="" method="post" id="individal_tax_retun" class="individal_tax_retun" enctype="multipart/form-data">
    <div class="container">
        <div class="tab-content">
            <div id="sucess_msg"  style="display: none;">
                <div class="alert alert-success">
                    <strong>Success!</strong> your payment is succesfully.we will contact you as soon as possible
                </div>
            </div>
            <input type="hidden" name="stripeToken"  id="stripeToken" />
            <input type="hidden" name="amount"  id="amount" value="5900"/>
            <input type="hidden" name="currency"  id="currency" value="AUD"/>
            <div role="tabpanel" class="tab-pane active" id="Personalinfo">
               <div class="returntab_wrap">
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for="">Which Year of Tax Return you want to lodge ?</label>
                                <select class="form-control" name="year" id="year">
                                    <?php
                                     $present_year = date("Y");
                                    for($i=2001; $i <= $present_year; $i++){
                                        ?>
                                       <option value="<?php echo $i; ?>"><?php echo $i; ?></option>  
                                        <?php
                                    }
                                     ?>
                                    
                                </select>
                                
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for="">First name:</label>
                                <input id="first_name" name="first_name" placeholder="" class="form-control "  type="text">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for=""> Last name:</label>
                                <input id="last_name" name="last_name" placeholder="" class="form-control " type="text">

                            </div>
                        </div>
                    </div>


                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for="">TFN</label>
                                <input id="tfn" name="tfn" placeholder="" class="form-control "  type="text">

                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for="">   Date of Birth </label>
                                <input id="date_of_birth" name="date_of_birth" placeholder="" class="form-control " type="text">

                            </div>
                        </div>

                    </div>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for="">Your Contact Phone NO</label>
                                <input id="phone_number" name="phone_number" placeholder="" class="form-control " type="text">

                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for="">  Your Email Address</label>
                                <input id="email_id" name="email" placeholder="" class="form-control " type="text" onblur="return valEmail1();">
                                <span style="display: none" generated="true" class="errorAll field-validation-valid" id="txtEmail_error" for="txtEmail_error">&nbsp;</span> 

                            </div>
                        </div>
                    </div>
                    
                        <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for=""> Postal Address: ( if not same )</label>
                                <input id="postaladdress" name="postaladdress" placeholder="" class="form-control "  type="text">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for=""> Residence Address </label>
                                <input id="residence_address" name="residence_address" placeholder="" class="form-control "  type="text">
                            </div>
                        </div>

                    </div>
                      <div class="row">
                        <div class="col-sm-12">
                            <h4> Bank Details</h4>
                            
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for="">BSB</label>
                                <input id="bsb" name="bsb" placeholder="" class="form-control " type="text">

                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for=""> Account </label>
                                <input id="account" name="account" placeholder="" class="form-control "  type="text">
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for="">Account Name</label>
                                <input id="accountname" name="accountname" placeholder="" class="form-control "  type="text">
                            </div>
                        </div>
                        
                    </div>
 
                     <div class="row">
                        <div class="col-sm-12">
                            <h4> Citizenship Details</h4>   
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for="">  Are you Australian Citizen or PR ?</label>
                                <div class="row"> 
                                    <div class="col-sm-12">
                                        <label class="radio-inline" for="reqType-0">
                                            <input name="australian_citizen" id="australian_citizen" value="yes" type="radio" checked> Yes
                                        </label>
                                        <label class="radio-inline" for="reqType-1">
                                            <input name="australian_citizen" id="australian_citizen" value="no" type="radio"> No
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for=""> Your VISA Type </label>
                                <input id="visa_type" name="visa_type" placeholder="" class="form-control "  type="text">
                            </div>
                        </div>

                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                            <h4> Medicare Card Details</h4> 
                            
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for="">Do you have Medicare Card for the whole year ?</label>
                                <div class="row"> 
                                    <div class="col-sm-12">
                                        <label class="radio-inline" for="reqType-0">
                                            <input name="medicare_card" id="medicare_card" value="yes" checked type="radio"> Yes
                                        </label>
                                        <label class="radio-inline" for="reqType-1">
                                            <input name="medicare_card" id="medicare_card" value="no" type="radio"> No
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">

                                <label class=" control-label" for="">How many days you hold Medicare Card ?  </label>
                                <input id="medicare_card_hold_days" name="medicare_card_hold_days" placeholder="" class="form-control " type="text">
                            </div>
                        </div>

                    </div>
                   <div class="row">
                        <div class="col-sm-12">
                            <h4> Insurance Details</h4> 
                            
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for="">Do you have Private Health Insurance </label>
                                <div class="row"> 
                                    <div class="col-sm-12">
                                        <label class="radio-inline" for="reqType-0">
                                            <input name="private_health_insurance" id="private_health_insurance" value="yes" checked type="radio"> Yes
                                        </label>
                                        <label class="radio-inline" for="reqType-1">
                                            <input name="private_health_insurance" id="private_health_insurance" value="no" type="radio"> No
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                           
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                            <h4> Spouse Details</h4> 
                            
                        </div>
                    </div>
                     <div class="row">
                     <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for="">Do you have Spouse ?</label>
                                <div class="row"> 
                                    <div class="col-sm-12">
                                        <label class="radio-inline" for="reqType-0">
                                            <input name="spouse" id="spouse" value="yes" checked type="radio"> Yes
                                        </label>
                                        <label class="radio-inline" for="reqType-1">
                                            <input name="spouse" id="spouse" value="no" type="radio"> No
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                     </div>

                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for="">Name </label>
                                <input id="spouse_name" name="spouse_name" placeholder="" class="form-control "  type="text">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for=""> Gender </label>
                                <!--<input id="spouse_gender" name="spouse_gender" placeholder="" class="form-control "  type="text">-->
                                 <select class="form-control" name="spouse_gender" id="spouse_gender">
                                    <option value="Male">Male </option>
                                    <option value="Female">Female</option>
                                </select>
                            </div>
                        </div>
                    </div> 



                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for="">Date of Birth </label>
                                <input id="spouse_date_of_birth" name="spouse_date_of_birth" placeholder="" class="form-control "  type="text">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for=""> Yearly Taxable income </label>
                                <input id="spouse_yearly_taxable_income" name="spouse_yearly_taxable_income" placeholder="" class="form-control "  type="text">
                            </div>
                        </div>
                    </div> 
                   <div class="row">
                        <div class="col-sm-12">
                            <h4> Dependent Children Details</h4> 
                            
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for="">  Do you have Dependent Children ?</label>
                                <div class="row"> 
                                    <div class="col-sm-12">
                                        <label class="radio-inline" for="reqType-0">
                                            <input name="dependent_children" id="dependent_children" value="yes" checked type="radio"> Yes
                                        </label>
                                        <label class="radio-inline" for="reqType-1">
                                            <input name="dependent_children" id="dependent_children" value="no" type="radio"> No
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for=""> No. of Children </label>
                                <input id="no_children" name="no_children" placeholder="" class="form-control "  type="text">
                            </div>
                        </div>

                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                            <h4> HECS/HELP debt or SFSS Debt  Details</h4> 
                            
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for=""> Do you have HECS/HELP debt or SFSS Debt ?</label>
                                <div class="row"> 
                                    <div class="col-sm-12">
                                        <label class="radio-inline" for="reqType-0">
                                            <input name="help_debt" id="help_debt" value="yes" checked type="radio"> Yes
                                        </label>
                                        <label class="radio-inline" for="reqType-1">
                                            <input name="help_debt" id="help_debt" value="no" type="radio"> No
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for=""> Amount </label>
                                <input id="help_debt_amount" name="help_debt_amount" placeholder="" class="form-control "  type="text">
                            </div>
                        </div>

                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                        <div class="pull-right">
                            <a class="btn btn-primary btnNext" >Next</a> 
                        </div>
                       
                        </div>
                    </div>
                </div>        
            </div>      
            <div role="tabpanel" class="tab-pane " id="Income">
                <div class="returntab_wrap">

                    <div class="row">
                        <div class="col-sm-12">
                            <h3>  Salary and Wages Income</h3>
                            <h4>  Your major Job title</h4>
                        </div>
                    </div>
                    <div class="row">
                        <div id ="fieldList">
                            <div class="col-sm-3">
                                <div class="form-group">
                                    <label class=" control-label" for=""> ABN OF EMPLOYER </label>
                                    <input id="employer_name1" name="employer_name[]" placeholder="" class="form-control " type="text">

                                </div>
                            </div>


                            <div class="col-sm-3">
                                <div class="form-group">
                                    <label class=" control-label" for=""> PAYG Withold </label>
                                    <input id="payg_wihold1" name="payg_wihold[]" placeholder="" class="form-control "  type="text">


                                </div>
                            </div>
                            <div class="col-sm-3">
                                <div class="form-group">
                                    <label class=" control-label" for="">Gross wages </label>
                                    <input id="gross_wags1" name="gross_wags[]" placeholder="" class="form-control "  type="text">

                                </div>
                            </div>
                            <div class="col-sm-3">
                                <div class="form-group">
                                    <label class=" control-label" for=""> Allowance</label>
                                    <input id="allowance1" name="allowance[]" placeholder="" class="form-control "  type="text">               

                                </div>
                            </div>
                        </div>


                        <div class="col-sm-12">

                            <button  id="addMorejobsin_income" class="center-block  btn btn-primary">Add more Jobs</button>

                        </div>
                    </div>

                    <div class="row">
                        <div class="col-sm-12">
                            <h4>  Centerlink Income</h4>
                        </div>
                    </div>


                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for="">Have you received Centerlink Income ? </label>
                                <div class="row"> 
                                    <div class="col-sm-12">
                                        <label class="radio-inline" for="reqType-2">
                                            <input name="centerlink_income" id="centerlink_income" value="yes" checked type="radio"> Yes
                                        </label>
                                        <label class="radio-inline" for="reqType-3">
                                            <input name="centerlink_income" id="centerlink_income" value="no" type="radio"> No
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for=""> YES-please provide details  </label>
                                <input id="centerlink_income_details" name="centerlink_income_details" placeholder="" class="form-control "  type="text">

                            </div>
                        </div>

                    </div>


                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for="">PAYG Withold </label>
                                <input id="centerlink_income_payg_withold" name="centerlink_income_payg_withold" placeholder="" class="form-control "  type="text">

                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for=""> Centerlink Payment  </label>
                                <input id="centerlink_income_payment" name="centerlink_income_payment" placeholder="" class="form-control "  type="text">

                            </div>
                        </div>
                    </div> 


                    <div class="row">
                        <div class="col-sm-12">
                            <h4>  Bank income</h4>
                        </div>
                    </div> 


                    <div class="row">
                        <div class="col-sm-4">
                            <div class="form-group">
                                <label class=" control-label" for="">Bank interest income  </label>
                                <input id="bank_interest_received" name="bank_interest_received" placeholder="" class="form-control "  type="text">

                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="form-group">
                                <label class=" control-label" for="">Tax Withold  </label>
                                <input id="bank_interest_tax_withold" name="bank_interest_tax_withold" placeholder="" class="form-control "  type="text">
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="form-group">
                                <label class=" control-label" for="">Total Interest   </label>
                                <input id="bank_interest_total_interest" name="bank_interest_total_interest" placeholder="" class="form-control "  type="text">

                            </div>
                        </div>
                    </div>  



                    <div class="row">
                        <div class="col-sm-12">
                            <h4> Dividend Income </h4>
                        </div>
                    </div> 


                    <div class="row">
                        <div class="col-sm-4">
                            <div class="form-group">
                                <label class=" control-label" for="">Unfranked</label>
                                <input id="dividned_income_unfranked" name="dividned_income_unfranked" placeholder="" class="form-control "  type="text">
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="form-group">
                                <label class=" control-label" for="">Franked  </label>
                                <input id="dividned_income_franked" name="dividned_income_franked" placeholder="" class="form-control "  type="text">
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="form-group">
                                <label class=" control-label" for=""> Franking Credit    </label>

                                <input id="dividned_income_franked_credit" name="dividned_income_franked_credit" placeholder="" class="form-control "  type="text">
                            </div>
                        </div>
                    </div>  




                    <div class="row">
                        <div class="col-sm-12">
                            <h4>Other Income  </h4>
                        </div>
                    </div> 


                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for="">Other income (e.g. superannuation/PSI/ ESS share/) </label>

                                <input id="other_income" name="other_income" placeholder="" class="form-control "  type="text">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for=""> Other Income-Amount (e.g. superannuation/PSI/ ESS )
                                </label>

                                <input id="other_income_amount" name="other_income_amount" placeholder="" class="form-control "  type="text">
                            </div>
                        </div>

                    </div>  


                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for="">  Attach documnet (You can attach more then one file at a once)</label>
                                <input name="attach_document_income" type="file" class="form-control" id="attach_document_income" multiple >  

                            </div>
                        </div>
                    </div>     
                   <div class="row">
                        <div class="col-sm-12">
                           <div class="pull-right">
                            <a class="btn btn-primary btnPrevious" >Previous</a>
                            <a class="btn btn-primary btnNext">Next</a>
                           </div>
                            
                        </div>
                    </div>
                </div>

            </div>
            <div role="tabpanel" class="tab-pane " id="Deductions">
                <div class="returntab_wrap">
                    <div class="row">
                        <div class="col-sm-12">
                            <h4>   Work Related Car Expense </h4>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for=""> Claim method : </label>
                                <select class="form-control" name="claim_method_deduction" id="claim_method_deduction">
                                    <option value="">Select claim method </option>
                                    <option value="Cents per Kilo ">Cents per Kilo </option>
                                    <option value="Log Book Method">Log Book Method</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for="">KMs Travelled-<small> ( you can`t claim travel between home to work, you can only maximum claim 5000KM)</small> </label>
                                <input id="kms_travelled" name="kms_travelled" placeholder="" class="form-control "  type="text">

                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for=""> Your MV Engine Size  </label>
                                  <label class=" control-label" for="">  <small> -(for example 1.6L)</small> </label>
                                <input id="mv_engine_size" name="mv_engine_size" placeholder="" class="form-control"  type="text">

                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for="">Log Book Method amount  </label>
                                <input id="log_book_method_amount" name="log_book_method_amount" placeholder="" class="form-control "  type="text">

                            </div>
                        </div>
                       

                    </div>
                     <div class="row">
                        <div class="col-sm-12">
                            <h4> Uniform Expense  </h4>
                        </div>
                    </div>   
                     <div class="row"> 
                     <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for="">Uniform Expense   </label>
                                <input id="uniform_amount" name="uniform_amount" placeholder="" class="form-control "  type="text">
                            </div>
                        </div> 
                      </div> 
                    <div class="row">
                        <div class="col-sm-12">
                            <h4> Self -Education Expense  </h4>
                        </div>
                    </div> 


                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for="">Description</label>

                                <input id="self_education_description" name="self_education_description" placeholder="" class="form-control "  type="text">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for="">amount  </label>
                                <input id="self_education_amount" name="self_education_amount" placeholder="" class="form-control "  type="text">

                            </div>
                        </div>

                    </div>  




                    <div class="row">
                        <div class="col-sm-12">
                            <h4>Other  Expenses <small>(e.g computers Stationery mobile tools) please enter any other expenses you believe relevant with your job</small>   </h4>
                        </div>
                    </div> 

                    <div class="row">
                        <div id="fieldList_other_expense">
                            <div class="col-sm-4">
                                <div class="form-group">
                                    <label class=" control-label" for=""> Description </label>
                                    <input id="Other_expense_description1" name="Other_expense_description[]" placeholder="" class="form-control "  type="text">

                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="form-group">
                                    <label class=" control-label" for=""> % working related </label>
                                    <input id="Other_expense_per_working_related1" name="Other_expense_per_working_related[]" placeholder="" class="form-control "  type="text">

                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="form-group">
                                    <label class=" control-label" for=""> Amount </label>
                                    <input id="Other_expense_amount1" name="Other_expense_amount[]" placeholder="" class="form-control "  type="text">

                                </div>
                            </div>
                        </div>

                        <div class="col-sm-12">
                            <button id="addmore_other_expenses"  class="center-block  btn btn-primary">Add more Other Expenses</button>

                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                            <h4>Gifts or Donations   </h4>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for="">Description</label>

                                <input id="gifts_donations_description" name="gifts_donations_description" placeholder="" class="form-control "  type="text">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for="">amount  </label>
                                <input id="gifts_donations_amount" name="gifts_donations_amount" placeholder="" class="form-control "  type="text">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                            <h4>Tax Offsets </h4>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for="">Have you Received Single Parent Pay ? </label>


                                <div class="row"> 
                                    <div class="col-sm-12">
                                        <label class="radio-inline" for="reqType-2">
                                            <input name="Offsets_single_pay" id="Offsets_single_pay" value="yes" checked type="radio"> Yes
                                        </label>
                                        <label class="radio-inline" for="reqType-3">
                                            <input name="Offsets_single_pay" id="Offsets_single_pay" value="no" type="radio"> No
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class=" control-label" for="">Are you Living in Remote Area ? </label>
                                <div class="row"> 
                                    <div class="col-sm-12">
                                        <label class="radio-inline" for="reqType-2">
                                            <input name="Offsets_remote_area" id="Offsets_remote_area" value="yes" checked type="radio"> Yes
                                        </label>
                                        <label class="radio-inline" for="reqType-3">
                                            <input name="Offsets_remote_area" id="Offsets_remote_area" value="no" type="radio"> No
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class=" control-label" for="">IF YES : Please provide your Post Code </label>

                                <input id="offset_post_code" name="offset_post_code" placeholder="" class="form-control "  type="text">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for="">Anyother Offsets you may be entile but not sure please leave notes below  </label>
                                <textarea cols="4" rows="8"  class="form-control " name="offset_note" id="offset_notes" placeholder=""></textarea>

                            </div>

                        </div>

                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                           <div class="pull-right">
                            <a class="btn btn-primary btnPrevious" >Previous</a>
                            <a class="btn btn-primary btnNext">Next</a>
                           </div>
                            
                        </div>
                    </div>
                </div>
            </div>
            <div role="tabpanel" class="tab-pane  " id="Busniess">
                <div class="returntab_wrap">
                    <div class="row">
                          <div class="col-sm-6">
                               <div class="form-group">
                                  <label class=" control-label" for="">Do you have Busniess  Income ?</label>
                                
                                 
                                        <label class="radio-inline" for="reqType-0">
                                            <input name="businessincome_amount" id="businessincome_amount" value="3000"  type="radio"> Yes 
                                        </label>
                                     
                                             
                                        <label class="radio-inline" for="reqType-1">
                                            <input name="businessincome_amount" id="businessincome_amount" value="0" checked type="radio"> No
                                        </label>
                                     <h5><strong>(If you have business income,you have to pay Extra $30)</strong></h5>   
                                 </div>             
                                    
                                  
                              
                          </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for=""> Business name </label>
                                <input id="business_name" name="business_name" placeholder="" class="form-control "  type="text">
                            </div>
                            <div class="form-group">
                                <label class=" control-label" for="">  Busines activity </label>

                                <input id="business_activity" name="business_activity" placeholder="" class="form-control "  type="text">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for=""> Business address </label>

                                <textarea name="business_address" rows="5"  class="form-control " id="business_address" placeholder=""></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                            <h4> Business income</h4>
                        </div>
                    </div>
                    <div class="row">
                      <div class="col-sm-6">
                            <div class="form-group">
                              <label class=" control-label" for="">  Busines income </label>
                              <input id="business_income" name="business_income" placeholder="" class="form-control "  type="text">
                            </div>
                      </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                            <h4> Business Expense</h4>
                        </div>
                    </div>
                                      
                    <div class="row">
                      <div id="fieldList_busniess_expense">
                       <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for="">  Description  </label>

                                <input id="business_expans_des1" name="business_expans_des[]" placeholder="" class="form-control "  type="text">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for="">   Amount  </label>
                                <input id="business_exp_amount1" name="business_exp_amount[]" placeholder="" class="form-control "  type="text">
                            </div>
                        </div>
                        </div>
                        </div>
                         <div class="col-sm-12">
                            <button id="addmore_other_business_expenses"  class="center-block  btn btn-primary">Add more Other Expenses</button>
                        </div>

                    <!--<div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for="">  business_exp_stationery stationery  </label>

                                <input id="business_exp_stationery" name="business_exp_stationery" placeholder="" class="form-control "  type="text">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for="">   direct cost  </label>

                                <input id="business_exp_direct_cost" name="business_exp_direct_cost" placeholder="" class="form-control "  type="text">
                            </div>
                        </div>

                    </div>-->
                    <!--<div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for="">mobile</label>

                                <input id="business_exp_mobile" name="business_exp_mobile" placeholder="" class="form-control "  type="text">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for="">  travelling</label>

                                <input id="business_exp_travelling" name="business_exp_travelling" placeholder="" class="form-control "  type="text">
                            </div>
                        </div>
                    </div>-->

                    <!--<div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for=""> Other Expense </label>
                                <input id="business_exp_other_expense" name="business_exp_other_expense" placeholder="" class="form-control "  type="text">
                            </div>
                        </div>

                    </div>-->

                    
                    <div class="row">
                        <div class="col-sm-12">
                            <h4> Business losses  (if any)</h4>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for="">  ADo you have business loss in previous year ? </label>  
                                <div class="row"> 
                                    <div class="col-sm-12">
                                        <label class="radio-inline" for="reqType-0">
                                            <input name="busniess_loss_pre_year" id="busniess_loss_pre_year" value="yes" checked="checked" type="radio"> Yes
                                        </label>
                                        <label class="radio-inline" for="reqType-1">
                                            <input name="busniess_loss_pre_year" id="busniess_loss_pre_year" value="no" type="radio"> No
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for=""> if yes Your Carried Forward Loss is </label>
                                <input id="business_exp_forward_loss" name="business_exp_forward_loss" placeholder="" class="form-control "  type="text">
                            </div>
                        </div>
                       <div class="row">
                        <div class="col-sm-12">
                           <div class="pull-right">
                            <a class="btn btn-primary btnPrevious" >Previous</a>
                            <a class="btn btn-primary btnNext">Next</a>
                           </div>
                            
                        </div>
                    </div>
                    </div>
                </div>

            </div>
            <div role="tabpanel" class="tab-pane" id="Investment">
                <div class="returntab_wrap">
                    <div class="row">
                          <div class="col-sm-6">
                               <div class="form-group">
                                  <label class=" control-label" for="">Do you have Investment Property Income ?</label>
                                   
                                   
                                        <label class="radio-inline" for="reqType-0">
                                            <input name="investment_amount" id="investment_amount" value="3000"  type="radio"> Yes
                                        </label>
                                        <label class="radio-inline" for="reqType-1">
                                            <input name="investment_amount" id="investment_amount" value="0" checked type="radio"> No
                                        </label>
                                        <h5><strong>(If you have Investment Property income,you have to pay Extra $30)</strong></h5>   
                                  
                               </div>
                          </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                            <h4>  Investment property 1 </h4>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for=""> Address of investment property </label>
                                <textarea name="address_investment_property[]" rows="5"  class="form-control" id="address_investment_property1" placeholder=""></textarea>
                            </div>
                        </div>

                        
                    </div>
                     <div class="row">
                    <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for="">  Date property first earned rental income </label>
                                <input id="date_investment_property1" name="date_investment_property[]" placeholder="" class="form-control "  type="text">

                            </div> 
                        </div>
                        </div>
                    <div class="row">
                        <div class="col-sm-12">
                            <h4>Ownership details</h4>
                        </div>   
                    </div>   
                    <div class="row">
                        <div class="col-sm-6">
                        <div class="form-group">
                                <label class=" control-label" for=""> Ownership  Name 1 </label>
                                <input id="investment_first1" name="investment_first[]" placeholder="" class="form-control investment_first "  type="text">
                        </div>
                            
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for="">  Percentage Owner 1 </label>

                                <input id="investment_per_first1" name="investment_percentage_first[]" placeholder="" class="form-control "  type="text">
                            </div>
                        </div>

                    </div>

                    <div class="row">
                        <div class="col-sm-6">
                        <div class="form-group">
                                <label class=" control-label" for="">  Ownership  Name 2 </label>

                                <input id="investment_second1" name="investment_second[]" placeholder="" class="form-control "  type="text">
                            </div>
                            
                        </div>
                         <div class="col-sm-6">
                        <div class="form-group">
                                <label class=" control-label" for="">  Percentage Owner 2 </label>
                                <input id="investment_per_seocnd1" name="investment_percentage_secound[]" placeholder="" class="form-control "  type="text">
                            </div>
                      </div>

                    </div>
                     <div class="row">
                        <div class="col-sm-12">
                            <h4>Income Details</h4>
                        </div>   
                    </div>   
                    <div class="row">
                      <div class="col-sm-6">
                           <div class="form-group">
                                <label class=" control-label" for="">   Income Rental Income </label>

                                <input id="investment_rental_income1" name="investment_rental_income[]" placeholder="" class="form-control "  type="text">
                            </div>  
                        </div>
                     
                   
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for=""> Other Income (e.g Water Fees collected from tenants)</label>

                                <input id="investment_other_income1" name="investment_other_income[]" placeholder="" class="form-control "  type="text">
                            </div>
                        </div>
                        
                    </div>
                     <div class="row">
                        <div class="col-sm-12">
                            <h4>Expense Details</h4>
                        </div>   
                    </div>
                    <div class="row">
                      <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for="">   Advertising for tenants </label>
                                <input id="investment_advertising1" name="investment_advertising[]" placeholder="" class="form-control "  type="text">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for=""> Sundry  </label>
                                <input id="investment_sundry1" name="investment_sundry[]" placeholder="" class="form-control "  type="text">

                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for="">  Body corporate fees </label>
                                <input id="investment_body_corporate_fees1" name="investment_body_corporate_fees[]" placeholder="" class="form-control "  type="text">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for="">   Borrowing expenses  </label>
                                <input id="investment_borrowing_expenses1" name="investment_borrowing_expenses[]" placeholder="" class="form-control "  type="text">

                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for="">  Cleaning</label>
                                <input id="investment_cleaning1" name="investment_cleaning[]" placeholder="" class="form-control "  type="text">

                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for="">    Council rates   </label>
                                <input id="investment_council_rates1" name="investment_council_rates[]" placeholder="" class="form-control "  type="text">

                            </div>
                        </div>
                    </div>


                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for="">   Gardening </label> 
                                <input id="investment_gardening1" name="investment_gardening[]" placeholder="" class="form-control "  type="text">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for=""> Insurance   </label>

                                <input id="investment_insurance1" name="investment_insurance[]" placeholder="" class="form-control "  type="text">
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for="">   Interest </label>

                                <input id="investment_interest1" name="investment_interest[]" placeholder="" class="form-control "  type="text">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for="">  Land tax    </label>

                                <input id="investment_land_tax1" name="investment_land_tax[]" placeholder="" class="form-control "  type="text">
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for="">    Legal fees  </label>                            
                                <input id="investment_legal_fees1" name="investment_legal_fees[]" placeholder="" class="form-control "  type="text">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for="">   Pest control   </label>

                                <input id="investment_pest_control1" name="investment_pest_control[]" placeholder="" class="form-control "  type="text">
                            </div>
                        </div>
                    </div>


                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for="">    Agents fees  </label>

                                <input id="investment_agent_fee1" name="investment_agent_fee[]" placeholder="" class="form-control "  type="text">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for="">  Repairs  </label> 
                                <input id="investment_repairs1" name="investment_repairs[]" placeholder="" class="form-control "  type="text">
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for="">   Capital works deduction -Special building write off </label>

                                <input id="investment_capital_work1" name="investment_capital_work[]" placeholder="" class="form-control "  type="text">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for="">   Capital allowance assets   </label>

                                <input id="investment_capital_allowance1" name="investment_capital_allowance[]" placeholder="" class="form-control "  type="text">
                            </div>
                        </div>
                    </div>


                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for="">   Office supplies </label> 
                                <input id="investment_office_supplies1" name="investment_office_supplies[]" placeholder="" class="form-control "  type="text">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for=""> Travel  </label> 
                                <input id="investment_travel1" name="investment_travel[]" placeholder="" class="form-control "  type="text">
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class=" control-label" for="">  Water</label>
                                <input id="investment_water1" name="investment_water[]" placeholder="" class="form-control "  type="text">
                            </div>
                        </div>
                        
                    </div>

                    <div id="fieldList_investment">
                    </div>

                    <div class="row">
                        <div class="col-sm-12">
                            <div class="form-group">

                                <button id="addMoreinvestment_property" class="center-block  btn btn-primary "> add more investment property</button>

                            </div>
                        </div>



                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                        <div class="pull-left">
                            <a class="btn btn-primary btnPrevious" >Previous</a>
                           </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                            <input type="button" class="center-block  btn btn-Calculate"     value="Pay Now" name="save"  id="save" onclick="return validate_apply();"/>
                            <!--   <button class="center-block  btn btn-Calculate submit "> Pay Now</button>-->

                        </div>
                    </div>

                </div>
            </div>
        </div>

    </div>
</form>        





<?php /*   <form action="" method="post" id="individal_tax_retun" class="individal_tax_retun" enctype="multipart/form-data">

    <div class="tab-content">
    <div role="tabpanel" class="tab-pane active " id="personalinfo">
    <h4> <b>1</b> <span>Which Year of Tax Return you want to lodge ?</span> </h4>
    <input type="text" class="form-control" name="year" id="year"><br>

    <h4> <b>2</b> <span>First name:</span> </h4>
    <input type="text" class="form-control" name="first_name" id="first_name"><br>

    <h4> <b>3</b> <span>Last  name:</span> </h4>
    <input type="text" class="form-control" name="last_name" id="last_name"><br>

    <h4> <b>4</b> <span>TFN</span> </h4>
    <input type="text" class="form-control" name="tfn" id="tfn"><br>

    <h4> <b>5</b> <span>Date of Birth</span> </h4>
    <input type="text" class="form-control" name="date_of_birth" id="date_of_birth"><br>

    <h4> <b>6</b> <span>Your Contact Phone NO</span> </h4>
    <input type="text" class="form-control" name="phone_number" id="phone_number"><br>

    <h4> <b>7</b> <span>Your Email Address</span> </h4>
    <input type="text" class="form-control" name="email" id="email_id" onblur="return valEmail1();"><br> 
    <span style="display: none" generated="true" class="errorAll field-validation-valid" id="txtEmail_error" for="txtEmail_error">&nbsp;</span> 

    <h4> <b>8</b> <span>BSB:</span> </h4>
    <input type="text" class="form-control" name="bsb" id="bsb"><br>

    <h4> <b>9</b> <span>Account :</span> </h4>
    <input type="text" class="form-control" name="account" id="account"><br>

    <h4> <b>10</b> <span>Account Name :</span> </h4>
    <input type="text" class="form-control" name="accountname" id="accountname"><br>

    <h4> <b>11</b> <span>Residence Address:</span> </h4>
    <input type="text" class="form-control" name="residence_address" id="residence_address" ><br>

    <h4> <b>12</b> <span>Postal Address: ( if not same )</span> </h4>
    <input type="text" class="form-control" name="postaladdress" id="postaladdress"><br>



    <h4> <b>13</b> <span>Are you Australian Citizen or PR ?</span> </h4>
    <!--<input type="text" class="form-control" name="australian_citizen" id="australian_citizen">-->
    <input tabindex="3" class="" name="australian_citizen" id="australian_citizen" type="radio" value="yes" checked>Yes
    <input tabindex="3" class="" name="australian_citizen" id="australian_citizen" type="radio" value="no">No   

    <h4> <b>14</b> <span>Your VISA Type</span> </h4>
    <input type="text" class="form-control" name="visa_type" id="visa_type"><br>

    <h4> <b>15</b> <span>Do you have Medicare Card for the whole year ?</span> </h4>
    <input tabindex="3" class="" name="medicare_card" id="medicare_card" type="radio" value="yes"checked>Yes
    <input tabindex="3" class="" name="medicare_card" id="medicare_card" type="radio" value="no">No
    <!--<input type="text" class="form-control" name="medicare_card" id="medicare_card"><br>-->

    <h4> <b>16</b> <span>How many days you hold Medicare Card ? </span> </h4>
    <input type="text" class="form-control" name="medicare_card_hold_days" id="medicare_card_hold_days"><br>

    <h4> <b>17</b> <span>Do you have Private Health Insurance   </span> </h4>
    <input tabindex="3" class="" name="private_health_insurance" id="private_health_insurance" type="radio" value="yes"checked> Yes 
    <input tabindex="3" class="" name="private_health_insurance" id="private_health_insurance" type="radio" value="no"> No  
    <!--<input type="text" class="form-control" name="private_health_insurance" id="private_health_insurance"><br>-->

    <h4> <b>18</b> <span>Do you have Spouse ?</span> </h4>
    <input tabindex="3" class="" name="spouse" id="spouse" type="radio" value="yes"checked> Yes 
    <input tabindex="3" class="" name="spouse" id="spouse" type="radio" value="no">No   
    <!--<input type="text" class="form-control" name="spouse" id="spouse"><br>-->

    <h4> <b>19</b> <span>Name :</span> </h4>
    <input type="text" class="form-control" name="spouse_name" id="spouse_name"><br>

    <h4> <b>20</b> <span>Gender</span> </h4>
    <input type="text" class="form-control" name="spouse_gender" id="spouse_gender"><br>

    <h4> <b>21</b> <span>Date of Birth</span> </h4>
    <input type="text" class="form-control" name="spouse_date_of_birth" id="spouse_date_of_birth"><br><br />

    <h4> <b>22</b> <span>Yearly Taxable income</span> </h4>
    <input type="text" class="form-control" name="spouse_yearly_taxable_income" id="spouse_yearly_taxable_income"><br>

    <h4> <b>23</b> <span>Do you have Dependent Children ?</span> </h4>
    <input tabindex="3" class="" name="dependent_children" id="dependent_children" type="radio" value="yes"checked> Yes
    <input tabindex="3" class="" name="dependent_children" id="dependent_children" type="radio" value="no"> No 
    <!--<input type="text" class="form-control" name="dependent_children" id="dependent_children"><br>-->

    <h4> <b>24</b> <span>No. of Children</span> </h4>
    <input type="text" class="form-control" name="no_ children" id="no_ children"><br>

    <h4> <b>25</b> <span>Do you have HECS/HELP debt or SFSS Debt ?</span> </h4>
    <input tabindex="3" class="" name="help_debt" id="help_debt" type="radio" value="yes" checked>Yes  
    <input tabindex="3" class="" name="help_debt" id="help_debt" type="radio" value="no"> No 
    <!--<input type="text" class="form-control" name="help_debt" id="help_debt"><br>-->

    <h4> <b>26</b> <span>Amount </span> </h4>
    <input type="text" class="form-control" name="help_debt_amount" id="help_debt_amount"><br>
    </div>
    <div role="tabpanel" class="tab-pane" id="Inome">
    <h3>Salary and Wages Income</h3>

    <h4> <b>1</b> <span>Your major Job title</span> </h4>
    <div id="fieldList"> 
    <div class="col-sm-3">
    ABN OF EMPLOYER
    <input type="text" class="form-control" name="employer_name[]" id="employer_name1"><br>
    </div>
    <div class="col-sm-3">
    PAYG  Withold
    <input type="text" class="form-control" name="payg_wihold[]" id="payg_wihold1"><br>
    </div> 
    <div class="col-sm-3">
    Gross wages
    <input type="text" class="form-control" name="gross_wags[]" id="gross_wags1"><br>
    </div> 
    <div class="col-sm-3">
    Allowance
    <input type="text" class="form-control" name="allowance[]" id="allowance1"><br>
    </div>
    </div>
    <button id="addMorejobsin_income">Add more Jobs</button>  

    <h4> <b>2</b> <span> Centerlink Income</span> </h4>
    <div class="col-sm-12"> 
    <h4> <b>2.0 </b> <span>Have you received Centerlink Income ? </span> </h4>
    <input tabindex="3" class="" name="centerlink_income" id="centerlink_income" type="radio" value="yes"checked> Yes 
    <input tabindex="3" class="" name="centerlink_income" id="centerlink_income" type="radio" value="no">No
    <!-- <input type="text" class="form-control" name="centerlink_income" id="centerlink_income"><br><br />-->
    </div> 
    <div class="col-sm-4"> 
    <h4> <b>2.1</b> <span> YES-please provide details  </span> </h4>
    <input type="text" class="form-control" name="centerlink_income_details" id="centerlink_income_details"><br><br />
    </div>
    <div class="col-sm-4"> 
    <h4> <b>2.2</b> <span> PAYG  Withold  </span> </h4>    
    <input type="text" class="form-control" name="centerlink_income_payg_withold" id="centerlink_income_payg_withold"><br><br />
    </div>
    <div class="col-sm-4"> 
    <h4> <b>2.3</b> <span>Centerlink Payment  </span> </h4>    
    <input type="text" class="form-control" name="centerlink_income_payment" id="centerlink_income_payment"><br><br/>
    </div>

    <h4> <b>3</b> <span>Bank income</span> </h4>
    <div class="col-sm-4">  
    <h4> <b>3.1</b> <span>Bank interest income </span> </h4>
    <input type="text" class="form-control" name="bank_interest_received" id="bank_interest_received"><br><br />
    </div>
    <div class="col-sm-4">  
    <h4> <b>3.2</b> <span>Tax Withold   </span> </h4>
    <input type="text" class="form-control" name="bank_interest_tax_withold" id="bank_interest_tax_withold"><br><br />
    </div>
    <div class="col-sm-4">  
    <h4> <b>3.3</b> <span>Total Interest   </span> </h4> 
    <input type="text" class="form-control" name="bank_interest_total_interest" id="bank_interest_total_interest"><br><br /> 
    </div>


    <h4> <b>4</b> <span> Dividend Income </span> </h4>
    <div class="col-sm-4">  
    <h4> <b>4.1</b> <span>Unfranked </span> </h4>
    <input type="text" class="form-control" name="dividned_income_unfranked" id="dividned_income_unfranked"><br><br />
    </div>
    <div class="col-sm-4">  
    <h4> <b>4.2</b> <span>Franked   </span> </h4>
    <input type="text" class="form-control" name="dividned_income_franked" id="dividned_income_franked"><br><br />
    </div>
    <div class="col-sm-4">  
    <h4> <b>4.3</b> <span>Franking Credit   </span> </h4> 
    <input type="text" class="form-control" name="dividned_income_franked_credit" id="dividned_income_franked_credit"><br><br /> 
    </div>
    <h4> <b>5</b> <span> other  Income </span> </h4>   
    <div class="col-sm-6">  
    <h4> <b>5.1</b> <span>  Other income (e.g. superannuation/PSI/ ESS share/) </span> </h4>   
    <input type="text" class="form-control" name="other_income" id="other_income"><br><br /> 
    </div>
    <div class="col-sm-6">  
    <h4> <b>5.2</b>  Other Income-Amount (e.g. superannuation/PSI/ ESS ) </span> </h4>
    <input type="text" class="form-control" name="other_income_amount" id="other_income_amount"><br><br /> 
    </div>
    <h4> <b>5</b> <span>attach documnet </span> </h4>    
    <input type="file" class="form-control" name="attach_document_income" id="attach_document_income" multiple><br><br /> 
    </div>
    <div role="tabpanel" class="tab-pane" id="Deductions">
    <h4> <b>1</b>   D1 Work Related Car Expense </span> </h4>
    <h4> <b>1</b>Claim method : </span> </h4>
    <select class="form-control" name="claim_method_deduction" id="claim_method_deduction">
    <option value="">Select claim method </option>
    <option value="Cents per Kilo ">Cents per Kilo </option>
    <option value="Log Book Method">Log Book Method</option>
    </select>    
    <h4> <b>2</b>Cents per Kilo ( Most popular ) </span> </h4>
    <div class="row">
    <div class="col-sm-6">
    <h4> <b>3</b>KMs Travelled- ( you can`t claim travel between home to work, you can only maximum claim 5000KM </span> </h4>
    <input type="text" class="form-control" name="kms_travelled" id="kms_travelled"><br>
    </div>
    <div class="col-sm-6">
    <h4> <b>4</b>Your MV Engine Size </span> </h4>  
    <input type="text" class="form-control" name="mv_engine_size" id="mv_engine_size"><br>
    </div>   
    </div>   

    <h4> <b>5</b>Log Book Method </span> </h4>   
    <h5> <b>5.1</b>Log Book Method amount </span> </h5>   
    <input type="text" class="form-control" name="log_book_method_amount" id="log_book_method_amount"><br>

    <h4> <b>6</b>Uniform Expense </span> </h4>   
    <input type="text" class="form-control" name="uniform_amount" id="uniform_amount"><br>

    <h4> <b>7</b>Self -Education Expense</span> </h4>
    <div class="col-sm-6">
    Description  
    <input type="text" class="form-control" name="self_education_description" id="self_education_description"><br>
    </div>   
    <div class="col-sm-6">
    amount  
    <input type="text" class="form-control" name="self_education_amount" id="self_education_amount"><br>
    </div>
    <h4> <b>8</b>Other Expenses (e.g computers Stationery mobile tools) please enter any other expenses you believe relevant with your job</span> </h4>                                 
    <div id="fieldList_other_expense">  
    <div class="row">
    <div class="col-sm-3">  
    <h4> <b>8.1</b>Description </h4>
    <input type="text" class="form-control" name="Other_expense_description[]" id="Other_expense_description1"><br>
    </div> 
    <div class="col-sm-3">  
    <h4> <b>8.2</b>% working related </h4>
    <input type="text" class="form-control" name="Other_expense_per_working_related[]" id="Other_expense_per_working_related1"><br>
    </div>                         
    <div class="col-sm-3">  
    <h4> <b>8.3</b>Amount </h4>
    <input type="text" class="form-control" name="Other_expense_amount[]" id="Other_expense_amount1"><br>
    </div>     
    <div class="col-sm-3">
    <h4> add more </h4>  
    <button id="addmore_other_expenses">Other Expenses</button> 
    </div>     
    </div>
    </div>

    <h4> <b>9</b>Gifts or Donations </span> </h4>   
    <div class="col-sm-6">
    Description
    <input type="text" class="form-control" name="gifts_donations_description" id="gifts_donations_description"><br>
    </div>      
    <div class="col-sm-6">
    amount
    <input type="text" class="form-control" name="gifts_donations_amount" id="gifts_donations_amount"><br>
    </div>    
    <div class="col-sm-12"> 
    <h4> <b>10</b>Offsets   </span> </h4>    
    Have you Received Single Parent Pay ?
    <input tabindex="3" class="" name="Offsets_single_pay" id="Offsets_single_pay" type="radio" value="yes">
    <label for="id3"> Yes</label>
    <input tabindex="3" class="" name="Offsets_single_pay" id="Offsets_single_pay" type="radio" value="no">
    <label for="id3"> NO</label>
    </div>    
    <div class="col-sm-12"> 
    Are you Living in Remote Area ?

    <input tabindex="3" class="" name="Offsets_remote_area" id="Offsets_remote_area" type="radio" value="yes">
    <label for="id3"> Yes</label>
    <input tabindex="3" class="" name="Offsets_remote_area" id="Offsets_remote_area" type="radio" value="no">
    <label for="id3"> NO</label>
    </div>    
    <div class="col-sm-12">  
    IF YES : Please provide your Post Code
    <input type="text" class="form-control" name="offset_post_code" id="offset_post_code"><br>
    </div>    
    <div class="col-sm-12"> 
    Anyother Offsets you may be entile but not sure please leave notes below : 
    <textarea cols="40" rows="5" name="offset_note" id="offset_notes"> </textarea>
    </div>     





    </div>
    <div role="tabpanel" class="tab-pane" id="busniess">
    Business name   
    <input type="text" class="form-control" name="business_name" id="business_name"><br>
    Busines activity  
    <input type="text" class="form-control" name="business_activity" id="business_activity"><br>  
    Business address
    <input type="text" class="form-control" name="business_address" id="business_address"><br>
    <h4>Business Expense</h4>    business_exp_stationery
    stationery
    <input type="text" class="form-control" name="business_exp_stationery" id="business_exp_stationery"><br>
    direct cost
    <input type="text" class="form-control" name="business_exp_direct_cost" id="business_exp_direct_cost"><br>
    mobile
    <input type="text" class="form-control" name="business_exp_mobile" id="business_exp_mobile"><br>
    travelling
    <input type="text" class="form-control" name="business_exp_travelling" id="business_exp_travelling"><br>
    Other Expense
    <input type="text" class="form-control" name="business_exp_other_expense" id="business_exp_other_expense"><br>

    Do you have business loss in previous year ?
    <input tabindex="3" class="" name="busniess_loss_pre_year" id="busniess_loss_pre_year" type="radio" value="yes">
    <label for="id3"> Yes</label>
    <input tabindex="3" class="" name="busniess_loss_pre_year" id="busniess_loss_pre_year" type="radio" value="no">
    <label for="id3"> NO</label>
    if yes
    Your Carried Forward Loss is
    <input type="text" class="form-control" name="business_exp_forward_loss" id="business_exp_forward_loss"><br>

    </div>       
    <div role="tabpanel" class="tab-pane" id="investment">
    <div id="fieldList_investment">
    <h4> <b></b>Investment property 1 </span> </h4>
    <label> Address of investment property</label>
    <input type="text" class="form-control" name="address_investment_property[]" id="address_investment_property1"><br>
    <label>  Date property first earned rental income  </label>
    <input type="text" class="form-control" name="date_investment_property[]" id="date_investment_property1"><br>

    <label> Ownership name </label>
    <label> Name </label>
    <input type="text" class="form-control invetsment_first" name="investment_first[]" id="investment_first1" ><br>

    <input type="text" class="form-control" name="investment_second[]" id="investment_second1"><br> 
    <label> Percentage</label>
    <input type="text" class="form-control" name="investment_percentage_first[]" id="investment_per_first1"><br>
    <input type="text" class="form-control" name="investment_percentage_secound[]" id="investment_per_seocnd1"><br>

    <label>  Income</label> 
    <label>  Rental Income </label>
    <input type="text" class="form-control" name="investment_rental_income[]" id="investment_rental_income1"><br> 
    <label> Other Income (e.g Water Fees collected from tenants)</label>  
    <input type="text" class="form-control" name="investment_other_income[]" id="investment_other_income1"><br> 
    <label> Advertising for tenants </label>
    <input type="text" class="form-control" name="investment_advertising[]" id="investment_advertising1"><br> 
    <label> Body corporate fees </label>
    <input type="text" class="form-control" name="investment_body_corporate_fees[]" id="investment_body_corporate_fees1"><br>  
    <label> Borrowing expenses </label>
    <input type="text" class="form-control" name="investment_borrowing_expenses[]" id="investment_borrowing_expenses1"><br> 
    <label>  Cleaning  </label>
    <input type="text" class="form-control" name="investment_cleaning[]" id="investment_cleaning1"><br> 
    <label>  Council rates </label>
    <input type="text" class="form-control" name="investment_council_rates[]" id="investment_council_rates1"><br> 
    <label> Gardening  </label>
    <input type="text" class="form-control" name="investment_gardening[]" id="investment_gardening1"><br> 
    <label> Insurance   </label>
    <input type="text" class="form-control" name="investment_insurance[]" id="investment_insurance1"><br> 
    <label> Interest    </label>
    <input type="text" class="form-control" name="investment_interest[]" id="investment_interest1"><br> 
    <label> Land tax    </label>
    <input type="text" class="form-control" name="investment_land_tax[]" id="investment_land_tax1"><br> 
    <label>  Legal fees  </label>
    <input type="text" class="form-control" name="investment_legal_fees[]" id="investment_legal_fees1"><br> 
    <label>  Pest control </label>
    <input type="text" class="form-control" name="investment_pest_control[]" id="investment_pest_control1"><br> 
    <label>   Agents fees </label>
    <input type="text" class="form-control" name="investment_agent_fee[]" id="investment_agent_fee1"><br> 
    <label>  Repairs  </label>
    <input type="text" class="form-control" name="investment_repairs[]" id="investment_repairs1"><br> 
    <label>  Capital works deduction -Special building write off</label>
    <input type="text" class="form-control" name="investment_capital_work[]" id="investment_capital_work1"><br> 
    <label>    Capital allowance assets </label>
    <input type="text" class="form-control" name="investment_capital_allowance[]" id="investment_capital_allowance1"><br> 
    <label>   Office supplies  </label>
    <input type="text" class="form-control" name="investment_office_supplies[]" id="investment_office_supplies1"><br> 
    <label>    Travel </label>
    <input type="text" class="form-control" name="investment_travel[]" id="investment_travel1"><br> 
    <label>   Water </label>
    <input type="text" class="form-control" name="investment_water[]" id="investment_water1"><br> 
    <label>   Sundry </label>
    <input type="text" class="form-control" name="investment_sundry[]" id="investment_sundry1"><br> 
    </div>
    <button id="addMoreinvestment_property"> add more investment property</button>
    <input type="button" class="center-block  btn btn-Calculate"     value="Pay Now" name="save"  id="save" onclick="return validate_apply();"/>
    </div>
    </div> 
</form>   */  ?>

<div id="myModal" class="modal" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Etax Tax Return</h4>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-lg-12">
                            <label class="control-label" style="color:#002d89 ;">Total price -  </label>
                            <label class="control-label" style="color:#060 ;">$</label>
                            <label id="pop_finalvalue" class="control-label" style="color:#060 ;"></label>

                        <div class="form-group">
                            <label class="control-label">Email </label>
                            <input type="email" class="form-control" id="email" size="20" data-stripe="email" onblur="return valEmail2();">
                            <span id="email_error"></span>
                        </div>
                        <div class="form-group ">

                            <label class="control-label"> Card Number <span class="payment-icon"><img src="<?php bloginfo('template_url'); ?>/images/icons/payment-icon.png"></span>   </label>
                            <!--<input class="form-control" size="4" type="text">-->
                            <input class="form-control" type="text" maxlength="16" id="card_number" size="20" data-stripe="number" onblur="return valcardnumber();"> 
                            <span id="cardnumber_error"></span>
                        </div>

                        <div class="row">
                            <div class="col-sm-8">
                                <div class="form-group ">

                                    <label class="control-label">Expiration  (MM/YY)  </label>
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <!--<input class="form-control" size="4" type="text">-->
                                            <input class="form-control" type="text" maxlength="2" id="exp_month" size="2" data-stripe="exp_month" onblur="return valexpiration_month();">
                                            <span id="exp_month_error"></span>

                                        </div>  <div class="col-sm-6">
                                            <!-- <input class="form-control" size="4" type="text">-->
                                            <input class="form-control" type="text" maxlength="2"  id="exp_year" size="2" data-stripe="exp_year" onblur="return valexpiration_year();">
                                            <span id="exp_year_error"></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="form-group ">

                                    <label class="control-label">CVV <span class="cvv-icon"><img src="<?php bloginfo('template_url'); ?>/images/icons/cvv-icon.png"></span></label>
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <!-- <input  size="4" type="text">-->
                                            <input class="form-control" type="text" id="cvc" maxlength="3" size="4" data-stripe="cvc" onblur="return valcvc();">
                                            <span id="cvc_error"></span>
                                        </div>  
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="get_error" id="get_error"></div>
                        <div class="get_error1" id="get_error1"></div>
                        <div class="loader">
                            <input class="btn btn-Calculate submit" id="payment" value="Pay Now" onclick="return validate_payment();" type="button">   
                            <img id="loading-image" src="<?php bloginfo('template_url'); ?>/images/icons/animatedEllipse.gif" style="display:none;"/>  
                        </div>
                    </div>
                    <div class="get_error" id="get_error"></div>
                    <div class="get_error1" id="get_error1"></div>
                </div>
            </div>
        </div>
    </div>
</div>    
<script >
$('.btnNext').click(function(){ 
       $('.nav-tabs > .active').next('li').find('a').trigger('click');
        });
$('.btnPrevious').click(function(){
        $('.nav-tabs > .active').prev('li').find('a').trigger('click');
   
   
});
</script >
<script >
    $(function() {
        var maxField = 5;
        var x = 1;
        var id = 2; 
        var num = 2;
        $("#fieldList_investment").append("");   
        $("#addMoreinvestment_property").click(function(e) {                                                  
            e.preventDefault();
            if(x < maxField){ 
                x++;   
                $("#fieldList_investment").append("<div class='row'><div class='col-sm-12'><h4>  Investment property "+id+" </h4></div></div><div class='row'><div class='col-sm-6'><div class='form-group'><label class=' control-label' for=''> Address of investment property </label><textarea name='address_investment_property[]' rows='5'  class='form-control' id='address_investment_property"+id+"' placeholder=''></textarea></div></div></div><div class='row'><div class='col-sm-6'><div class='form-group'><label class=' control-label' for=''>  Date property first earned rental income </label><input id='date_investment_property"+id+"' name='date_investment_property[]' placeholder='' class='form-control '  type='text'></div> </div></div><div class='row'><div class='col-sm-12'><h4>Ownership details</h4></div> </div><div class='row'><div class='col-sm-6'><div class='form-group'><label class=' control-label' for=''> Ownership  Name 1 </label><input id='investment_first"+id+"' name='investment_first[]' placeholder='' class='form-control investment_first '  type='text'></div></div><div class='col-sm-6'><div class='form-group'><label class=' control-label' for=''>  Percentage Owner 1  </label><input id='investment_per_first"+id+"' name='investment_percentage_first[]' placeholder='' class='form-control '  type='text'></div></div></div><div class='row'><div class='col-sm-6'><div class='form-group'><label class=' control-label' for=''>  Ownership  Name 2 </label><input id='investment_second"+id+"' name='investment_second[]' placeholder='' class='form-control '  type='text'></div></div><div class='col-sm-6'><div class='form-group'><label class=' control-label' for=''>  Percentage Owner 2 </label><input id='investment_per_seocnd"+id+"' name='investment_percentage_secound[]' placeholder='' class='form-control '  type='text'></div></div></div><div class='row'><div class='col-sm-12'><h4>Income Details</h4></div></div><div class='row'><div class='col-sm-6'><div class='form-group'><label class=' control-label' for=''>   Income Rental Income </label><input id='investment_rental_income"+id+"' name='investment_rental_income[]' placeholder='' class='form-control '  type='text'></div></div><div class='col-sm-6'><div class='form-group'><label class=' control-label' for=''> Other Income (e.g Water Fees collected from tenants)</label><input id='investment_other_income"+id+"' name='investment_other_income[]' placeholder='' class='form-control '  type='text'></div></div></div><div class='row'><div class='col-sm-12'><h4>Expense Details</h4></div></div><div class='row'><div class='col-sm-6'><div class='form-group'><label class=' control-label' for=''>   Advertising for tenants </label><input id='investment_advertising"+id+"' name='investment_advertising[]' placeholder='' class='form-control '  type='text'></div></div><div class='col-sm-6'><div class='form-group'><label class=' control-label' for=''> Sundry  </label><input id='investment_sundry"+id+"' name='investment_sundry[]' placeholder='' class='form-control '  type='text'></div></div></div><div class='row'><div class='col-sm-6'><div class='form-group'><label class=' control-label' for=''>  Body corporate fees </label><input id='investment_body_corporate_fees"+id+"' name='investment_body_corporate_fees[]' placeholder='' class='form-control '  type='text'></div></div><div class='col-sm-6'><div class='form-group'><label class=' control-label' for=''>   Borrowing expenses  </label><input id='investment_borrowing_expenses"+id+"' name='investment_borrowing_expenses[]' placeholder='' class='form-control '  type='text'></div></div></div><div class='row'><div class='col-sm-6'> <div class='form-group'><label class=' control-label' for=''>  Cleaning</label><input id='investment_cleaning"+id+"' name='investment_cleaning[]' placeholder='' class='form-control '  type='text'></div></div><div class='col-sm-6'><div class='form-group'><label class=' control-label' for=''>    Council rates   </label><input id='investment_council_rates"+id+"' name='investment_council_rates[]' placeholder='' class='form-control '  type='text'> </div></div></div> <div class='row'> <div class='col-sm-6'><div class='form-group'><label class=' control-label' for=''>   Gardening </label> <input id='investment_gardening"+id+"' name='investment_gardening[]' placeholder='' class='form-control '  type='text'> </div>   </div><div class='col-sm-6'><div class='form-group'><label class=' control-label' for=''> Insurance   </label><input id='investment_insurance"+id+"' name='investment_insurance[]' placeholder='' class='form-control '  type='text'></div></div></div><div class='row'><div class='col-sm-6'><div class='form-group'><label class=' control-label' for=''>   Interest </label><input id='investment_interest"+id+"' name='investment_interest[]' placeholder='' class='form-control '  type='text'></div></div><div class='col-sm-6'><div class='form-group'><label class=' control-label' for=''>  Land tax    </label><input id='investment_land_tax"+id+"' name='investment_land_tax[]' placeholder='' class='form-control '  type='text'></div></div></div><div class='row'><div class='col-sm-6'><div class='form-group'><label class=' control-label' for=''>    Legal fees  </label><input id='investment_legal_fees"+id+"' name='investment_legal_fees[]' placeholder='' class='form-control '  type='text'></div></div><div class='col-sm-6'><div class='form-group'><label class=' control-label' for=''>   Pest control   </label><input id='investment_pest_control"+id+"' name='investment_pest_control[]' placeholder='' class='form-control '  type='text'></div></div></div><div class='row'><div class='col-sm-6'><div class='form-group'><label class=' control-label' for=''>    Agents fees  </label><input id='investment_agent_fee"+id+"' name='investment_agent_fee[]' placeholder='' class='form-control '  type='text'></div></div><div class='col-sm-6'><div class='form-group'><label class=' control-label' for=''>  Repairs  </label> <input id='investment_repairs"+id+"' name='investment_repairs[]' placeholder='' class='form-control '  type='text'></div></div></div> <div class='row'> <div class='col-sm-6'> <div class='form-group'> <label class=' control-label' for=''>   Capital works deduction -Special building write off </label><input id='investment_capital_work"+id+"' name='investment_capital_work[]' placeholder='' class='form-control '  type='text'></div></div><div class='col-sm-6'><div class='form-group'> <label class=' control-label' for=''>   Capital allowance assets   </label><input id='investment_capital_allowance"+id+"' name='investment_capital_allowance[]' placeholder='' class='form-control '  type='text'></div></div></div><div class='row'><div class='col-sm-6'><div class='form-group'><label class=' control-label' for=''>   Office supplies </label> <input id='investment_office_supplies"+id+"' name='investment_office_supplies[]' placeholder='' class='form-control '  type='text'></div></div><div class='col-sm-6'><div class='form-group'><label class=' control-label' for=''> Travel  </label><input id='investment_travel"+id+"' name='investment_travel[]' placeholder='' class='form-control '  type='text'></div></div></div><div class='row'><div class='col-sm-6'><div class='form-group'><label class=' control-label' for=''>  Water</label><input id='investment_water"+id+"' name='investment_water[]' placeholder='' class='form-control ' type='text'></div></div></div>");
                id++;
                num++;
            } else if(x = maxField){
                $("#addMoreinvestment_property").hide();                                                  
            }
        });
    });
</script>   
<script >
    $(function() {
        var maxField = 7;
        var x = 1;
        var id = 2;
        $("#addmore_other_business_expenses").click(function(e) {                                                  
            e.preventDefault();
            if(x < maxField){ 
                x++;
                
                 
                $("#fieldList_busniess_expense").append("<div class='col-sm-6'><div class='form-group'><input type='text' class='form-control' name='business_expans_des[]' id='business_expans_des"+id+"'></div></div>"); 
                $("#fieldList_busniess_expense").append("<div class='col-sm-6'><div class='form-group'><input type='text' class='form-control' name='business_exp_amount[]' id='business_exp_amount"+id+"'></div></div>");
            
               
                id++;
            } 
            else if(x = maxField){
                $("#addmore_other_business_expenses").hide();                                                  
            }
        });
    });
</script>
<!--<script >
$(function() {
var maxField = 5;
var x = 1;
var id = 2;
$("#addMoreinvestment_property").click(function(e) {                                                  
e.preventDefault();
if(x < maxField){ 
x++;
$("#fieldList_investment").append("<div class='col-sm-3'><input type='text' class='form-control' name='employer_name[]' id='employer_name"+id+"'><br></div>"); 
$("#fieldList_investment").append("<div class='col-sm-3'><input type='text' class='form-control' name='payg_wihold[]' id='payg_wihold"+id+"'><br></div>");
$("#fieldList_investment").append("<div class='col-sm-3'><input type='text' class='form-control' name='gross_wags[]' id='gross_wags"+id+"'><br></div>");
$("#fieldList_investment").append("<div class='col-sm-3'><input type='text' class='form-control' name='allowance[]' id='allowance"+id+"'><br></div>");
id++;
}
});
});
</script>    -->
<script >
    $(function() {
        var maxField = 5;
        var x = 1;
        var id = 2;
        $("#addMorejobsin_income").click(function(e) {                                                  
            e.preventDefault();
            if(x < maxField){ 
                x++;
                $("#fieldList").append("<div class='col-sm-3'><input type='text' class='form-control' name='employer_name[]' id='employer_name"+id+"'><br></div>"); 
                $("#fieldList").append("<div class='col-sm-3'><input type='text' class='form-control' name='payg_wihold[]' id='payg_wihold"+id+"'><br></div>");
                $("#fieldList").append("<div class='col-sm-3'><input type='text' class='form-control' name='gross_wags[]' id='gross_wags"+id+"'><br></div>");
                $("#fieldList").append("<div class='col-sm-3'><input type='text' class='form-control' name='allowance[]' id='allowance"+id+"'><br></div>");
                id++;
            }
            else if(x = maxField){
                $("#addMorejobsin_income").hide();                                                  
            }
        });
    });
</script> 
<script >
    $(function() {
        var maxField = 5;
        var x = 1;
        var id = 2;
        $("#addmore_other_expenses").click(function(e) {                                                  
            e.preventDefault();
            if(x < maxField){ 
                x++;
                $("#fieldList_other_expense").append("<div class='col-sm-4'><input type='text' class='form-control' name='Other_expense_description[]' id='Other_expense_description"+id+"'><br></div>"); 
                $("#fieldList_other_expense").append("<div class='col-sm-4'><input type='text' class='form-control' name='Other_expense_per_working_related[]' id='Other_expense_per_working_related"+id+"'><br></div>");
                $("#fieldList_other_expense").append("<div class='col-sm-4'><input type='text' class='form-control' name='Other_expense_amount[]' id='Other_expense_amount"+id+"'><br></div>");

                id++;
            } 
            else if(x = maxField){
                $("#addmore_other_expenses").hide();                                                  
            }
        });
    });
</script>
<script type="text/javascript">
    Stripe.setPublishableKey('pk_test_6vLHj0BFQGiRouThtbBH2Lel');
</script>            
<script>
    function validate_apply() {
        var status = true;
        if(valEmail1() == false){
            status = false;
        }
        /* if(valinvestment_first() == false){
        status = false;
        }      */
        if(status == false){    
            return status;
        }else{
            var amount =$("#amount").val();
            var investment_amount = $('input[name=investment_amount]:checked').val();
            var businessincome_amount = $('input[name=businessincome_amount]:checked').val();
            var final_aomunt_1 =  parseFloat(investment_amount) + parseFloat(businessincome_amount) + parseFloat(amount);
            var final_aomunt_2 = final_aomunt_1 / 100 ;
            $("#pop_finalvalue").html(final_aomunt_2);
            jQuery("#myModal").modal('show');
        }
    }
    function valEmail1() {
        var email = jQuery("#email_id").val();
        var reg_email = /^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/;
        if(email == '') {
            /*jQuery("#email_id").css("border","1px solid red"); 
            jQuery("#txtEmail_error").css("display","");
            jQuery("#txtEmail_error").html('Please enter email');*/
            jQuery("#email_id").css("border","1px solid #ccc"); 
            jQuery("#txtEmail_error").css("display","none");
            return true; 
        }
        else if(!reg_email.test(email)) {
            jQuery("#email_id").css("border","1px solid red");
            jQuery("#personal a").css("color","#FF0000");   
            jQuery("#txtEmail_error").css("display","");
            jQuery("#txtEmail_error").html('Please enter valid email');
            return false; 
        }
        else {  
            jQuery("#email_id").css("border","1px solid #ccc");
            jQuery("#personal a").css("color","#002776");    
            jQuery("#txtEmail_error").css("display","none");
            return true;   
        }
    }
    /*  function valinvestment_first() {
    var invetsment_first = $("input[name='investment_first[]']").length ; 
    alert(invetsment_first);
    //   var invetsment_first = jQuery(".invetsment_first").length;
    // var x;
    // alert(invetsment_first);
    for (var x = 1; x <= invetsment_first; x++) {
    //    var invetsment_first =  $("#investment_first"+x).val();


    if(invetsment_first == '') {

    jQuery("#investment_first"+x).css("border","1px solid red"); 
    jQuery(".invetsment_first_error").css("display","");
    jQuery(".invetsment_first_error").html('Please Owner Name ');
    return false; 
    }
    else {  
    jQuery("#investment_first"+x).css("border","1px solid #ccc"); 
    jQuery(".invetsment_first_error").css("display","none");
    return true;   
    }


    } 
    }    */
</script>           
<script>
    function validate_payment() {

        var status = true;
        if(valcvc() == false){
            status = false;
        }
        if(valexpiration_year() == false){
            status = false;
        }  
        if(valexpiration_month() == false){
            status = false;
        }   
        if(valcardnumber() == false){
            status = false;
        }
        if(valEmail2() == false){
            status = false;
        }   
        if(status == false){    

            return status;

        }else{


            var email =$("#email").val();   
            var card_number =$("#card_number").val();   
            var exp_month =$("#exp_month").val();   
            var exp_year =$("#exp_year").val();   
            var cvc =$("#cvc").val();   

            Stripe.createToken({
                name: email,
                number: card_number,
                cvc: cvc,
                exp_month:exp_month ,
                exp_year: exp_year
            }, stripeResponseHandler);
            function stripeResponseHandler(status, response) {

                if (response.error) {
                    // re-enable the submit button
                    $('.submit-button').removeAttr("disabled");
                    // show the errors on the form
                    $("#get_error1").html(response.error.message);
                } else {
                    var token = response['id'];
                    var year =$("#year").val();
                    var first_name =$("#first_name").val();
                    var last_name =$("#last_name").val();
                    var tfn =$("#tfn").val();
                    var date_of_birth =$("#date_of_birth").val();
                    var phone_number =$("#phone_number").val();
                    var email =$("#email_id").val();
                    var bsb =$("#bsb").val();
                    var account =$("#account").val();
                    var accountname =$("#accountname").val();
                    var residence_address =$("#residence_address").val();
                    var postaladdress =$("#postaladdress").val();
                   // var australian_citizen =$("#australian_citizen").val(); 
                    var australian_citizen = $('input[name=australian_citizen]:checked').val(); 
                    var visa_type =$("#visa_type").val();
                 //   var medicare_card =$("#medicare_card").val();
                    var medicare_card = $('input[name=medicare_card]:checked').val(); 
                    var medicare_card_hold_days =$("#medicare_card_hold_days").val();
                   // var private_health_insurance =$("#private_health_insurance").val();
                    var private_health_insurance = $('input[name=private_health_insurance]:checked').val(); 
                    var spouse = $('input[name=spouse]:checked').val(); 
                //    var spouse =$("#spouse").val();
                    var spouse_name =$("#spouse_name").val();
                    var spouse_gender =$("#spouse_gender").val();
                    var spouse_date_of_birth =$("#spouse_date_of_birth").val();
                    var spouse_yearly_taxable_income =$("#spouse_yearly_taxable_income").val();
                  //  var dependent_children =$("#dependent_children").val();
                    var dependent_children = $('input[name=dependent_children]:checked').val(); 
                    var no_children =$("#no_children").val();
                    var help_debt = $('input[name=help_debt]:checked').val(); 
                 //   var help_debt =$("#help_debt").val();
                    var help_debt_amount =$("#help_debt_amount").val();



                    // inocme filed values
                    var centerlink_income = $('input[name=centerlink_income]:checked').val(); 
                   // var centerlink_income = $("#centerlink_income").val();
                    var centerlink_income_details = $("#centerlink_income_details").val();
                    var centerlink_income_payg_withold = $("#centerlink_income_payg_withold").val();
                    var centerlink_income_payment = $("#centerlink_income_payment").val();
                    var bank_interest_received = $("#bank_interest_received").val();
                    var bank_interest_tax_withold = $("#bank_interest_tax_withold").val();
                    var bank_interest_total_interest = $("#bank_interest_total_interest").val();
                    var dividned_income_unfranked = $("#dividned_income_unfranked").val();
                    var dividned_income_franked = $("#dividned_income_franked").val();
                    var dividned_income_franked_credit = $("#dividned_income_franked_credit").val();
                    var other_income = $("#other_income").val();
                    var other_income_amount = $("#other_income_amount").val();
                    // var attach_document_income = $("#attach_document_income").val();  

                    // for deduction income      
                    var claim_method_deduction = $("#claim_method_deduction").val();
                    var kms_travelled = $("#kms_travelled").val();
                    var mv_engine_size = $("#mv_engine_size").val();
                    var log_book_method_amount = $("#log_book_method_amount").val();
                    var uniform_amount = $("#uniform_amount").val();
                    var self_education_description = $("#self_education_description").val();
                    var self_education_amount = $("#self_education_amount").val(); 
                    var gifts_donations_description = $("#gifts_donations_description").val();
                    var gifts_donations_amount = $("#gifts_donations_amount").val();
                   // var Offsets_single_pay = $("#Offsets_single_pay").val();
                    var Offsets_single_pay = $('input[name=Offsets_single_pay]:checked').val(); 
                    var Offsets_remote_area = $('input[name=Offsets_remote_area]:checked').val(); 
                    var offset_post_code = $("#offset_post_code").val();
                    var offset_notes = $("#offset_notes").val();



                    // business values 
                    var business_name = $("#business_name").val();
                    var business_activity = $("#business_activity").val();
                    var business_address = $("#business_address").val();
                    var business_income = $("#business_income").val();
                //    var business_exp_stationery = $("#business_exp_stationery").val();
                 //   var business_exp_direct_cost = $("#business_exp_direct_cost").val();
                  //  var business_exp_mobile = $("#business_exp_mobile").val();
                   // var business_exp_travelling = $("#business_exp_travelling").val();
                  //  var business_exp_other_expense = $("#business_exp_other_expense").val();
                  //  var busniess_loss_pre_year = $("#busniess_loss_pre_year").val();
                    var busniess_loss_pre_year = $('input[name=busniess_loss_pre_year]:checked').val(); 
                    var business_exp_forward_loss = $("#business_exp_forward_loss").val();
                    
                    var amount =$("#amount").val();
            
            var investment_amount = $('input[name=investment_amount]:checked').val();
            
            var businessincome_amount = $('input[name=businessincome_amount]:checked').val();
            var final_aomunt =  parseFloat(investment_amount) + parseFloat(businessincome_amount) + parseFloat(amount);
                   
                   
                   
                    var currency =$("#currency").val(); 

                    var post_data = new FormData();  
                    post_data.append( 'year', year );
                    post_data.append( 'first_name', first_name );
                    post_data.append( 'last_name',last_name );
                    post_data.append( 'tfn',tfn );
                    post_data.append( 'phone_number',phone_number );
                    post_data.append( 'email_id',email );
                    post_data.append( 'date_of_birth',date_of_birth );
                    post_data.append( 'bsb',bsb );
                    post_data.append( 'account',account );
                    post_data.append( 'accountname',accountname );
                    post_data.append( 'contact_residence_address',residence_address );
                    post_data.append( 'postaladdress',postaladdress );
                    post_data.append( 'australian_citizen',australian_citizen );
                    post_data.append( 'visa_type',visa_type );
                    post_data.append( 'medicare_card',medicare_card );
                    post_data.append( 'medicare_card_hold_days',medicare_card_hold_days );
                    post_data.append('private_health_insurance', private_health_insurance);
                    post_data.append( 'spouse',spouse );
                    post_data.append( 'spouse_name',spouse_name );
                    post_data.append( 'spouse_gender',spouse_gender );
                    post_data.append( 'spouse_date_of_birth',spouse_date_of_birth );
                    post_data.append( 'spouse_yearly_taxable_income',spouse_yearly_taxable_income );
                    post_data.append( 'dependent_children',dependent_children );
                    post_data.append('no_children', no_children);
                    post_data.append( 'help_debt',help_debt );
                    post_data.append( 'help_debt_amount',help_debt_amount );
                    ///cetnerlik income     

                    var employer_name =     $("input[name='employer_name[]']").length ;
                    for (var x = 1 ; x <= employer_name; x++) {
                        var value =  $("#employer_name"+x).val();
                        //    alert(value);
                        post_data.append("employer_name[]", value );
                    }  

                    var payg_wihold = $("input[name='payg_wihold[]']").length ; 
                    for (var x = 1; x <= payg_wihold; x++) {
                        var value =  $("#payg_wihold"+x).val();
                        post_data.append("payg_wihold[]", value);
                    }
                    var gross_wags = $("input[name='gross_wags[]']").length ; 
                    for (var x = 1; x <= gross_wags; x++) {
                        var value =  $("#gross_wags"+x).val();
                        post_data.append("gross_wags[]", value);
                    } 
                    var allowance = $("input[name='allowance[]']").length ; 
                    for (var x = 1; x <= allowance; x++) {
                        var value =  $("#allowance"+x).val();
                        post_data.append("allowance[]", value);
                    }  


                    post_data.append( 'centerlink_income', centerlink_income );
                    post_data.append( 'centerlink_income_details', centerlink_income_details );
                    post_data.append( 'centerlink_income_payg_withold',centerlink_income_payg_withold );
                    post_data.append( 'centerlink_income_payment',centerlink_income_payment );
                    post_data.append( 'bank_interest_received',bank_interest_received );
                    post_data.append( 'bank_interest_tax_withold',bank_interest_tax_withold );
                    post_data.append( 'bank_interest_total_interest',bank_interest_total_interest );
                    post_data.append( 'dividned_income_unfranked',dividned_income_unfranked );
                    post_data.append( 'dividned_income_franked',dividned_income_franked );
                    post_data.append( 'dividned_income_franked_credit',dividned_income_franked_credit );
                    post_data.append( 'other_income',other_income );
                    post_data.append( 'other_income_amount',other_income_amount );
                    post_data.append( 'attach_document_income',attach_document_income );    

                    var ins = document.getElementById('attach_document_income').files.length;
                    // alert(ins);
                    for (var x = 0; x < ins; x++) {
                        post_data.append("files[]", document.getElementById('attach_document_income').files[x]);
                    }


                    // for deducation values

                    post_data.append( 'claim_method_deduction', claim_method_deduction );
                    post_data.append( 'kms_travelled', kms_travelled );
                    post_data.append( 'mv_engine_size',mv_engine_size );
                    post_data.append( 'log_book_method_amount',log_book_method_amount );
                    post_data.append( 'uniform_amount',uniform_amount );
                    post_data.append( 'self_education_description',self_education_description );
                    post_data.append( 'self_education_amount',self_education_amount );

                    var Other_expense_description =     $("input[name='Other_expense_description[]']").length ;
                    for (var x = 1; x <= Other_expense_description; x++) {
                        var value =  $("#Other_expense_description"+x).val();

                        post_data.append("Other_expense_description[]", value );
                    } 

                    var Other_expense_per_working_related =  $("input[name='Other_expense_per_working_related[]']").length ;
                    for (var x = 1; x <= Other_expense_per_working_related; x++) {
                        var value =  $("#Other_expense_per_working_related"+x).val();

                        post_data.append("Other_expense_per_working_related[]", value );
                    }  
                    var Other_expense_amount =     $("input[name='Other_expense_amount[]']").length ;
                    for (var x = 1; x <= Other_expense_amount; x++) {
                        var value =  $("#Other_expense_amount"+x).val();

                        post_data.append("Other_expense_amount[]", value );
                    }   




                    post_data.append( 'gifts_donations_description',gifts_donations_description );
                    post_data.append( 'gifts_donations_amount',gifts_donations_amount );
                    post_data.append( 'Offsets_single_pay',Offsets_single_pay );
                    post_data.append( 'Offsets_remote_area',Offsets_remote_area );
                    post_data.append( 'offset_post_code',offset_post_code );
                    post_data.append( 'offset_notes',offset_notes ); 


                    // business append

                    post_data.append( 'business_name', business_name );
                    post_data.append( 'business_activity', business_activity );
                    post_data.append( 'business_address',business_address );
                    post_data.append( 'business_income',business_income );
                    var business_expans_des =     $("input[name='business_expans_des[]']").length ;
                    
                    for (var x = 1; x <= business_expans_des; x++) {
                        var value =  $("#business_expans_des"+x).val();

                        post_data.append("business_expans_des[]", value );
                    } 

                    var business_exp_amount =     $("input[name='business_exp_amount[]']").length ;
                    for (var x = 1; x <= business_exp_amount; x++) {
                        var value =  $("#business_exp_amount"+x).val();

                        post_data.append("business_exp_amount[]", value );
                    } 
                   // post_data.append( 'business_exp_stationery',business_exp_stationery );
                 //   post_data.append( 'business_exp_direct_cost',business_exp_direct_cost );
                  //  post_data.append( 'business_exp_mobile',business_exp_mobile );
                  //  post_data.append( 'business_exp_travelling',business_exp_travelling );
                  //  post_data.append( 'business_exp_other_expense',business_exp_other_expense );
                    post_data.append( 'busniess_loss_pre_year',busniess_loss_pre_year );
                    post_data.append( 'business_exp_forward_loss',business_exp_forward_loss );    


                    var investment_first  = $("input[name='investment_first[]']").length ;

                    for (var x = 1 ; x <= investment_first; x++) {
                        var value1 =  $("#address_investment_property"+x).val();

                        post_data.append("address_investment_property[]", value1 );

                        var value2 =  $("#date_investment_property"+x).val();

                        post_data.append("date_investment_property[]", value2);

                        var value3 =  $("#investment_first"+x).val();

                        post_data.append("investment_first[]", value3 );

                        var value4 =  $("#investment_second"+x).val();

                        post_data.append("investment_second[]", value4 );


                        var value5 =  $("#investment_per_first"+x).val();

                        post_data.append("investment_percentage_first[]", value5 );

                        var value6 =  $("#investment_per_seocnd"+x).val();

                        post_data.append("investment_percentage_secound[]", value6 );

                        var value7 =  $("#investment_rental_income"+x).val();
                        post_data.append("investment_rental_income[]", value7 );

                        var value8 =  $("#investment_other_income"+x).val();
                        post_data.append("investment_other_income[]", value8 );

                        var value30 =  $("#investment_advertising"+x).val();
                        post_data.append("investment_advertising[]", value30 );


                        var value9 =  $("#investment_body_corporate_fees"+x).val();
                        post_data.append("investment_body_corporate_fees[]", value9 );

                        var value10 =  $("#investment_borrowing_expenses"+x).val();
                        post_data.append("investment_borrowing_expenses[]", value10 );

                        var value11 =  $("#investment_cleaning"+x).val();
                        post_data.append("investment_cleaning[]", value11 );



                        var value12 =  $("#investment_council_rates"+x).val();
                        post_data.append("investment_council_rates[]", value12 );

                        var value13 =  $("#investment_gardening"+x).val();
                        post_data.append("investment_gardening[]", value13 );


                        var value14 =  $("#investment_insurance"+x).val();
                        post_data.append("investment_insurance[]", value14 );

                        var value15 =  $("#investment_interest"+x).val();
                        post_data.append("investment_interest[]", value15 );

                        var value16 =  $("#investment_land_tax"+x).val();
                        post_data.append("investment_land_tax[]", value16 );

                        var value17 =  $("#investment_legal_fees"+x).val();
                        post_data.append("investment_legal_fees[]", value17 );



                        var value18 =  $("#investment_pest_control"+x).val();
                        post_data.append("investment_pest_control[]", value18);

                        var value19 =  $("#investment_agent_fee"+x).val();
                        post_data.append("investment_agent_fee[]", value19 );

                        var value20 =  $("#investment_repairs"+x).val();
                        post_data.append("investment_repairs[]", value20 );


                        var value21 =  $("#investment_capital_work"+x).val();
                        post_data.append("investment_capital_work[]", value21 );

                        var value22 =  $("#investment_capital_allowance"+x).val();
                        post_data.append("investment_capital_allowance[]", value22 );

                        var value23 =  $("#investment_office_supplies"+x).val();
                        post_data.append("investment_office_supplies[]", value23 );

                        var value24 =  $("#investment_travel"+x).val();
                        post_data.append("investment_travel[]", value24 );



                        var value25 =  $("#investment_water"+x).val();
                        post_data.append("investment_water[]", value25 );

                        var value26 =  $("#investment_sundry"+x).val();
                        post_data.append("investment_sundry[]", value26 ); 
                    }   
                    post_data.append('stripeToken',token);
                    post_data.append('amount',final_aomunt);
                    post_data.append('currency',currency);
                    post_data.append('email',email);  
                    post_data.append('action', 'individual_return');    

                    $.ajax({
                        url: "<?php echo admin_url('admin-ajax.php'); ?>",
                        type:"post",
                        processData: false,
                        contentType: false,
                        data : post_data,  
                        beforeSend: function() {
                            $("#loading-image").show();
                        },
                        success:function(html) {
                            $("#loading-image").hide();
                            /*if(html = '1'){ 
                            //   $('#stripe_paynm').submit();

                            alert("You have successfully apply for tax Return");
                            // $(':input').val('');
                            $("#individal_tax_retun")[0].reset();
                            }else{
                            alert("Please try again");
                            }*/
                            if(html = '1'){
                                window.location.href = "<?php  the_permalink(251); ?>";
                             //   $("#sucess_msg").modal('show');
                                //$("#myModal").modal('hide');
                                $("#myModal").fadeOut();
                                $('body').removeClass('modal-open');
                                $('.modal-backdrop').remove();
                                $("#individal_tax_retun")[0].reset();
                                // alert("You payment has been successful");  
                            }else if(html){
                                $("#get_error").html(html);  

                            }
                        },
                        error: function(errorThrown){
                            console.log(errorThrown);
                        }
                    });     


                }
            }
        }
    }
    function valEmail2() {
        var email = jQuery("#email").val();
        var reg_email = /^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/;
        if(email == '') {
            jQuery("#email").css("border","1px solid red"); 
            jQuery("#email_error").css("display","");
            jQuery("#email_error").html('Please enter email');
            return false; 
        }
        else if(!reg_email.test(email)) {
            jQuery("#email").css("border","1px solid red"); 
            jQuery("#email_error").css("display","");
            jQuery("#email_error").html('Please enter valid email');
            return false; 
        }
        else {  
            jQuery("#email").css("border","1px solid #ccc"); 
            jQuery("#email_error").css("display","none");
            return true;   
        }
    } 
    function valcardnumber() { 
        var card_number = jQuery("#card_number").val();
        var regexp = /^[0-9 ]*$/;

        if(card_number == '') {
            jQuery("#card_number").css("border","1px solid red"); 
            jQuery("#cardnumber_error").css("display","");
            jQuery("#cardnumber_error").html('Please enter Card number');
            return false; 
        }
        else if(card_number.search(regexp) == -1) {
            jQuery("#card_number").css("border","1px solid red");
            jQuery("#cardnumber_error").css("display","");
            jQuery("#cardnumber_error").html('Please enter valid Card number');
            return false; 
        }
        else {      
            jQuery("#card_number").css("border","1px solid #ccc");             
            jQuery("#cardnumber_error").css("display","none");
            return true;   
        }    
    }  
    function valexpiration_month() { 
        var exp_month = jQuery("#exp_month").val();

        var regexp = /^[0-9 ]*$/;
        if(exp_month == '') {
            jQuery("#exp_month").css("border","1px solid red"); 
            jQuery("#exp_month_error").css("display","");
            jQuery("#exp_month_error").html('Please enter month');
            return false; 
        }
        else if(exp_month.search(regexp) == -1) {
            jQuery("#exp_month").css("border","1px solid red");
            jQuery("#exp_month_error").css("display","");
            jQuery("#exp_month_error").html('Please enter valid month');
            return false; 
        }
        else  if (exp_month < 0 || exp_month > 12) {
            jQuery("#exp_month").css("border","1px solid red");
            jQuery("#exp_month_error").css("display","");
            jQuery("#exp_month_error").html('Please enter valid month');
            return false;
        }
        else {      
            jQuery("#exp_month").css("border","1px solid #ccc");             
            jQuery("#exp_month_error").css("display","none");
            return true;   
        }    
    }   
    function valexpiration_year() { 
        var exp_year = jQuery("#exp_year").val();

        var regexp = /^[0-9 ]*$/;
        if(exp_year == '') {
            jQuery("#exp_year").css("border","1px solid red"); 
            jQuery("#exp_year_error").css("display","");
            jQuery("#exp_year_error").html('Please enter year');
            return false; 
        }
        else if(exp_year.search(regexp) == -1) {
            jQuery("#exp_year").css("border","1px solid red");
            jQuery("#exp_year_error").css("display","");
            jQuery("#exp_year_error").html('Please enter valid year');
            return false; 
        }
        else {      
            jQuery("#exp_year").css("border","1px solid #ccc");             
            jQuery("#exp_year_error").css("display","none");
            return true;   
        }    
    }   
    function valcvc() { 
        var cvc = jQuery("#cvc").val();
        var regexp = /^[0-9 ]*$/;
        if(cvc == '') {
            jQuery("#cvc").css("border","1px solid red"); 
            jQuery("#cvc_error").css("display","");
            jQuery("#cvc_error").html('Please enter cvc');
            return false; 
        }
        else if(cvc.search(regexp) == -1) {
            jQuery("#cvc").css("border","1px solid red");
            jQuery("#cvc_error").css("display","");
            jQuery("#cvc_error").html('Please enter valid cvc');
            return false; 
        }
        else {      
            jQuery("#cvc").css("border","1px solid #ccc");             
            jQuery("#cvc_error").css("display","none");
            return true;   
        }    
    }    
</script>   
<script>       
    $("#tab_click li a").click(function(e) {   
        return false;
    });
</script>       



                     
  
<?php
get_footer();

