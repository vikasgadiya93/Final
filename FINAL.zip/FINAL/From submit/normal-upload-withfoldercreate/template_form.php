<?php
    /**
    Template Name: Teacher Register
    */
?>

<?php 
    if ( is_user_logged_in() ) {
        wp_safe_redirect( home_url() );
    }
    if(isset($_POST['cost_per_mintue']))  
    { 


        //echo "<pre>"; print_r($_POST); die; 
        $first_name = $_POST['first_name'];
        $last_name = $_POST['last_name'];
        $username1 = $_POST['username1'];
        $emails_id  = $_POST['emails_id'];
        $paypal_emails_id  = $_POST['paypal_emails_id'];
        $pass = $_POST['pass'];
        $phone = $_POST['phone'];
        $nickname = $username1;
        $website = '';
        //additoion information
        $bio_description = $_POST['bio_description'];
        $cost_per_mintue = $_POST['cost_per_mintue'];
        $teacher_level = $_POST['teacher_level'];
        $teacher_style  = $_POST['teacher_style'];
        $country  = $_POST['country'];
        $city  = $_POST['city'];



        $teacher_level = implode(",",$teacher_level); 
        $teacher_style = implode(",",$teacher_style); 





        $user_data = array(
        'user_login'    =>  $username1,
        'user_email'    =>  $emails_id,
        'user_pass'     =>  $pass,
        'user_url'      =>  $website,
        'first_name'    =>  $first_name,
        'last_name'     =>  $last_name,
        'nickname'      =>  $nickname,
        'description'   =>  $bio,
        'role' => 'teacher'
      
        );

      
        $user_id = wp_insert_user( $user_data );

        if ( is_wp_error($user_id) ){
            $error = $user_id->get_error_message();
            $status = "0";
        }else{
            update_user_meta($user_id, 'paypal_email', $paypal_emails_id);
            update_user_meta($user_id, 'user_type', "teacher");
            update_user_meta($user_id,'admin_notify',0);
            update_user_meta($user_id,'teacher_verified','');
            update_user_meta($user_id,'country',$country);
            update_user_meta($user_id,'city',$city);
            update_user_meta($user_id,'phone',$phone);


            $fileName=$_FILES["user_image"]["name"];
            if(!empty($fileName)){
                $user_image_path = imageProfile($_FILES,$user_id);
                update_user_meta($user_id, 'user_image', $user_image_path);
            }
            $fileName=$_FILES["user_video"]["name"];
            if(!empty($fileName)){
                $user_video_path = videoProfile($_FILES,$user_id);
                
               update_user_meta($user_id, 'user_video', $user_video_path);
            }

            update_user_meta($user_id, 'description', $bio_description);
            update_user_meta($user_id, 'cost_per_mintue', $cost_per_mintue);
            update_user_meta($user_id, 'teacher_level', $teacher_level);
            update_user_meta($user_id, 'teacher_style', $teacher_style);


            //   Email
           // $admin_email = get_option('noti_email_id');
           
             $admin_email = 'approval@laughingcamel.net';
            // $admin_email = 'vikas@redsparkinfo.co.in';
            $home_page = home_url();    
            $logo = esc_url( get_option('footer_logo_url') );

            $header = "<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>
            <html xmlns='http://www.w3.org/1999/xhtml'>
            <head>
            <meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
            <meta name='viewport' content='width=device-width, initial-scale=1, maximum-scale=1' />
            <meta http-equiv='X-UA-Compatible' content='IE=edge' />
            <meta name='format-detection' content='date=no' />
            <meta name='format-detection' content='address=no' />
            <meta name='format-detection' content='telephone_no=no' />
            <title></title>
            <style type='text/css'>
            body {
            margin: 0px !important;
            padding: 0px !important;
            -webkit-text-size-adjust: 100% !important;
            -ms-text-size-adjust: 100% !important;
            -webkit-font-smoothing: antialiased !important;
            }
            html {
            width: 100%;
            }
            img {
            border: 0 !important;
            outline: none !important;
            display: block !important;
            }
            table {
            border-collapse: collapse;
            mso-table-lspace: 0px;
            mso-table-rspace: 0px;
            }
            td {
            border-collapse: collapse;
            mso-line-height-rule: exactly;
            }
            a, span {
            mso-line-height-rule: exactly;
            }
            a {
            text-decoration: none !important;
            }
            .ExternalClass * {
            line-height: 100%;
            }
            .video img {
            width: 100%;
            height: auto;
            }
            h1, h2, h3, h4, h5, h6 {
            line-height: 100% !important;
            -webkit-font-smoothing: antialiased;
            }
            yshortcuts, .yshortcuts a, .yshortcuts a:link, .yshortcuts a:visited, .yshortcuts a:hover, .yshortcuts a span {
            color: black;
            text-decoration: none !important;
            border-bottom: none !important;
            background: none !important;
            }
            code {
            white-space: 300;
            word-break: break-all;
            }
            span a {
            text-decoration: none !important;
            }
            .yshortcuts a {
            border-bottom: none !important;
            }
            *[class='gmail-fix'] {
            display: none !important;
            }
            @media only screen and (min-width:481px) and (max-width:599px) {
            table[class=templetcontainer] {
            width: 100% !important;
            }
            table[class=spark_full_width_containt] {
            width: 100% !important;
            }
            td[class=spacer] {
            padding-left: 14px !important;
            padding-right: 14px !important;
            }
            td[class=remove] {
            display: none !important;
            }
            img[class=full_img] {
            width: 100% !important;
            height: auto !important;
            }
            td[class=height_f] {
            height: 20px !important;
            }
            td[class=video] img {
            width: 100% !important;
            height: auto !important;
            }
            td[class=text_center] {
            text-align: center !important;
            }
            .hide {
            display: none !important;
            }
            td[class='mob_hide'] {
            display: none !important;
            font-size: 0 !important;
            height: 0 !important;
            line-height: 0 !important;
            min-height: 0 !important;
            width: 0 !important;
            }
            td[class='templetcontainer2'] {
            float: left !important;
            width: 100% !important;
            display: block !important;
            }
            td[class=pad_bottom] {
            padding-bottom: 10px;
            }
            td[class=pad_top] {
            padding-top: 10px;
            }
            }
            @media only screen and (max-width:480px) {
            table[class=templetcontainer] {
            width: 100% !important;
            }
            table[class=spark_full_width_containt] {
            width: 100% !important;
            }
            td[class='spacer'] {
            padding-left: 16px !important;
            padding-right: 16px !important;
            }
            td[class=remove] {
            display: none !important;
            }
            img[class=full_img] {
            width: 100% !important;
            height: auto !important;
            }
            td[class=height_f] {
            height: 20px !important;
            }
            td[class=video] img {
            width: 100% !important;
            height: auto !important;
            }
            td[class=text_center] {
            text-align: center !important;
            }
            .hide {
            display: none !important;
            }
            td[class=pad_bottom] {
            padding-bottom: 10px;
            }
            td[class=pad_top] {
            padding-top: 10px;
            }
            td[class='mob_hide'] {
            display: none !important;
            font-size: 0 !important;
            height: 0 !important;
            line-height: 0 !important;
            min-height: 0 !important;
            width: 0 !important;
            }
            td[class='templetcontainer2'] {
            float: left !important;
            width: 100% !important;
            display: block !important;
            }
            }
            /* Hide spacer image in applications that support media queries */
            @media only screen and (max-width: 600px) {
            *[class='gmail-fix'] {
            display: none !important;
            }
            }
            </style>
            </head>
            <body marginwidth='0' marginheight='0' offset='0' topmargin='0' leftmargin='0' bgcolor='ffffff'>
            <table width='100%' border='0' align='center' cellspacing='0' cellpadding='0' bgcolor='#ffffff'>
            <tr class='gmail-fix'>
            <td><table cellpadding='0' cellspacing='0' border='0' align='center' width='600'>
            <tr>
            <td cellpadding='0' cellspacing='0' border='0' height='1' style='line-height: 1px; min-width: 600px;'>
            <img src='images/spacer.gif' width='600' height='1' style='display: block; max-height: 1px; min-height: 1px; min-width: 600px; width: 600px;'/>
            </td>
            </tr>
            </table></td>
            </tr>
            <tr>
            <td align='center'><table width='600' border='0' cellspacing='0' cellpadding='0' align='center' class='templetcontainer' style='table-layout:fixed;' >
            <tr>
            <td class='remove' height='20'>&nbsp;</td>
            </tr>
            <tr>
            <td align='center' valign='top' style='padding:10px 0px;'>
            <a href=".$home_page.">
            <img class='thank-you-img' src='".$logo."' alt='laughingcamel' style='max-width: 250px;'></a>
            </td>
            </tr>
            <tr>
            <td class='remove' height='20'>&nbsp;</td>
            </tr>
            </table>
            </td>
            </tr>
            <tr>
            <td align='center'><table width='600' border='0' cellspacing='0' cellpadding='0' align='center' class='templetcontainer' bgcolor='#ffffff' style='table-layout:fixed; background-color:#ffffff;' >
            <tr>
            <td width='20' class='remove'>&nbsp;</td>
            <td width='' class='spacer'><table width='560' border='0' cellspacing='0' cellpadding='0' align='center' class='templetcontainer'>
            <tr>
            <td align='center' style='font-family:Arial, sans-serif; font-size:14px; line-height:26px; color:#000000;'>";

            $footer="<tr>
            <td align='center'>
            <table width='600' border='0' cellspacing='0' cellpadding='0' align='center' class='templetcontainer'  bgcolor='#525354' style='table-layout:fixed; background-color:#525354;'>
            <tr>
            <td height='10' align='center' valign='top'></td>
            </tr>
            <tr>
            <td align='center' valign='top'  class='spacer'><table width='600' border='0' cellspacing='0' cellpadding='0' align='center' class='templetcontainer' bgcolor='#525354' style='table-layout:fixed; background-color:#525354;' >
            <tr>
            <td width='20' class='remove'>&nbsp;</td>
            <td width='' class='spacer'><table width='100%' border='0' cellspacing='0' cellpadding='0' align='center' class='templetcontainer'>
            <tr>
            <td align='center' valign='top' style='font-size:14px; line-height: 24px; font-family:  Arial, Helvetica, sans-serif; color:#ffffff;text-align: center; padding:0px 0;'>

            </td>
            </tr>
            <tr>
            <td height='10' style='line-height:1px;font-size:1px;'  class='height_f'>&nbsp;</td>
            </tr>
            </table>
            </td>
            <td width='20' class='remove'>&nbsp;</td>
            </tr>
            </table></td>
            </tr>
            </table>
            </td>
            </tr>
            <tr>
            <td align='center'><table width='600' border='0' cellspacing='0' cellpadding='0' align='center' class='templetcontainer' >
            <tr>
            <td class='spacer'> <table width='600' border='0' cellspacing='0' cellpadding='0' align='center' class='templetcontainer'>
            <tr>
            <td height='15' style='line-height:1px; font-size:1px;'>&nbsp;</td>
            </tr>
            </table></td>
            </tr>
            <tr>
            <td height='20'>&nbsp;</td>
            </tr>
            </table></td>
            </tr>
            </table>
            </body>
            </html>";
            
            $url = get_permalink('89').'?teacher_id='.base64_encode($user_id); ;  
            $admin_message = $header."
            <table style='background: #eee; padding-left:10px;' width='100%'>
            <tr>
            <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'> First Name </th>
            <td bgcolor='#fff' style='padding: 5px; background-color: #fff;' align='center' width='2%'> : </td>
            <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$first_name."</td>
            </tr>


            <tr>
            <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'> Last Name </th>
            <td bgcolor='#fff' style='padding: 5px; background-color: #fff;' align='center' width='2%'> : </td>
            <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$last_name."</td>
            </tr>

            <tr>
            <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'> Username </th>
            <td bgcolor='#fff' style='padding: 5px; background-color: #fff;' align='center' width='2%'> : </td>
            <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$username1."</td>
            </tr> 

            <tr>
            <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'> Email </th>
            <td bgcolor='#fff' style='padding: 5px; background-color: #fff;' align='center' width='2%'> : </td>
            <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$emails_id."</td>
            </tr> 

            <tr>
            <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'> Paypal Emails </th>
            <td bgcolor='#fff' style='padding: 5px; background-color: #fff;' align='center' width='2%'> : </td>
            <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$paypal_emails_id."</td>
            </tr>
            <tr>
            <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'> Description </th>
            <td bgcolor='#fff' style='padding: 5px; background-color: #fff;' align='center' width='2%'> : </td>
            <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$bio_description."</td>
            </tr> 
            <tr>
            <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'> Cost Per Mintue </th>
            <td bgcolor='#fff' style='padding: 5px; background-color: #fff;' align='center' width='2%'> : </td>
            <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$cost_per_mintue."</td>
            </tr>
            <tr>
            <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'> Teacher Level </th>
            <td bgcolor='#fff' style='padding: 5px; background-color: #fff;' align='center' width='2%'> : </td>
            <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$teacher_level."</td>
            </tr>
            <tr>
            <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'> Country </th>
            <td bgcolor='#fff' style='padding: 5px; background-color: #fff;' align='center' width='2%'> : </td>
            <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$country."</td>
            </tr>
              <tr>
            <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'> City </th>
            <td bgcolor='#fff' style='padding: 5px; background-color: #fff;' align='center' width='2%'> : </td>
            <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$city."</td>
            </tr>
            <tr>
            <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'> Teacher Styles </th>
            <td bgcolor='#fff' style='padding: 5px; background-color: #fff;' align='center' width='2%'> : </td>
            <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$teacher_style."</td>
            </tr>
            <tr>
            <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'> Approve URL </th>
            <td bgcolor='#fff' style='padding: 5px; background-color: #fff;' align='center' width='2%'> : </td>
            <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'> <a href=".$url.">".$url."</a></td>
            </tr>
            
            
            </table>
            <br> ".$footer; 

            $subject = "New Teacher Profile Submited for Review";
 
            $blog_name = html_entity_decode(get_bloginfo('name'));

            //$headers = 'From: Laughingcamel <'.$to.'>' . "\r\n";
            $headers = 'From: '.$blog_name.'  <'.get_option('admin_email').'>' ."\r\n";
            $headers .= "MIME-Version: 1.0\r\n";
            $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
            $mail = mail( $admin_email, $subject, $admin_message, $headers );

            $subject1 = "New Teacher Registration";
            $message1 = '<html>
            <head>
            <meta http-equiv="content-type" content="text/html; ">
            <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
            <title>Laughingcamel</title>
            </head>
            <body text="#000000" bgcolor="#FFFFFF">
            <div id="wrapper" dir="ltr" style="background-color: #f7f7f7;
            margin: 0; padding: 70px 0 70px 0; -webkit-text-size-adjust:
            none !important; width: 100%;">
            <table cellspacing="0" cellpadding="0" height="100%"
            width="100%" border="0">
            <tbody>
            <tr>
            <td valign="top" align="center">
            <div id="template_header_image"> </div>
            <table id="template_container" style="box-shadow: 0 1px
            4px rgba(0,0,0,0.1) !important; background-color:
            #ffffff; border: 1px solid #dedede; border-radius: 3px
            !important;" cellspacing="0" cellpadding="0"
            width="600" border="0">
            <tbody>
            <tr>
            <td valign="top" align="center">
            <!-- Header -->
            <table id="template_header"
            style="background-color: #96588a;
            border-radius: 3px 3px 0 0 !important; color:
            #ffffff; border-bottom: 0; font-weight: bold;
            line-height: 100%; vertical-align: middle;
            font-family: &quot;Helvetica Neue&quot;,
            Helvetica, Roboto, Arial, sans-serif;"
            cellspacing="0" cellpadding="0" width="600"
            border="0">
            <tbody>
            <tr>
            <td id="header_wrapper" style="padding:
            36px 48px; display: block;">
            <h1 style="color: #ffffff; font-family:
            &quot;Helvetica Neue&quot;, Helvetica,
            Roboto, Arial, sans-serif; font-size:
            30px; font-weight: 300; line-height:
            150%; margin: 0; text-align: left;
            text-shadow: 0 1px 0 #ab79a1;
            -webkit-font-smoothing: antialiased;">Welcome
            to Laughingcamel</h1>
            </td>
            </tr>
            </tbody>
            </table>
            </td>
            </tr>
            <tr>
            <td valign="top" align="center">
            <table id="template_body" cellspacing="0"
            cellpadding="0" width="600" border="0">
            <tbody>
            <tr>
            <td id="body_content"
            style="background-color: #ffffff;"
            valign="top">
            <table cellspacing="0" cellpadding="20"
            width="100%" border="0">
            <tbody>
            <tr>
            <td style="padding: 48px;"
            valign="top">
            <div id="body_content_inner"
            style="color: #636363;
            font-family: &quot;Helvetica
            Neue&quot;, Helvetica, Roboto,
            Arial, sans-serif; font-size:
            14px; line-height: 150%;
            text-align: left;">
            <p style="margin: 0 0 16px;">Thanks for creating an account on Laughing Camel. Your display name is <strong>'.$username1.'</strong></p>
           <p style="margin: 0 0 16px;">To login <a  href="https://laughingcamel.net/teacher-login/">Click here.</a> Please note, it may take up to 24 hours to approve your registration as a Teacher.</p>
            </div>
            </td>
            </tr>
            </tbody>
            </table>
            </td>
            </tr>
            </tbody>
            </table>
            </td>
            </tr>
            <tr>
            <td valign="top" align="center">
            <!-- Footer -->
            <table id="template_footer" cellspacing="0"
            cellpadding="10" width="600" border="0">
            <tbody>
            <tr>
            <td style="padding: 0;
            -webkit-border-radius: 6px;"
            valign="top">
            <table cellspacing="0" cellpadding="10"
            width="100%" border="0">
            <tbody>
            <tr>
            <td colspan="2" id="credit"
            style="padding: 0 48px 48px
            48px; -webkit-border-radius:
            6px; border: 0; color: #c09bb9;
            font-family: Arial; font-size:
            12px; line-height: 125%;
            text-align: center;"
            valign="middle">
            <p>Laughingcamel </p>
            </td>
            </tr>
            </tbody>
            </table>
            </td>
            </tr>
            </tbody>
            </table>
            </td>
            </tr>
            </tbody>
            </table>
            </td>
            </tr>
            </tbody>
            </table>
            </div>
            </div>
            </body>
            </html>';        


            //  $headers = "From: Quest Media profile_img ";
             $headers1 = 'From: '.$blog_name.'  <'.get_option('admin_email').'>' ."\r\n";
            $headers1 .= "MIME-Version: 1.0\r\n";
            $headers1 .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
            $mail1 = mail( $emails_id, $subject1, $message1, $headers1 );


            $emailSent = true;
            $success = "1"; 

           // wp_redirect(home_url('/'));
            wp_redirect(get_the_permalink(176));
            exit;
            $status = "1";
        }
    }   
?>
<?php
    get_header(); 
    $page_id = get_the_id();
    $post_img = wp_get_attachment_url( get_post_thumbnail_id( $page_id ) );
?>

<section class="section section-content section-login-register py-5">
    <div class="container">
        <div class="row">
            <div class="col-sm-10 offset-sm-1">
                <div class="info-text info-text1">
                    <h2>Teacher Registration Form</h2>
                    <h5>Submit the form below to become a guitar teacher.</h5>
                    <p style="color: red;">Fields with * are mandatory.</p>
                </div>

                <?php if($status == "1"){ ?>
                    <div class="alert alert-success alert-dismissible">
                        Thanks for creating an account on Laughingcamel.
                    </div>
                    <?php } ?>
                <?php if($status == "0"){ ?>
                    <div class="alert alert-warning alert-dismissible" style="color: red;">
                        <?php if($error == "Sorry, that username already exists!"){ echo "Sorry, that display name already exists!"; }else{  echo $error; }?>
                    </div>
                    <?php } ?>
                <div class="white-box">
                    <form action="" method="post" id="teacher_profile_form" enctype="multipart/form-data">         
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label for="reg_sr_firstname">First Name <span class="required">*</span></label>
                                    <input type="text" class="form-control" name="first_name" id="first_name" onblur="return valFname();" value="<?php echo @$_POST['first_name'];?>">
                                    <label style="display:none" generated="true" class="errorAll" id="first_name_error" for="first_name_error">&nbsp;</label>       
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label for="reg_sr_lastname">Last Name <span class="required">*</span></label>
                                    <input type="text" class="form-control" name="last_name" id="last_name" onblur="return valLname();" value="<?php echo @$_POST['last_name'];?>">
                                    <label style="display:none" generated="true" class="errorAll" id="last_name_error" for="last_name_error">&nbsp;</label>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label for="reg_username">Display Name <span class="required">*</span></label>
                                    <input type="text" class="form-control username1" name="username1" id="username1" onblur="return valUsername();" value="<?php echo @$_POST['username1'];?>">
                                    <label style="display:none" generated="true" class="errorAll" id="username1_error" for="username1_error">&nbsp;</label>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label for="reg_password">Password <span class="required">*</span></label>
                                    <input type="password" class="form-control" name="pass" id="pass" onblur="return valPass();" value="<?php echo @$_POST['pass'];?>">
                                    <label style="display:none" generated="true" class="errorAll" id="pass_error1" for="pass_error1">&nbsp;</label>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label for="reg_email">Email address <span class="required">*</span></label>
                                    <input type="email" class="form-control" name="emails_id" id="emails_id" onblur="return valEmail2();" value="<?php echo @$_POST['emails_id'];?>">
                                    <label style="display:none" generated="true" class="errorAll" id="emails_id_error1" for="emails_id_error1">&nbsp;</label>             
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label for="reg_email">Paypal Email <span class="required">*</span></label>
                                    <input type="email" class="form-control" name="paypal_emails_id" id="paypal_emails_id" onblur="return valPaypal_email2();" value="<?php echo @$_POST['paypal_emails_id'];?>">
                                    <span class="payment_note">    The Paypal account where you will receive your payments</span>
                                    <br>
                                    <label style="display:none" generated="true" class="errorAll" id="paypal_emails_id_error1" for="paypal_emails_id_error1">&nbsp;</label>             
                                </div>
                            </div>
                             <div class="col-sm-6">  
                            <div class="form-group">
                                 <label for="reg_email">Country <span class="required">*</span></label>
                                <select class="form-control" name="country" id="country"  onblur="return valSelect();">
                                    <option value="">Select country</option>  
                                    <?php 

                                        $countries = array("Afghanistan", "Albania", "Algeria", "American Samoa", "Andorra", "Angola", "Anguilla", "Antarctica", "Antigua and Barbuda", "Argentina", "Armenia", "Aruba", "Australia", "Austria", "Azerbaijan", "Bahamas", "Bahrain", "Bangladesh", "Barbados", "Belarus", "Belgium", "Belize", "Benin", "Bermuda", "Bhutan", "Bolivia", "Bosnia and Herzegowina", "Botswana", "Bouvet Island", "Brazil", "British Indian Ocean Territory", "Brunei Darussalam", "Bulgaria", "Burkina Faso", "Burundi", "Cambodia", "Cameroon", "Canada", "Cape Verde", "Cayman Islands", "Central African Republic", "Chad", "Chile", "China", "Christmas Island", "Cocos (Keeling) Islands", "Colombia", "Comoros", "Congo", "Congo, the Democratic Republic of the", "Cook Islands", "Costa Rica", "Cote d'Ivoire", "Croatia (Hrvatska)", "Cuba", "Cyprus", "Czech Republic", "Denmark", "Djibouti", "Dominica", "Dominican Republic", "East Timor", "Ecuador", "Egypt", "El Salvador", "Equatorial Guinea", "Eritrea", "Estonia", "Ethiopia", "Falkland Islands (Malvinas)", "Faroe Islands", "Fiji", "Finland", "France", "France Metropolitan", "French Guiana", "French Polynesia", "French Southern Territories", "Gabon", "Gambia", "Georgia", "Germany", "Ghana", "Gibraltar", "Greece", "Greenland", "Grenada", "Guadeloupe", "Guam", "Guatemala", "Guinea", "Guinea-Bissau", "Guyana", "Haiti", "Heard and Mc Donald Islands", "Holy See (Vatican City State)", "Honduras", "Hong Kong", "Hungary", "Iceland", "India", "Indonesia", "Iran (Islamic Republic of)", "Iraq", "Ireland", "Israel", "Italy", "Jamaica", "Japan", "Jordan", "Kazakhstan", "Kenya", "Kiribati", "Korea, Democratic People's Republic of", "Korea, Republic of", "Kuwait", "Kyrgyzstan", "Lao, People's Democratic Republic", "Latvia", "Lebanon", "Lesotho", "Liberia", "Libyan Arab Jamahiriya", "Liechtenstein", "Lithuania", "Luxembourg", "Macau", "Macedonia, The Former Yugoslav Republic of", "Madagascar", "Malawi", "Malaysia", "Maldives", "Mali", "Malta", "Marshall Islands", "Martinique", "Mauritania", "Mauritius", "Mayotte", "Mexico", "Micronesia, Federated States of", "Moldova, Republic of", "Monaco", "Mongolia", "Montserrat", "Morocco", "Mozambique", "Myanmar", "Namibia", "Nauru", "Nepal", "Netherlands", "Netherlands Antilles", "New Caledonia", "New Zealand", "Nicaragua", "Niger", "Nigeria", "Niue", "Norfolk Island", "Northern Mariana Islands", "Norway", "Oman", "Pakistan", "Palau", "Panama", "Papua New Guinea", "Paraguay", "Peru", "Philippines", "Pitcairn", "Poland", "Portugal", "Puerto Rico", "Qatar", "Reunion", "Romania", "Russian Federation", "Rwanda", "Saint Kitts and Nevis", "Saint Lucia", "Saint Vincent and the Grenadines", "Samoa", "San Marino", "Sao Tome and Principe", "Saudi Arabia", "Senegal", "Seychelles", "Sierra Leone", "Singapore", "Slovakia (Slovak Republic)", "Slovenia", "Solomon Islands", "Somalia", "South Africa", "South Georgia and the South Sandwich Islands", "Spain", "Sri Lanka", "St. Helena", "St. Pierre and Miquelon", "Sudan", "Suriname", "Svalbard and Jan Mayen Islands", "Swaziland", "Sweden", "Switzerland", "Syrian Arab Republic", "Taiwan, Province of China", "Tajikistan", "Tanzania, United Republic of", "Thailand", "Togo", "Tokelau", "Tonga", "Trinidad and Tobago", "Tunisia", "Turkey", "Turkmenistan", "Turks and Caicos Islands", "Tuvalu", "Uganda", "Ukraine", "United Arab Emirates", "United Kingdom", "United States", "United States Minor Outlying Islands", "Uruguay", "Uzbekistan", "Vanuatu", "Venezuela", "Vietnam", "Virgin Islands (British)", "Virgin Islands (U.S.)", "Wallis and Futuna Islands", "Western Sahara", "Yemen", "Yugoslavia", "Zambia", "Zimbabwe");
                                        foreach($countries as $key=>$value){    ?> 
                                        <option value="<?php echo $value;?>"><?php echo $value;?></option>  
                                        <?php }
                                    ?>

                                </select>
                            </div>
                            </div>
                             <div class="col-sm-6"> 
                            <div class="form-group">
                            <label for="reg_email">City <span class="required">*</span></label>
                                <input type="text" id="city" name="city" class="form-control" placeholder="City"  onblur="return valcity();"> 

                            </div>
                            </div>
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label>Profile Description <span class="required">*</span></label> 
                                    <textarea class="form-control"  onblur="return valmessage();" id="Message1" name="bio_description" rows="5" placeholder="Tell potential students a bit about yourself - What musical accompliishments or experience do you have?(e.g. do you perform in a band, do you have a music degree?) - What do you like most about teaching guitar ?- What styles do you like to play and teach ?"><?php echo @$_POST['bio_description'];?></textarea>
                                    <label style="display:none" generated="true" class="errorAll" id="bio_description_error" for="bio_description_error">&nbsp;</label>       
                                </div>
                            </div>


                            <div class="col-sm-4">
                                <div class="form-group">
                                    <label for="reg_sr_lastname">Your Cost (per minute In USD): <span class="required">*</span></label>
                                    <input type="text" class="form-control" name="cost_per_mintue" id="cost_per_mintue" onblur="return valcost();" placeholder="0.00" value="<?php echo @$_POST['cost_per_mintue'];?>"  >
                                    <p style="font-size: .7rem; margin-bottom: 0rem;">* Commission will be deducted from this.</p>
                                    <label style="display:none" generated="true" class="errorAll" id="cost_per_mintue_error" for="cost_per_mintue_error">&nbsp;</label>
                                </div>
                            </div>
                             <div class="col-sm-4"> 
                            <div class="form-group">
                            <label for="reg_email">Phone</label>
                                <input type="text" id="phone" name="phone" class="form-control" placeholder="Phone"> 

                            </div>
                            </div>
                            <div class="col-sm-8">
                                <div class="form-group">
                                    <label for="reg_username">Select one or more levels  <span class="required">*</span></label>
                                     
                                    <ul class="checkbox-list">
                                        <li>
                                            <label for="beginner_id"> <input type="checkbox" name="teacher_level[]" id="beginner_id" value="beginner">
                                                Beginner</label>
                                        </li>
                                        <li>
                                            <label for="intermediate_id"><input type="checkbox" name="teacher_level[]" id="intermediate_id" value="intermediate"> Intermediate</label>
                                        </li>
                                        <li>
                                            <label for="advanced_id"><input type="checkbox" name="teacher_level[]" id="advanced_id" value="advanced">
                                                Advanced</label>
                                        </li>
                                    </ul>

                                </div>
                                <label style="display:none" generated="true" class="errorAll" id="teacher_leavel_error" for="teacher_leavel_error">&nbsp;</label>
                            </div>

                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label for="reg_username">Select one or more styles  <span class="required">*</span></label>
                                    <ul class="checkbox-list">
                                        <li><label for="bluegrass_id"><input type="checkbox" name="teacher_style[]" id="bluegrass_id" value="bluegrass"> 
                                                Bluegrass</label></li>
                                        <li><label for="blues_id"><input type="checkbox" name="teacher_style[]" id="blues_id" value="blues"> 
                                                Blues</label></li>
                                        <li>
                                            <label for="classical_id"><input type="checkbox" name="teacher_style[]" id="classical_id" value="classical">
                                                Classical</label>
                                        </li>
                                        <li>
                                            <label for="country_id"> <input type="checkbox" name="teacher_style[]" id="country_id" value="country">
                                                Country</label>
                                        </li>
                                        <li>
                                            <label for="flamenco_id"><input type="checkbox" name="teacher_style[]" id="flamenco_id" value="flamenco">
                                                Flamenco</label>
                                        </li>
                                        <li>
                                            <label for="folk_id"><input type="checkbox" name="teacher_style[]" id="folk_id" value="folk">
                                                Folk</label>
                                        </li>
                                        <li>
                                            <label for="folk_Rock_id"><input type="checkbox" name="teacher_style[]" id="folk_Rock_id" value="folk/Rock">
                                                Folk/Rock</label>
                                        </li>
                                        <li>
                                            <label for="funk_id"><input type="checkbox" name="teacher_style[]" id="funk_id" value="funk">
                                                Funk</label>
                                        </li>
                                        <li>
                                            <label for="jazz_id"> <input type="checkbox" name="teacher_style[]" id="jazz_id" value="jazz">
                                                Jazz</label>
                                        </li>
                                        <li>
                                            <label for="metal_id"><input type="checkbox" name="teacher_style[]" id="metal_id" value="metal">
                                                Metal</label>
                                        </li>
                                        <li>
                                            <label for="pop_id"><input type="checkbox" name="teacher_style[]" id="pop_id" value="pop">
                                                Pop</label>
                                        </li>
                                        <li>
                                            <label for="rock_id"><input type="checkbox" name="teacher_style[]" id="rock_id" value="rock">
                                                Rock</label>
                                        </li>

                                    </ul>

                                </div>
                                <label style="display:none" generated="true" class="errorAll" id="teacher_style_error" for="teacher_style_error">&nbsp;</label>
                            </div>
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label for="reg_sr_firstname">Profile Image <span class="required">*</span></label><br /> 
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="form-group">
                                   
                                    <input name="user_image" id="user_image" class="file-upload-img" onchange="readURL(this);" type="file">
                                
                                </div>
                                   <label style="display:none" generated="true" class="errorAll" id="user_image_error" for="user_image_error">&nbsp;</label>
                            </div>
                            <div class="col-sm-8">
                                <div class="form-group">
                                    <div class="image-preview">
                                        <img id="blah" src="#" alt="" width="200px" height="200px" />  
                                    </div>        
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label for="reg_sr_firstname">Profile Video</label><br /> 
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="form-group">
                                    <input name="user_video" id="user_video" class="file-upload-img" accept="video/mp4,video/x-m4v,video/*"
                                        onchange="readURL1(this);" type="file">
                                </div>
                            </div>
                            <div class="col-sm-8">
                                <div class="form-group">
                                    <style>
                                        .video-preview {
                                            width: 274px;
                                            height: 204px;
                                            border: 4px solid rgba(0,0,0,0.2);
                                            background: #fff;
                                            box-shadow: 0px 0px 15px rgba(0,0,0,0.2);
                                            padding: 10px;
                                            position: relative;
                                        }
                                    </style>
                                    <div class="video-preview">
                                        <video src="movie.ogg" id="blah12" controls  width="244px" height="174px" >
                                            Your browser does not support the video tag.
                                        </video>
                                        <!-- <img id="blah" src="#" alt="" width="200px" height="200px" />  -->
                                    </div>        
                                </div>
                            </div>


 <div class="col-sm-12 text-center">
                             <p>By clicking Next, you agree to our <a href="<?php echo get_the_permalink('212'); ?>">Terms of Use</a> and our <a href="<?php echo get_the_permalink('219'); ?>">Privacy Policy</a>.</p>
                            </div>

                            <div class="col-sm-12 text-center">
                                <div class="form-group">
                                    <input type="button" class="btn btn-submit btn-warning" name="submit_for_review" value="Submit For Review" id="" onclick="return validate_submit_for_review();">
                                </div>

                            </div>
                            <div class="col-sm-12 text-center">
                                <div class="payment_note">You'll hear back from us within 24 hours. If you're accepted, you can then start teaching and earning.    </div>
                            </div>    


                        </div>
                    </form>

                </div>
            </div>

        </div>
    </div>
</section>
<div id="myModal" class="modal fade show" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">

            <div class="modal-body">
                <center> 
                    <label style="font-size: 17px;font-weight: 300;margin: 20px 0;">You'll hear back from us within 24 hours. If you're accepted, you can then start teaching and earning.</label>
                    <input class="btn btn-warning" id="submit_for_review_id" value="Okay"  type="button">
                </center> 

            </div>
        </div>
    </div>
</div>
<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.3.1.min.js"></script>
<script type="text/javascript">
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#blah').attr('src', e.target.result);
                }

                reader.readAsDataURL(input.files[0]);
            }
        }
        function readURL1(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#blah12').attr('src', e.target.result);
            }

            reader.readAsDataURL(input.files[0]);
        }
    }
    </script>
<script>

    function validate_submit_for_review() {
        var status = true;

        if(valcost() == false){
            status = false;
        }
        if(valmessage() == false){
            status = false;
        }
        if(valFname() == false){
            status = false;
        }
        if(valLname() == false){
            status = false;
        }
        if(valUsername() == false){
            status = false;
        }
        if(valEmail2() == false){
            status = false;
        } 
        if(valPaypal_email2() == false){
            status = false;
        } 
          if(valteacherleavel() == false){
            status = false;
        } 
         if(valteacherstyle() == false){
            status = false;
        } 
         if(valSelect() == false){
            status = false;
        }
         if(valcity() == false){
            status = false;
        }
        if(valPass() == false){
            status = false;
        }
        if(valimage() == false){
            status = false;
        } 
        
        if(status == false){

            return status;
        }else{

            jQuery('#myModal').modal('show'); 

            jQuery('#submit_for_review_id').click(function(){
                jQuery("#teacher_profile_form").submit();

            });

        }



    }
   
        function valimage() {
                var user_image = jQuery('#user_image').val();
                
                if(user_image == '') {
                      jQuery("#user_image_error").css("display","");   
                    jQuery("#user_image_error").html('Please Upload a Image');
                   
                    return false;
                   
                }else { 
                    jQuery("#user_image_error").css("display","none");  
                   
                    return true;   
                }
}  
    
     function valteacherleavel() {
                var select = jQuery('input[name="teacher_level[]"]:checked').length;
                
                if(select == '0') {
                      jQuery("#teacher_leavel_error").css("display","");   
                    jQuery("#teacher_leavel_error").html('Please Select at least one level');
                   
                    return false;
                   
                }else { 
                    jQuery("#teacher_leavel_error").css("display","none");  
                   
                    return true;   
                }
}
function valteacherstyle() {
               
                 var select = jQuery('input[name="teacher_style[]"]:checked').length;     
                
                if(select == '0') {
                      jQuery("#teacher_style_error").css("display","");   
                    jQuery("#teacher_style_error").html('Please Select at least one style');
                    return false; 
                }else { 
                    jQuery("#teacher_style_error").css("display","none");  
                 
                    return true;   
                }
}
    

    function valSelect() {
                var select = jQuery("#country").val();
                var regexp = /^[a-zA-Z ]*$/; 
                if(select == '') {
                    jQuery("#country").css("border","1px solid red"); 
                    return false; 
                }else {  
                    jQuery("#country").css("border","1px solid #ccc"); 
                    return true;   
                }
}
function valcity() {
                var city = jQuery("#city").val();

                if(city == '') {
                    jQuery("#city").css("border","1px solid red"); 

                    return false; 
                }

                else {      
                    jQuery("#city").css("border","1px solid #ccc");             
                    jQuery("#phone_error").css("display","none");
                    return true;   
                }
} 

    function valmessage() {
        var Message = jQuery("#Message1").val();
        if(Message == '') {
            jQuery("#Message1").css("border","1px solid red"); 
            jQuery("#bio_description_error").css("display","");
            jQuery("#bio_description_error").html('Please Enter Description');
            return false; 
        }

        else {  
            jQuery("#Message1").css("border","1px solid #ccc"); 
            jQuery("#bio_description_error").css("display","none");
            return true;   
        }
    } 



    function valcost() {
        var cost_per_mintue = jQuery("#cost_per_mintue").val();
        //var regax = /^[0-9]+(\.[0-9]{1,5})?$/
        var regexp  =/^[0-9]+(\.[0-9]{1,5})?$/
        if(cost_per_mintue == '') {
            jQuery("#cost_per_mintue").css("border","1px solid red"); 
            jQuery("#cost_per_mintue_error").css("display","");
            jQuery("#cost_per_mintue_error").html('Please enter Cost');
            return false; 
        }
        else if(cost_per_mintue.search(regexp) == -1) {
            jQuery("#cost_per_mintue").css("border","1px solid red");
            jQuery("#cost_per_mintue_error").css("display","");
            jQuery("#cost_per_mintue_error").html('Please enter valid Cost');
            return false; 
        }
        else {           
            jQuery("#cost_per_mintue").css("border","1px solid #ccc");       
            jQuery("#cost_per_mintue_error").css("display","none");
            return true;   
        }
    }



    // mini jQuery plugin that formats to two decimal places
    (function($) {
        $.fn.currencyFormat = function() {
            this.each( function( i ) {
                $(this).change( function( e ){
                    if( isNaN( parseFloat( this.value ) ) ) return;
                    this.value = parseFloat(this.value).toFixed(2);
                });
            });
            return this; //for chaining
        }
    })( jQuery );

    // apply the currencyFormat behaviour to elements with 'currency' as their class
    $( function() {
        $('#cost_per_mintue').currencyFormat();
    });






</script>
<script>


    function valUsername() {
        var username1 = jQuery("#username1").val();
     //   var regexp = /^[a-zA-Z ]*$/; 
        if(username1 == '') {
            jQuery(".username1").css("border","1px solid red"); 
            jQuery("#username1_error").css("display","");
            jQuery("#username1_error").html('Please enter display name');
            return false; 
        }
        /*else if(username1.search(regexp) == -1) {
            jQuery(".username1").css("border","1px solid red");
            jQuery("#username1_error").css("display","");
            jQuery("#username1_error").html('Please enter valid display name');
            return false; 
        } */
        else {           
            jQuery(".username1").css("border","1px solid #ccc");       
            jQuery("#username1_error").css("display","none");
            return true;   
        }
    }

    function valFname() {
        var first_name = jQuery("#first_name").val();
        var regexp = /^[a-zA-Z ]*$/; 
        if(first_name == '') {
            jQuery("#first_name").css("border","1px solid red"); 
            jQuery("#first_name_error").css("display","");
            jQuery("#first_name_error").html('Please enter first name');
            return false; 
        }
        else if(first_name.search(regexp) == -1) {
            jQuery("#first_name").css("border","1px solid red");
            jQuery("#first_name_error").css("display","");
            jQuery("#first_name_error").html('Please enter valid first name');
            return false; 
        }
        else {           
            jQuery("#first_name").css("border","1px solid #ccc");       
            jQuery("#first_name_error").css("display","none");
            return true;   
        }
    }

    function valLname() {
        var last_name = jQuery("#last_name").val();
        var regexp = /^[a-zA-Z\- ]*$/; 
        if(last_name == '') {
            jQuery("#last_name").css("border","1px solid red"); 
            jQuery("#last_name_error").css("display","");
            jQuery("#last_name_error").html('Please enter last name');
            return false; 
        }
        else if(last_name.search(regexp) == -1) {
            jQuery("#last_name").css("border","1px solid red");
            jQuery("#last_name_error").css("display","");
            jQuery("#last_name_error").html('Please enter valid last name');
            return false; 
        }
        else {           
            jQuery("#last_name").css("border","1px solid #ccc");       
            jQuery("#last_name_error").css("display","none");
            return true;   
        }
    }

    function valEmail2() {
        var emails_id = jQuery("#emails_id").val();
        var reg_email = /^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/;
        if(emails_id == '') {
            jQuery("#emails_id").css("border","1px solid red"); 
            jQuery("#emails_id_error1").css("display","");
            jQuery("#emails_id_error1").html('Please enter email');
            return false; 
        }
        else if(!reg_email.test(emails_id)) {
            jQuery("#emails_id").css("border","1px solid red"); 
            jQuery("#emails_id_error1").css("display","");
            jQuery("#emails_id_error1").html('Please enter valid email');
            return false; 
        }
        else {  
            jQuery("#emails_id").css("border","1px solid #ccc"); 
            jQuery("#emails_id_error1").css("display","none");
            return true;   
        }
    }

    function valPaypal_email2() {
        var paypal_emails_id = jQuery("#paypal_emails_id").val();
        var reg_email = /^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/;
        if(paypal_emails_id == '') {
            jQuery("#paypal_emails_id").css("border","1px solid red"); 
            jQuery("#paypal_emails_id_error1").css("display","");
            jQuery("#paypal_emails_id_error1").html('Please enter paypal email');
            return false; 
        }
        else if(!reg_email.test(paypal_emails_id)) {
            jQuery("#paypal_emails_id").css("border","1px solid red"); 
            jQuery("#paypal_emails_id_error1").css("display","");
            jQuery("#paypal_emails_id_error1").html('Please enter valid paypal email');
            return false; 
        }
        else {  
            jQuery("#paypal_emails_id").css("border","1px solid #ccc"); 
            jQuery("#paypal_emails_id_error1").css("display","none");
            return true;   
        }
    }

    function valPass() {
        var pass = jQuery("#pass").val();
        if(pass == '') {
            jQuery("#pass").css("border","1px solid red"); 
            jQuery("#pass_error1").css("display","");
            jQuery("#pass_error1").html('Please enter password');
            return false; 
        }
        else {      
            jQuery("#pass").css("border","1px solid #ccc");             
            jQuery("#pass_error1").css("display","none");
            return true;   
        }
    }

    /*function valPass1() {
    var pass = jQuery("#pass").val();
    var pass1 = jQuery("#pass1").val();
    if(pass1 == '') {
    jQuery("#pass1").css("border","1px solid red"); 
    jQuery("#pass1_error1").css("display","");
    jQuery("#pass1_error1").html('Please enter confirm password');
    return false; 
    }else if(pass != pass1){
    jQuery("#pass1").css("border","1px solid red"); 
    jQuery("#pass1_error1").css("display","");
    jQuery("#pass1_error1").html('Please enter currect confirm password');
    return false; 
    }
    else {      
    jQuery("#pass1").css("border","1px solid #ccc");             
    jQuery("#pass1_error1").css("display","none");
    return true;   
    }*/
    //}

    /* function check_pass() {
    var pass = jQuery("#pass").val();
    var pass1 = jQuery("#pass1").val();
    if(pass != pass1){
    jQuery("#pass").css("border","1px solid red"); 
    jQuery("#pass1").css("border","1px solid red"); 
    jQuery("#pass1_error1").css("display","");
    jQuery("#pass1_error1").html('Please enter currect password');
    return false; 
    }else{
    jQuery("#pass").css("border","1px solid #ccc");             
    jQuery("#pass1").css("border","1px solid #ccc");             
    jQuery("#pass1_error1").css("display","none");
    return true;   
    }
    }*/ 
</script>
<?php get_footer(); ?>