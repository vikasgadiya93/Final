
    //Image Profile

    function imageProfile($file,$id)
    {

        if($file['user_image']['name']!=''){

            $upload_dir = wp_upload_dir();
            $user_dirname = $upload_dir['basedir'].'/user_images/'.$id;
            if ( ! file_exists( $user_dirname ) ) {
                wp_mkdir_p( $user_dirname );
            }
            $filename = basename($file['user_image']['name']);
            $unique = round(microtime(true));
            $img_target_path = $user_dirname . "/" .$unique .'_'. $filename;
            if(move_uploaded_file($file['user_image']['tmp_name'], $img_target_path))  {
            } else {  }
            chmod("{$img_target_path}", 0755);

            $img_target_path1 = $upload_dir['baseurl'].'/user_images/'.$id . "/" .$unique .'_'. $filename;
            return $img_target_path1;
        }else
        {
            $com_log= get_user_meta($id, "user_image",true);
            //$root_document = $_SERVER['DOCUMENT_ROOT']."/jobportal/";
            //$domain = strstr($com_log, '/profile_image_uploads');
            //$path=$root_document.$domain;
            if(is_file($path) === true)
            {
                unlink($path);
            }
            return  '';
        }
    }
