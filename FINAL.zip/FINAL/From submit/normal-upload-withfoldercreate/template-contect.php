<?php
    /**
    Template Name: Contact Pages
    */ 
    ?>
 <?php
    if(isset($_POST['submit1']))  
    {   

        $firstname=$_POST['first_name'];
        $email1  =$_POST['emails_id'];
        $phone = $_POST['phone1'];
        $Message1 = $_POST['Message1'];

        global $wpdb;
       $insert = $wpdb->insert("wp_contactus", array(
        "first_name" => $firstname,
        "phone" => $phone,
        "email" => $email1,
        "msg" => $Message1,

        ));
        if($insert)
        {  
            

            $to = $email1;
            $subject = "Thank You for Contacting";
            $message = do_shortcode( '[email_header]' )."
            <h3> Thank You for Contacting. We will contact you soon</h3>
            <br> ".do_shortcode( '[email_footer]' );    
            $headers = 'From: test <'.get_option('admin_email').'>' ."\r\n";
            $headers .= "MIME-Version: 1.0\r\n";
            $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
            wp_mail( $to, $subject, $message, $headers );
        
        
        //   Email
        //$to = get_option('notification_email');
        $to = get_option('admin_email');
        \

        $subject = "New Contact Inquiry";

        $message="<h2>Mosero Conatct Us</h2><br />";

        $message.="<style type='text/css'>
        #sign{
        display:none;
        }
        a { color: #2D7BE0; }
        a:hover { text-decoration: none; }
        </style>
        <table style='background: #eee; padding-left:10px;' width='100%'>
        <tr>
        <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'> First Name </th>
        <td bgcolor='#fff' style='padding: 5px; background-color: #fff;' align='center' width='2%'> : </td>
        <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$firstname."</td>
        </tr>
        <tr>
        <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'> Phone Number </th>
        <td bgcolor='#fff' style='padding: 5px; background-color: #fff;' align='center' width='2%'> : </td>
        <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$phone."</td>
        </tr> 

        <tr>
        <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'> Email </th>
        <td bgcolor='#fff' style='padding: 5px; background-color: #fff;' align='center' width='2%'> : </td>
        <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$email1."</td>
        </tr> 

        <tr>
        <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'> Message </th>
        <td bgcolor='#fff' style='padding: 5px; background-color: #fff;' align='center' width='2%'> : </td>
        <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$Message1."</td>
        </tr> 
        </table>
        <br>"; 

        
        $headers = 'From: test <'.get_option('admin_email').'>' . "\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
        wp_mail( $to, $subject, $message, $headers );

        $emailSent = true;
        $success = "1"; 
        }
        $get_url = get_the_permalink(99);          
        wp_redirect($get_url);
        exit;
    }   
?>
    
<?php    get_header(); ?>
 <link rel="stylesheet" type="text/css" href="<?php bloginfo('template_url') ?>/styles/thankyou.css">
<section class="page-heading">
    <span class="bg-overlay"></span>
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <h1>Contact Us</h1>
            </div>
        </div>
    </div>                    

</section>
<section class="section section-content py-5">
    <div class="container">
        <div class="row">
            <div class="col-sm-4">
                <?php dynamic_sidebar('sidebar-3'); ?>
            </div>
            <div class="col-sm-8">
                <?php
                    // Start the loop.
                    while ( have_posts() ) : the_post();

                        the_content();

                        // End the loop.
                        endwhile;
                ?>
                <form action='' method="post">
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>Full Name</label>
                               <input type="text" id="first_name" name="first_name" class="form-control"   onblur="return valName1();">
        <label style="display:none" generated="true" class="errorAll" id="first_name_error" for="first_name_error">&nbsp;</label>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>Email Address</label>
                               <input type="text" id="emails_id" name="emails_id" class="form-control"  onblur="return valEmail2();">  
        <label style="display:none" generated="true" class="errorAll" id="emails_id_error1" for="emails_id_error1">&nbsp;</label>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>Phone Number</label>
                               <input type="text" id="phone1" name="phone1" class="form-control" onblur="return valContact2();">
        <label style="display:none" generated="true" class="errorAll" id="phone_error" for="phone_error">&nbsp;</label>
                            </div>
                        </div>
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label>Message</label>
                               <textarea class="form-control"  onblur="return valmessage();" id="Message1" name="Message1" rows="5"></textarea>
                            </div>
                        </div>
                        <div class="col-sm-12 text-right">
                            <input type="submit" class="btn btn-warning" name="submit1" id="sub_contact_us1" onclick="return validate_contact_us();" >
                           
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
<section class="section-map">

    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3151.811052924625!2d144.96300941537004!3d-37.817894479751644!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6ad642b4758afc1d%3A0x42435549df48a4b0!2sLevel+13%2F2+Elizabeth+St%2C+Melbourne+VIC+3004%2C+Australia!5e0!3m2!1sen!2sin!4v1537944755187" width="100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
    </section>
 <script>
    function validate_contact_us() {

        var status = true;

        if(valName1() == false){

            status = false;
        }
        if(valContact2() == false){
            status = false;
        }           
        if(valEmail2() == false){
            status = false;
        } 

        if(valmessage() == false){
            status = false;
        }
        //alert(status);
        return status;

    }  

    function valName1() {
        var first_name = jQuery("#first_name").val();
        var regexp = /^[a-zA-Z ]*$/; 
        if(first_name == '') {
            jQuery("#first_name").css("border","1px solid red"); 
            jQuery("#first_name_error").css("display","");
            jQuery("#first_name_error").html('Please Enter name');
            return false; 
        }
        else if(first_name.search(regexp) == -1) {
            jQuery("#first_name").css("border","1px solid red");
            jQuery("#first_name_error").css("display","");
            jQuery("#first_name_error").html('Please Enter valid  name');
            return false; 
        }
        else {           
            jQuery("#first_name").css("border","1px solid #ccc");       
            jQuery("#first_name_error").css("display","none");
            return true;   
        }
    }
    function vallastName1() {
        var last_name = jQuery("#last_name").val();
        var regexp = /^[a-zA-Z ]*$/; 
        if(last_name == '') {
            jQuery("#last_name").css("border","1px solid red"); 
            jQuery("#last_name_error").css("display","");
            jQuery("#last_name_error").html('Please Enter last name');
            return false; 
        }
        else if(last_name.search(regexp) == -1) {
            jQuery("#last_name").css("border","1px solid red");
            jQuery("#last_name_error").css("display","");
            jQuery("#last_name_error").html('Please Enter valid  name');
            return false; 
        }
        else {           
            jQuery("#last_name").css("border","1px solid #ccc");       
            jQuery("#last_name_error").css("display","none");
            return true;   
        }
    } 
    function valContact2() {
        var phone1 = jQuery("#phone1").val();
        var regexp = /^[0-9]*$/; 
        if(phone1 == '') {
            jQuery("#phone1").css("border","1px solid red"); 
            jQuery("#phone_error").css("display","");
            jQuery("#phone_error").html('Please Enter contact number');
            return false; 
        }
        else if(phone1.search(regexp) == -1) {
            jQuery("#phone1").css("border","1px solid red");
            jQuery("#phone_error").css("display","");
            jQuery("#phone_error").html('Please Enter valid contact number');
            return false; 
        }
        else {      
            jQuery("#phone1").css("border","1px solid #ccc");             
            jQuery("#phone_error").css("display","none");
            return true;   
        }
    } 
    function valEmail2() {
        var emails_id = jQuery("#emails_id").val();
        var reg_email = /^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/;
        if(emails_id == '') {
            jQuery("#emails_id").css("border","1px solid red"); 
            jQuery("#emails_id_error1").css("display","");
            jQuery("#emails_id_error1").html('Please Enter email');
            return false; 
        }
        else if(!reg_email.test(emails_id)) {
            jQuery("#emails_id").css("border","1px solid red"); 
            jQuery("#emails_id_error1").css("display","");
            jQuery("#emails_id_error1").html('Please Enter valid email');
            return false; 
        }
        else {  
            jQuery("#emails_id").css("border","1px solid #ccc"); 
            jQuery("#emails_id_error1").css("display","none");
            return true;   
        }
    }

    function valmessage() {
        var Message = jQuery("#Message1").val();
        if(Message == '') {
            jQuery("#Message1").css("border","1px solid red"); 
            jQuery("#message_error").css("display","");
            jQuery("#message_error").html('Please Enter Message');
            return false; 
        }

        else {  
            jQuery("#Message1").css("border","1px solid #ccc"); 
            jQuery("#message_error").css("display","none");
            return true;   
        }
    } 

</script>
<?php             
//get_sidebar();
 get_footer();  