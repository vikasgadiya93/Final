<?php
    /**
    template name: multiple file upload
    */
    get_header(); ?>

<form id="upload_file" method="post" action="">
    <input type="file" name="files[]" id="multifiles" multiple > 
    <input type="button" name="submit" id="filesubmit" onclick="validate_multifile();">
</form>

<?php get_footer(); ?>
 
 <script type="text/javascript"> 
    function validate_multifile() {
      
           var post_data = new FormData();  
                          var ins = document.getElementById('multifiles').files.length;
                  alert(ins);
                    for (var x = 0; x < ins; x++) {
                        post_data.append("files[]", document.getElementById('multifiles').files[x]);
                    }  
          
          //  post_data.append( 'file_attach', attach_file );
            post_data.append('action', 'multiple_file'); 

            $.ajax({
                url: "<?php echo admin_url('admin-ajax.php'); ?>",
                type:"post",
                processData: false,
                contentType: false,
                data :  post_data,
                success:function(html) {
                    if(html == '1'){
                        alert("Successfully Submit");
                        $("input[type=text]").val("");
                        $("input[type=file]").val("");
                    }
                    else
                        {
                        alert("Not submit");
                    }
                },
                error: function(errorThrown){
                    console.log(errorThrown);
                }
            });
    }

 

</script>