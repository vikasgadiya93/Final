<?php
      
    //parse_str($_POST['data'], $_POST);
    global $wpdb;
  //  global $data;
         $images_arr = array();
    if(isset($_POST)){
        $no_files = count($_FILES["files"]['name']);

        for ($i = 0; $i < $no_files; $i++) {  
            //move_uploaded_file($_FILES["files"]["tmp_name"][$i], 'uploads/' . $_FILES["files"]["name"][$i]);
            //      echo 'File successfully uploaded : uploads/' . $_FILES["files"]["name"][$i] . ' ';
            $uploads = wp_upload_dir(); 
            $upload_dir = $uploads['basedir']; 
            $upload_dir1 = $uploads['baseurl']; 

            $new_upload= $upload_dir."/CV/";  
            $new_upload1= $upload_dir1."/CV/";

            $file = $new_upload .basename($_FILES['files']['name'][$i]);
            $img = $_FILES['files']['name'][$i] ;
            $file1 = $new_upload1."".$img; 

            move_uploaded_file($_FILES['files']['tmp_name'][$i], $file);
             $images_arr[] = $img;

        }
        // print_r($_FILES);       // To check file is there or not
        // $img = $_FILES['file_attach']['name'] ;
         $all_images = implode(",",$images_arr);

        $gender   = $_POST['gender'];                  
        $txtName  = $_POST['userName'];
        $txtEmail = $_POST['userEmail'];
        $phone_no = $_POST['userPhone'];


        $data = array("name"=>$txtName,"email"=>$txtEmail,"comments"=>$all_images,"contactno"=>$phone_no,"gender"=>$gender );
       //  print_r($data);
        $insert = $wpdb->insert("wp_contact",$data);
        echo "1";
        if($insert)
        { 
            $to = $subsc_email;
            $subject = "claim Enquery";

            $message.="<style type='text/css'>
            #sign{
            display:none;
            }
            a { color: #2D7BE0; }
            a:hover { text-decoration: none; }
            </style>
            <table style='background: #eee; padding-left:10px;' width='100%'>
            <tr>
            <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'> Gender </th>
            <td bgcolor='#fff' style='padding: 5px; background-color: #fff;' align='center' width='2%'> : </td>
            <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$myselect."</td>
            </tr>  
            <tr>
            <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'> Name </th>
            <td bgcolor='#fff' style='padding: 5px; background-color: #fff;' align='center' width='2%'> : </td>
            <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$txtName."</td>
            </tr>  
            <tr>
            <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'> Email </th>
            <td bgcolor='#fff' style='padding: 5px; background-color: #fff;' align='center' width='2%'> : </td>
            <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$txtEmail."</td>
            </tr>  
            <tr>
            <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'> Phone number </th>
            <td bgcolor='#fff' style='padding: 5px; background-color: #fff;' align='center' width='2%'> : </td>
            <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$phone_no."</td>
            </tr>  
            </table>
            <br>"; 
            $headers = "From: pepl <vikas@redsparkinfo.com>\r\n";
            $headers .= "MIME-Version: 1.0\r\n";
            $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
            wp_mail( $to, $subject, $message, $headers );
            $emailSent = true;   


        }
    }                 
?>