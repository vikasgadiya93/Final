<?php
    /**
    Template Name: Blog
    */
    get_header(); 
    $page_id = get_the_id();
    $post_img = wp_get_attachment_url( get_post_thumbnail_id( $page_id ) );
?>
<section class="breadcumb-section">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="breadcrumbs">
                    <ul>
                        <li class="home">
                            <a href="<?php echo home_url(); ?>">Home</a>           
                            <span>/ </span>
                        </li>
                        <li class="category9">
                            <strong><?php the_title(); ?> </strong>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="blog-container">
    <div class="container">
        <div class="blogsection">
            <div class="row">
                <div class="col-md-9 col-sm-8">
                    <?php  
                        $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;  
                        $args = array(
                        'post_type' => 'blog',
                        'posts_per_page' => '6',
                        'order' => 'DESC',
                        'paged' => $paged
                        );
                        $the_query = new WP_Query( $args );
                        if ( $the_query->have_posts() ) : while ( $the_query->have_posts() ) : $the_query->the_post();
                                $id=get_the_ID ();
                                // $post_class = get_post_meta( $id, 'post_class', true );   
                                $themeta = get_post_meta( $id, 'blog_caption', true );   
                                $themeta2 = get_post_meta( $id, 'blog_tagline', true );   
                                $blog_img = wp_get_attachment_url( get_post_thumbnail_id( $id ) );
                                $comments_count = wp_count_comments($id);  
                                $alt_meta = get_post_meta( $id, 'titles', true );                      
                            ?> 
                            <article class="blogpost-lists">
                                <div class="post-entry">
                                    <div class="entry-content-header">
                                        <h2 class="entry-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                                        <div class="blog-post-info">
                                            <div class="entry-meta">
                                                <ul class="list-inline blog_author">
                                                    <li> 
                                                        <span class="date"> <i class="fa fa-calendar-times-o"></i> <?php // echo get_the_date(); ?>
                                                        <?php echo human_time_diff( get_post_time('U', true), current_time('timestamp') ) . ' ago'; ?>
                                                         </span>
                                                    </li>
                                                    <li>
                                                        <?php $author = get_the_author(); ?>
                                                        <span class="by_author"> <i class="fa fa-user"></i> By <?php echo $author; ?></span>
                                                    </li>
                                                    <li>
                                                        <?php $author = get_the_author(); ?>
                                                        <span class="by_author"> <i class="fa fa-pencil-square-o"></i> Cat </span>
                                                    </li>
                                                    <!--<li>
                                                        <?php $author = get_the_author(); ?>
                                                        <span class="by_author"> <i class="fa fa-user"></i> By <?php echo $author; ?></span>
                                                    </li>-->
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="post-img">
                                            <a href="<?php the_permalink(); ?>">
                                                <img alt="<?php echo $alt_meta; ?>" class="img-responsive" src="<?php echo $blog_img; ?>">
                                            </a>
                                        </div>
                                    </div>
                                    <div class="entry-content">
                                        <p><?php echo substr(strip_tags(get_the_content()),0,500); ?></p>
                                        <a class="read-more" href="<?php the_permalink(); ?>">Continue reading</a>
                                    </div>
                                </div>
                            </article>
                            <hr>
                            <?php  
                                endwhile;endif;
                        wp_reset_query();            
                    ?>  
                    <div class="row blog-pagination">
                        <div class="col-sm-12 text-center">
                            <nav class="pagi-right">
                                <ul class="pagination">
                                    <li>
                                        <?php
                                            global $wp_query;
                                            $big = 999999999;
                                            echo paginate_links( array(
                                            'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
                                            'format' => '?paged=%#%',
                                            'prev_text' => __( '&laquo;', 'aag' ),
                                            'next_text' => __( '&raquo;', 'aag' ),
                                            'current' => max( 1, get_query_var('paged') ),
                                            'total' => $the_query->max_num_pages,
                                            ) );
                                        ?>
                                    </li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
                <?php get_sidebar('blog_side2'); ?>
            </div>
        </div>
    </div>
</section> <?php get_footer(); ?>