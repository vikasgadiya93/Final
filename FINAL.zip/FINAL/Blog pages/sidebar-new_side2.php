<aside class="blogright col-md-3 col-sm-4">
    <div class="sidebar-widget">
        <div class="sidebar-widget-title">
            Latest Blog
        </div>
        <div class="sidebar-widget-content sidebar-popularlist">
            <ul class="sidebar-widget-list">
                <?php  
                    $post_id = $id;
                    $args=array(
                    'post_type' => 'news',
                    'posts_per_page' => 4,
                    'post__not_in' => array( $post_id ),
                    'order' => 'DESC',
                    );
                    $the_query = new WP_Query( $args );
                    if ( $the_query->have_posts() ) : while ( $the_query->have_posts() ) : $the_query->the_post();
                            $var_title=get_post_meta($post->ID, 'sidebar_name', true);
                            $titles = get_the_title();  
                        ?>
                        <li> <a href="<?php the_permalink(); ?>"> <b><?php echo $titles; ?></b></a> </li>
                        <?php endwhile; endif; ?>
                <?php wp_reset_query();?>
            </ul>
        </div>
    </div>
</aside>