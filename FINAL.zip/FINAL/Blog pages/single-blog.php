<?php
    get_header();
    $id = get_the_ID(); 
    $current_user = wp_get_current_user();
    $user_id_1 = $current_user->ID;
    $user_name_1 = $current_user->user_login;
    $user_emai_l = $current_user->user_email; 
    $user_pass_1 = $current_user->user_password;
?>
<?php 
    if(isset($_POST['comment_submit']))    
    {
        global $wpdb;
        $name = $_POST['name1'];
        $email1 = $_POST['email1'];
        $commets = $_POST['commet_1'];
        $user_name = $_POST['user_name'];
        $Website = $_POST['Website'];
        $pass = $_POST['pass'];
        $post_id = get_the_ID();
        $current_user = wp_get_current_user();
        $user_id = $current_user->ID;
        $user_name1 = $current_user->user_login;
        $user_email = $current_user->user_email;

        $commnet_count = $wpdb->get_row( "SELECT * FROM wp_posts WHERE id=".$post_id );
        $comment = $commnet_count->comment_count;
        $comments = $comment + 1;
        $date = date('Y-m-d H:i:s');


        $com_id = $wpdb->insert("wp_comments", array(
        "comment_post_ID" => $post_id,
        "comment_author" => $name,
        "comment_author_email" => $email1,
        "comment_content" => $commets,
        "comment_author_url" => $Website,
        "comment_approved" => 1,
        "user_id" => $user_id
        ));  

        update_comment_meta( $com_id, 'user_name',  $user_name);
        update_comment_meta( $com_id, 'password', $pass);


        $wpdb->update( 'wp_posts', array(
        'comment_count' => $comments
        ),array( 'ID' => $post_id  )               
        );
    }        
?>
<section class="breadcumb-section">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="breadcrumbs">
                    <ul>
                        <li class="home">
                            <a href="<?php echo home_url(); ?>">Home</a>           
                            <span>/ </span>
                        </li>
                        <li class="home">
                            <a href="<?php echo home_url()."/blog/"; ?>">Blog</a>           
                            <span>/ </span>
                        </li>
                        <li class="category9">
                            <strong><?php the_title(); ?> </strong>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="blog-container">
    <div class="container">
        <div class="blogsection">
            <div class="row">
                <div class="col-md-9 col-sm-8">
                    <article class="blogpost-lists">
                        <?php while ( have_posts() ) : the_post(); 
                                $blog_img = wp_get_attachment_url( get_post_thumbnail_id( $id ) );
                                $alt_meta = get_post_meta( $id, 'titles', true );  
                            ?> 
                            <div class="post-entry">
                                <div class="entry-content-header">
                                    <h2 class="entry-title">
                                        <?php the_title(); ?>
                                    </h2>
                                    <div class="blog-post-info">
                                        <div class="entry-meta">
                                            <ul class="list-inline blog_author">
                                                <li> 
                                                    <span class="date"> <i class="fa fa-calendar-times-o"></i> <?php // echo get_the_date(); ?>
                                                        <?php echo human_time_diff( get_post_time('U', true), current_time('timestamp') ) . ' ago'; ?>
                                                    </span>
                                                </li>
                                                <li>
                                                    <?php $author = get_the_author(); ?>
                                                    <span class="by_author"> <i class="fa fa-user"></i> By <?php echo $author; ?></span>
                                                </li>
                                                <li>
                                                    <?php $author = get_the_author(); ?>
                                                    <span class="by_author"> <i class="fa fa-pencil-square-o"></i> Cat </span>
                                                </li>
                                                <!--<li>
                                                <?php $author = get_the_author(); ?>
                                                <span class="by_author"> <i class="fa fa-user"></i> By <?php echo $author; ?></span>
                                                </li>-->
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="post-img">
                                        <a href="<?php echo home_url(); ?>">
                                            <img alt="<?php echo $alt_meta; ?>" class="img-responsive" src="<?php echo $blog_img; ?>">
                                        </a>
                                    </div>
                                </div>
                                <div class="entry-content">
                                    <?php the_content(); ?>
                                </div>
                            </div>
                            <?php echo do_shortcode ('[apss_share]'); ?>
                            <?php endwhile; ?>
                    </article>

                    <div class="related-blog-lists">
						<div class="row">
							<div class="col-sm-12">
								<div class="title">
									<h3>Related</h3>
									<span><img src="http://redsparkinfo.in/diabetespetsupply/wp-content/themes/diabetespetsupply/images/divider.png" alt="" class="img-responsive"></span>
								</div>
							</div>
						</div>
                        <div class="row">
                            <?php  
                                $custom_taxterms = wp_get_object_terms( $post->ID, 'blog_category', array('fields' => 'ids') );
                                // echo "<pre>"; print_r($custom_taxterms); die; 
                                if($custom_taxterms[1]){
                                    $custom_taxterms = $custom_taxterms[1];
                                }else{
                                    $custom_taxterms = $custom_taxterms[0]; 
                                }
                                $args = array(
                                'post_type' => 'blog',
                                'post_status' => 'publish',
                                'posts_per_page' => 3, 
                                'orderby' => 'rand',
                                'tax_query' => array(
                                array(
                                'taxonomy' => 'blog_category',
                                'field' => 'id',
                                'terms' => $custom_taxterms
                                )
                                ),
                                'post__not_in' => array ($post->ID),
                                );
                                $related_items = new WP_Query( $args );
                                $count = $related_items->post_count; 
                                if ($related_items->have_posts()) : 
                                    while ( $related_items->have_posts() ) : $related_items->the_post();
                                        $ids =get_the_ID ();
                                        $themeta = get_post_meta( $ids, 'blog_caption', true );   
                                        $themeta2 = get_post_meta( $ids, 'blog_tagline', true );   
                                        $blog_img = wp_get_attachment_url( get_post_thumbnail_id( $ids ) );
                                        $comments_count = wp_count_comments($ids);  
                                        $alt_meta = get_post_meta( $ids, 'titles', true ); 
                                    ?>
                                    <div class="col-sm-4">
                                        <article class="blogpost-lists">
                                            <div class="post-entry blog-entry">
                                                <div class="entry-content-header">
                                                    <div class="post-img blog-img">
                                                        <a href="<?php the_permalink(); ?>">
                                                            <img alt="<?php echo $alt_meta; ?>" class="img-responsive" src="<?php echo $blog_img; ?>">
                                                        </a>
                                                    </div>
                                                    <h4 class="related-title">
                                                        <a href="<?php the_permalink(); ?>">
                                                            <strong> 
                                                                <?php the_title(); ?> 
                                                            </strong>
                                                        </a> 
                                                    </h4>
                                                </div>
                                            </div>
                                        </article>
                                    </div>
                                    <?php   
                                        $i++;
                                        endwhile;
                                    endif;
                                wp_reset_postdata();
                                if($count == 0){  
                                    echo " <div class='col-sm-12'> <div class='entry-content'> <p> OOPS...!There is no related post. </p> </div> </div>";
                                }
                            ?>                                                 
                        </div>
                    </div>
                </div>
                <?php get_sidebar('blog_side2'); ?>
            </div>
        </div>
    </div>
</section>
<script>
    function validate_comment() {
        var status = true;

        if(valName1() == false){
            status = false;
        }
        if(valEmail12() == false){
            status = false;
        } 
        if(valUser_Name() == false){
            status = false;
        } 
        if(valPass() == false){
            status = false;
        } 
        if(valComment() == false){
            status = false;
        } 
        return status;
    }
    function valName1() {
        alert();
        var first_name = jQuery("#name1").val();
        var regexp = /^[a-zA-Z ]*$/; 
        if(first_name == '') {
            jQuery("#name1").css("border","1px solid red"); 
            return false; 
        }
        else if(first_name.search(regexp) == -1) {
            jQuery("#name1").css("border","1px solid red");
            return false; 
        }
        else {           
            jQuery("#name1").css("border","1px solid #ccc");       
            return true;   
        }
    }
    function valEmail12() {
        var email_1 = jQuery("#email_1").val();
        var reg_email = /^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/;
        if(email_1 == '') {
            jQuery("#email_1").css("border","1px solid red"); 
            return false; 
        }
        else if(!reg_email.test(email_1)) {
            jQuery("#email_1").css("border","1px solid red"); 
            return false; 
        }
        else {  
            jQuery("#email_1").css("border","1px solid #ccc"); 
            return true;   
        }
    }
    function valUser_Name() {
        var user_name = jQuery("#user_name1").val();
        if(user_name == '') {
            jQuery("#user_name1").css("border","1px solid red"); 
            return false; 
        }
        else{      
            jQuery("#user_name1").css("border","1px solid #ccc");             
            return true;   
        }
    }
    function valPass() {
        var pass = jQuery("#pass1").val();
        var regexp = /^[0-9]*$/; 
        if(pass == '') {
            jQuery("#pass1").css("border","1px solid red"); 
            return false; 
        }
        else{      
            jQuery("#pass1").css("border","1px solid #ccc");             
            return true;   
        }
    }
    function valComment() {
        var comment1 = jQuery("#comment1").val();
        var regexp = /^[0-9]*$/; 
        if(comment1 == '') {
            jQuery("#comment1").css("border","1px solid red"); 
            return false; 
        }
        else{      
            jQuery("#comment1").css("border","1px solid #ccc");             
            return true;   
        }
    }
</script>
<?php get_footer(); ?>
