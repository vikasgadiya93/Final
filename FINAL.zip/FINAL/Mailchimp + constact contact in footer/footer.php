<?php
    /**
    * The template for displaying the footer
    *
    * Contains the closing of the "site-content" div and all content after.
    *
    * @package WordPress
    * @subpackage Twenty_Fifteen
    * @since Twenty Fifteen 1.0
    */
?>

<?php  
    if(isset($_POST['subscribe_submit']))  
    { 
        $email  = $_POST['subscribe_email'];
        $mysql_check="SELECT * FROM wp_subscribe WHERE email = '".$email."'";
        $result_check = $wpdb->get_results( $mysql_check ); 
        if(count($result_check) > 0) {
            //echo "Email already exists";
            //echo "<script>alert('Email already exists !');</script>";
            $error_msg1 = "<div class='alert alert-danger'><strong>Error!</strong> Email already exists</div>";     
            echo '<script>alert("1");</script>';
        } else{ 
            global $wpdb;
          $insert =  $wpdb->insert("wp_subscribe", array(
           "email" => $email,
            ));

       /* contact contact intergration */     

            require_once 'ctctWrapper/ConstantContact.php';
            require_once 'ctctWrapper/config.php';

            $ConstantContact = new ConstantContact("oauth2", $apiKey, $username, $accessToken);  //OR
            //$ConstantContact = new ConstantContact("basic", $apiKey, $username, $password);
            //Supply your credentials--API Key and other details--in config.php
            //echo "<pre>"; print_r($ConstantContact); die; 
            //Get potential contact lists
            $lists = $ConstantContact->getLists();
            //Lists are returned in multidimentional arrays 0 being the list, and 1 being the next50
//          /  echo "<pre>"; print_r($lists); die; 
            //Email address here is used for testing purposes
            $emailAddress = $email;
            
            //Search for our new Email address
            $search = $ConstantContact->searchContactsByEmail($emailAddress);

            //Debugging
            echo '<pre>';
            print_r($ConstantContact);
            echo '</pre>';
            echo $emailAddress . "<br>";

            //If the search didnt return a contact object
            if($search == false)
            {
                // Create a new Contact Object to store data into 
                $contactObj = new Contact();
                // Adding multiple lists to this new Contact Object
                $contactObj->lists = array($lists['lists'][0]->id);
                // Set the email address
                $contactObj->emailAddress = $emailAddress;
                $contactObj->emailAddress[0] = $emailAddress;
                //Set the opt in source
                $contactObj->optInSource = "ACTION_BY_CONTACT";
                // Create the Contact and DONE
                $Contact = $ConstantContact->addContact($contactObj);
                echo ("Contact added.");
            } //Otherwise we update our existing contact
            else 
            {
                // Gather data from our previous search and store it into a data type
                $contactObj = $ConstantContact->getContactDetails($search[0]);
                // We need to get the old list and add a new list to it as
                // this request requires a PUT and will remove the lists
                // as they are stored in an array
                array_push($contactObj->lists, $lists['lists'][0]->id );
                //array_push($contactObj->lists, $lists['lists'][18]->id );
                
                //Set the opt in value
                $contactObj->optInSource = "ACTION_BY_CONTACT";
                $contactObj->firstName = 'firstname';
                $contactObj->lastName = 'CTCTlastname';
                // Update the contact and DONE
                $UpdateContact = $ConstantContact->updateContact($contactObj);
                
                echo ("Contact updated.");
            }
             /* End contact contact intergration */  
            
            /* Mail chimp integration */
                require_once 'MCAPI.class.php'; 
                $apikey = '292f77344b1f390e2352e4ce4ae05ec9-us7';
                $listId = '8399f987d1';

                $api = new MCAPI($apikey);


                // $merge_vars = array('FNAME'=>$firstname, 'EMAIL'=>$email1);
                $merge_vars = array('EMAIL'=>$email,'FNAME'=>$check_name);
                // until the link contained in it is clicked!
                $retval = $api->listSubscribe( $listId, $email, $merge_vars );

                if ($api->errorCode){ 
                  //  echo "Unable to load listSubscribe()!<br />";
                 //   echo "\tCode=".$api->errorCode."<br />";
                 //   echo "\tMsg=".$api->errorMessage."<br />";
                } else {
                  //  echo "$email Subscribed Successfully !<br />";
                }   
                 
           /* End Mail chimp integration */
              
                    
            if($insert){
                //mail to customer
                $to = $email;
                $subject = "Thank You For subscription";
                $message = do_shortcode( '[email_header]' )."
                <h3> Thank you for subscription</h3>
                <br> ".do_shortcode( '[email_footer]' );    
                $headers = 'From: Periop Partners <'.get_option('admin_email').'>' ."\r\n";
                $headers .= "MIME-Version: 1.0\r\n";
                $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
                //   wp_mail( $to, $subject, $message, $headers );

                // mail to admin
                $to_1 = get_option('admin_email');
                // $to = 'deval@redsparkinfo.com';

                $subject_1 = "New subscription Inquiry";

                $message_1="<h2>Subscription Request</h2><br />";

                $message_1.="<style type='text/css'>
                #sign{
                display:none;
                }
                a { color: #2D7BE0; }
                a:hover { text-decoration: none; }
                </style>
                <table style='background: #eee; padding-left:10px;' width='100%'>
                <tr>
                <th colspan='2' bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;' width='20%'> Email </th>
                <td bgcolor='#fff' style='padding: 5px; background-color: #fff;' align='center' width='2%'> : </td>
                <td bgcolor='#fff' style='padding: 5px;background-color: #fff; text-align: left;'>".$email."</td>
                </tr>
                </table>
                <br>"; 

                //  $headers = "From: Quest Media profile_img ";
                $headers = 'From: Periop partners <'.get_option('admin_email').'>' ."\r\n";
                $headers .= "MIME-Version: 1.0\r\n";
                $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
              //  wp_mail( $to_1, $subject_1, $message_1, $headers );
                //  $_POST['email1']=$_POST['cell1']=$_POST['fname']=$_POST['pos']=$_POST['lname']=$_POST['profile_img']="";

                $emailSent = true;
                $success = "1"; 
                //  wp_redirect(  get_permalink( 64 ) );    
                exit;
            }

        }
    }     
?> 





<footer class="footer pd-bottom-10">
    <div class="container">
        <div class="row">
            <div class="col-sm-5">
                <h2>Sign Up to <span>Newsletter</span></h2>
            </div>
            <div class="col-sm-7">
                <form  action="" method="post">
                <div class="form-group">
                    <div class="input-group">
                        <!--   <input id="Date" name="Date" class="form-control" placeholder=" Enter your email address" type="text">
                        <span class="input-group-addon"><button class="btn Subscribebtn">Subscribe</button></span> </div>-->

                        <input type="text" class="form-control" name="subscribe_email" id="email" value="" placeholder="Enter your email address" onblur="return valEmail();" />
                    <span class="input-group-addon">  <input type="submit" name="subscribe_submit" value="Subscribe" id="subscribe_submit" class="btn Subscribebtn" onclick="return validate_subscribe();"> </span> </div>


                </div>
            </div>
            </form>
        </div>

        <hr>

         

    </div>


</footer>
<!-- Bootstrap core JavaScript
================================================== --> 
<!-- Placed at the end of the document so the pages load faster --> 
<script src="<?php echo get_template_directory_uri(); ?>/js/modernizr.js" type="text/javascript" ></script> 
<script src="<?php echo get_template_directory_uri(); ?>/js/bootstrap.min.js"></script> 
<script src="<?php echo get_template_directory_uri(); ?>/js/ie10-viewport-bug-workaround.js"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/theme.js"></script> 

<script> 
    function validate_subscribe() {
        var status = true;

        if(valEmail() == false){
            status = false;
        } 
        return status; 
    }
    function valEmail() {
        var email = jQuery("#email").val();
        var reg_email = /^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/;
        if(email == '') {
            jQuery("#email").css("border","1px solid red"); 
            jQuery("#email_error1").css("display","");
            jQuery("#email_error1").html('Please Enter email');
            return false; 
        }
        else if(!reg_email.test(email)) {
            jQuery("#email").css("border","1px solid red"); 
            jQuery("#email_error1").css("display","");
            jQuery("#email_error1").html('Please Enter valid email');
            return false; 
        }
        else {  
            jQuery("#email").css("border","1px solid #ccc"); 
            jQuery("#email_error1").css("display","none");
            return true;   
        }
    }
</script>
 <?php wp_footer(); ?>
</body>
</html>
