
function status_change(nid,status){
    /*var id = jQuery(t).attr("id");
    alert(id);*/
    if(status == '1'){ // Ads wiil be InActive
        var status_msg = 'Are you sure you want unsubscribe????';
    }else{
        var status_msg = 'Are you sure you want subscribe????';
    }
    var retVal = confirm(status_msg);
    if( retVal == true ){
        jQuery.ajax({
            type: "POST",
            async:false,
            url: ajaxurl,
            data: {
                'action'        :'check_newsletter_status',
                'status'    : status,
                'id'            : nid
            },
            success: function (response) {
                if(response==1)
                    {
                    window.location.href = "admin.php?page=unsubscribe_data";
                }
                else{
                    alert('Please try again');
                }
            }
        });
    }
    else{
        return false;
    } 
    // location.reload();
}


